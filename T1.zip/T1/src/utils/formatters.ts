// Format file size in bytes to human readable format
export function formatBytes(bytes: number, decimals: number = 2): string {
  if (bytes === 0) return '0 Bytes'

  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']

  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i]
}

// Format date to relative time or absolute date
export function formatDate(dateString: string): string {
  const date = new Date(dateString)
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  
  // If less than 24 hours, show relative time
  if (diff < 24 * 60 * 60 * 1000) {
    const hours = Math.floor(diff / (60 * 60 * 1000))
    const minutes = Math.floor(diff / (60 * 1000))
    
    if (hours > 0) {
      return `${hours}h ago`
    } else if (minutes > 0) {
      return `${minutes}m ago`
    } else {
      return 'Just now'
    }
  }
  
  // If less than a week, show day name
  if (diff < 7 * 24 * 60 * 60 * 1000) {
    return date.toLocaleDateString('en-US', { weekday: 'short' })
  }
  
  // Otherwise show date
  return date.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric',
    year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
  })
}

// Format path for display (shorten long paths)
export function formatPath(path: string, maxLength: number = 50): string {
  if (path.length <= maxLength) return path
  
  const parts = path.split('/')
  if (parts.length <= 2) return path
  
  // Show first and last parts with ... in between
  const first = parts[0] || '/'
  const last = parts[parts.length - 1]
  
  return `${first}/.../${last}`
}

// Format permissions (octal to rwx)
export function formatPermissions(octal: string): string {
  const permissions = ['---', '--x', '-w-', '-wx', 'r--', 'r-x', 'rw-', 'rwx']
  
  if (octal.length !== 3) return octal
  
  return octal
    .split('')
    .map(digit => permissions[parseInt(digit)])
    .join('')
}

// Get file extension from filename
export function getFileExtension(filename: string): string {
  const parts = filename.split('.')
  return parts.length > 1 ? `.${parts.pop()?.toLowerCase()}` : ''
}

// Check if file is text-based
export function isTextFile(filename: string, mimeType?: string): boolean {
  if (mimeType && mimeType.startsWith('text/')) return true
  
  const textExtensions = [
    '.txt', '.md', '.json', '.js', '.jsx', '.ts', '.tsx', '.css', '.html', '.xml',
    '.py', '.java', '.cpp', '.c', '.h', '.css', '.scss', '.less', '.yaml', '.yml',
    '.toml', '.ini', '.conf', '.config', '.env', '.gitignore', '.dockerfile', '.sh',
    '.bat', '.ps1', '.sql', '.php', '.rb', '.go', '.rs', '.swift', '.kt', '.scala',
    '.lua', '.perl', '.r', '.m', '.asm', '.vb', '.cs', '.fs', '.clj', '.hs', '.elm'
  ]
  
  const ext = getFileExtension(filename)
  return textExtensions.includes(ext)
}

// Check if file is an image
export function isImageFile(filename: string, mimeType?: string): boolean {
  if (mimeType && mimeType.startsWith('image/')) return true
  
  const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp', '.ico']
  const ext = getFileExtension(filename)
  return imageExtensions.includes(ext)
}

// Check if file is a video
export function isVideoFile(filename: string, mimeType?: string): boolean {
  if (mimeType && mimeType.startsWith('video/')) return true
  
  const videoExtensions = ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.mkv', '.m4v']
  const ext = getFileExtension(filename)
  return videoExtensions.includes(ext)
}

// Check if file is audio
export function isAudioFile(filename: string, mimeType?: string): boolean {
  if (mimeType && mimeType.startsWith('audio/')) return true
  
  const audioExtensions = ['.mp3', '.wav', '.flac', '.aac', '.ogg', '.wma', '.m4a']
  const ext = getFileExtension(filename)
  return audioExtensions.includes(ext)
}

// Check if file is an archive
export function isArchiveFile(filename: string): boolean {
  const archiveExtensions = ['.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz']
  const ext = getFileExtension(filename)
  return archiveExtensions.includes(ext)
}
