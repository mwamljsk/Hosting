import React, { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useDropzone } from 'react-dropzone'
import { FiUpload, FiX, FiFile, FiCheck, FiAlertCircle } from 'react-icons/fi'

interface UploadModalProps {
  currentPath: string
  onClose: () => void
  onUpload: (files: FileList) => Promise<void>
}

interface UploadFile {
  file: File
  status: 'pending' | 'uploading' | 'success' | 'error'
  progress: number
  error?: string
}

const UploadModal: React.FC<UploadModalProps> = ({
  currentPath,
  onClose,
  onUpload
}) => {
  const [uploadFiles, setUploadFiles] = useState<UploadFile[]>([])
  const [isUploading, setIsUploading] = useState(false)

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      file,
      status: 'pending' as const,
      progress: 0
    }))
    setUploadFiles(prev => [...prev, ...newFiles])
  }, [])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: true
  })

  const removeFile = (index: number) => {
    setUploadFiles(prev => prev.filter((_, i) => i !== index))
  }

  const handleUpload = async () => {
    if (uploadFiles.length === 0) return

    setIsUploading(true)
    
    try {
      // Create FileList-like object
      const files = uploadFiles.map(uf => uf.file)
      const fileList = {
        length: files.length,
        item: (index: number) => files[index],
        [Symbol.iterator]: function* () {
          for (let i = 0; i < files.length; i++) {
            yield files[i]
          }
        }
      } as FileList

      // Update status to uploading
      setUploadFiles(prev => prev.map(uf => ({ ...uf, status: 'uploading' as const })))

      await onUpload(fileList)

      // Update status to success
      setUploadFiles(prev => prev.map(uf => ({ ...uf, status: 'success' as const, progress: 100 })))

      // Close modal after a short delay
      setTimeout(() => {
        onClose()
      }, 1000)
    } catch (error) {
      // Update status to error
      setUploadFiles(prev => prev.map(uf => ({ 
        ...uf, 
        status: 'error' as const,
        error: error instanceof Error ? error.message : 'Upload failed'
      })))
    } finally {
      setIsUploading(false)
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <FiCheck className="text-green-400" />
      case 'error':
        return <FiAlertCircle className="text-red-400" />
      case 'uploading':
        return <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-400"></div>
      default:
        return <FiFile className="text-gray-400" />
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-6 w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <FiUpload className="h-6 w-6 text-blue-400" />
              <div>
                <h2 className="text-xl font-bold text-white">Upload Files</h2>
                <p className="text-white/60 text-sm">Upload to: {currentPath}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors"
            >
              <FiX />
            </button>
          </div>

          {/* Drop Zone */}
          <div
            {...getRootProps()}
            className={`
              border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer mb-6
              ${isDragActive 
                ? 'border-blue-400 bg-blue-400/10' 
                : 'border-white/30 hover:border-white/50 hover:bg-white/5'
              }
            `}
          >
            <input {...getInputProps()} />
            <FiUpload className="h-12 w-12 mx-auto mb-4 text-white/50" />
            {isDragActive ? (
              <p className="text-white">Drop the files here...</p>
            ) : (
              <div>
                <p className="text-white mb-2">Drag & drop files here, or click to select</p>
                <p className="text-white/50 text-sm">You can upload multiple files at once</p>
              </div>
            )}
          </div>

          {/* File List */}
          {uploadFiles.length > 0 && (
            <div className="flex-1 overflow-y-auto mb-6">
              <h3 className="text-white font-medium mb-3">Files to upload ({uploadFiles.length})</h3>
              <div className="space-y-2">
                {uploadFiles.map((uploadFile, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center justify-between p-3 bg-white/5 rounded-lg"
                  >
                    <div className="flex items-center space-x-3 min-w-0 flex-1">
                      {getStatusIcon(uploadFile.status)}
                      <div className="min-w-0 flex-1">
                        <p className="text-white text-sm truncate">{uploadFile.file.name}</p>
                        <p className="text-white/50 text-xs">
                          {formatFileSize(uploadFile.file.size)}
                        </p>
                        {uploadFile.error && (
                          <p className="text-red-400 text-xs mt-1">{uploadFile.error}</p>
                        )}
                      </div>
                    </div>
                    
                    {uploadFile.status === 'pending' && (
                      <button
                        onClick={() => removeFile(index)}
                        className="p-1 hover:bg-white/10 rounded text-white/50 hover:text-white transition-colors"
                      >
                        <FiX />
                      </button>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-white/70 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleUpload}
              disabled={uploadFiles.length === 0 || isUploading}
              className={`
                px-6 py-2 rounded-lg font-medium transition-colors
                ${uploadFiles.length === 0 || isUploading
                  ? 'bg-gray-500 text-gray-300 cursor-not-allowed'
                  : 'bg-blue-500 hover:bg-blue-600 text-white'
                }
              `}
            >
              {isUploading ? 'Uploading...' : `Upload ${uploadFiles.length} file(s)`}
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

export default UploadModal
