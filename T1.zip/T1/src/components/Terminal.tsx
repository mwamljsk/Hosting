import React, { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Terminal as XTerm } from 'xterm'
import { FitAddon } from 'xterm-addon-fit'
import io, { Socket } from 'socket.io-client'
import { FiTerminal, FiMaximize2, FiMinimize2, FiX, FiPower, FiRefreshCw } from 'react-icons/fi'
import 'xterm/css/xterm.css'

const Terminal: React.FC = () => {
  const terminalRef = useRef<HTMLDivElement>(null)
  const terminal = useRef<XTerm | null>(null)
  const fitAddon = useRef<FitAddon | null>(null)
  const socket = useRef<Socket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)

  useEffect(() => {
    initializeTerminal()
    
    return () => {
      cleanup()
    }
  }, [])

  const initializeTerminal = () => {
    if (!terminalRef.current) return

    // Initialize xterm
    terminal.current = new XTerm({
      theme: {
        background: 'rgba(0, 0, 0, 0.8)',
        foreground: '#ffffff',
        cursor: '#ffffff',
        cursorAccent: '#000000',

        black: '#000000',
        red: '#cd3131',
        green: '#0dbc79',
        yellow: '#e5e510',
        blue: '#2472c8',
        magenta: '#bc3fbc',
        cyan: '#11a8cd',
        white: '#e5e5e5',
        brightBlack: '#666666',
        brightRed: '#f14c4c',
        brightGreen: '#23d18b',
        brightYellow: '#f5f543',
        brightBlue: '#3b8eea',
        brightMagenta: '#d670d6',
        brightCyan: '#29b8db',
        brightWhite: '#e5e5e5'
      },
      fontFamily: 'JetBrains Mono, Consolas, Monaco, monospace',
      fontSize: 14,
      fontWeight: 'normal',
      lineHeight: 1.2,
      cursorBlink: true,
      cursorStyle: 'block',
      scrollback: 1000,
      tabStopWidth: 4,

    })

    fitAddon.current = new FitAddon()
    terminal.current.loadAddon(fitAddon.current)

    terminal.current.open(terminalRef.current)
    fitAddon.current.fit()

    // Connect to socket
    connectSocket()

    // Handle window resize
    const handleResize = () => {
      if (fitAddon.current && terminal.current) {
        fitAddon.current.fit()
        if (socket.current) {
          socket.current.emit('terminal-resize', {
            cols: terminal.current.cols,
            rows: terminal.current.rows
          })
        }
      }
    }

    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }

  const connectSocket = () => {
    socket.current = io('http://localhost:3001')

    socket.current.on('connect', () => {
      setIsConnected(true)
      socket.current?.emit('create-terminal')
    })

    socket.current.on('disconnect', () => {
      setIsConnected(false)
    })

    socket.current.on('terminal-ready', () => {
      if (terminal.current) {
        terminal.current.writeln('Terminal ready! Type commands below:')
        terminal.current.writeln('')
        
        // Handle terminal input
        let currentCommand = '';
        terminal.current.onData((data) => {
          if (data === '\r') {
            // Enter key pressed - execute command
            socket.current?.emit('execute-command', currentCommand)
            currentCommand = '';
          } else if (data === '\u007F') {
            // Backspace
            if (currentCommand.length > 0) {
              currentCommand = currentCommand.slice(0, -1);
              terminal.current?.write('\b \b');
            }
          } else if (data >= ' ' || data === '\t') {
            // Regular character
            currentCommand += data;
            terminal.current?.write(data);
          }
        })
      }
    })

    socket.current.on('terminal-output', (data: string) => {
      if (terminal.current) {
        terminal.current.write(data)
      }
    })

    socket.current.on('terminal-exit', () => {
      if (terminal.current) {
        terminal.current.writeln('\r\nTerminal session ended.')
      }
    })

    socket.current.on('terminal-error', (error: string) => {
      if (terminal.current) {
        terminal.current.writeln(`\r\nTerminal error: ${error}`)
      }
    })
  }

  const cleanup = () => {
    if (socket.current) {
      socket.current.disconnect()
    }
    if (terminal.current) {
      terminal.current.dispose()
    }
  }

  const restartTerminal = () => {
    cleanup()
    setTimeout(() => {
      initializeTerminal()
    }, 100)
  }

  const clearTerminal = () => {
    if (terminal.current) {
      terminal.current.clear()
    }
  }

  const terminalContainerClass = isFullscreen 
    ? 'fixed inset-0 z-50 bg-gray-900' 
    : 'h-full'

  return (
    <motion.div 
      className={terminalContainerClass}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10 bg-white/5 backdrop-blur-sm">
        <div className="flex items-center space-x-3">
          <FiTerminal className="text-green-400" />
          <div>
            <h3 className="text-white font-medium">Terminal</h3>
            <p className="text-white/50 text-sm">
              {isConnected ? 'Connected' : 'Disconnected'}
            </p>
          </div>
          <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-400' : 'bg-red-400'}`}></div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={clearTerminal}
            className="flex items-center space-x-2 px-3 py-2 bg-gray-500 hover:bg-gray-600 rounded-lg text-white transition-colors"
          >
            <FiX />
            <span>Clear</span>
          </button>

          <button
            onClick={restartTerminal}
            className="flex items-center space-x-2 px-3 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white transition-colors"
          >
            <FiRefreshCw />
            <span>Restart</span>
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors"
          >
            {isFullscreen ? <FiMinimize2 /> : <FiMaximize2 />}
          </button>

          {isFullscreen && (
            <button
              onClick={() => setIsFullscreen(false)}
              className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors"
            >
              <FiX />
            </button>
          )}
        </div>
      </div>

      {/* Terminal */}
      <div 
        ref={terminalRef}
        className="flex-1 p-4"
        style={{ 
          height: isFullscreen ? 'calc(100vh - 80px)' : 'calc(100% - 80px)',
          fontFamily: 'JetBrains Mono, Consolas, Monaco, monospace'
        }}
      />

      {/* Status Bar */}
      <div className="px-4 py-2 bg-white/5 border-t border-white/10 text-xs text-white/70 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <span>Status: {isConnected ? 'Connected' : 'Disconnected'}</span>
          {terminal.current && (
            <>
              <span>Size: {terminal.current.cols}x{terminal.current.rows}</span>
              <span>Encoding: UTF-8</span>
            </>
          )}
        </div>
        <div className="flex items-center space-x-4">
          <span>Ctrl+C: Interrupt</span>
          <span>Ctrl+D: Exit</span>
        </div>
      </div>
    </motion.div>
  )
}

export default Terminal
