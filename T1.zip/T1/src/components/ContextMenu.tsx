import React, { useEffect, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  FiEdit3, 
  FiTrash2, 
  FiCopy, 
  FiMove, 
  FiDownload, 
  FiArchive, 
  FiEye,
  FiInfo,
  FiShare2
} from 'react-icons/fi'

interface ContextMenuProps {
  x: number
  y: number
  file?: any
  onClose: () => void
  onDelete: (paths: string[]) => Promise<void>
  onRename: (oldPath: string, newName: string) => Promise<void>
  onEdit: (file: any) => void
}

const ContextMenu: React.FC<ContextMenuProps> = ({
  x,
  y,
  file,
  onClose,
  onDelete,
  onRename,
  onEdit
}) => {
  const menuRef = useRef<HTMLDivElement>(null)
  const [showRenameInput, setShowRenameInput] = useState(false)
  const [newName, setNewName] = useState('')

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose()
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    document.addEventListener('keydown', handleEscape)

    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
      document.removeEventListener('keydown', handleEscape)
    }
  }, [onClose])

  useEffect(() => {
    if (file) {
      setNewName(file.name)
    }
  }, [file])

  const handleRename = async () => {
    if (file && newName && newName !== file.name) {
      await onRename(file.path, newName)
    }
    setShowRenameInput(false)
    onClose()
  }

  const handleDelete = async () => {
    if (file) {
      await onDelete([file.path])
    }
    onClose()
  }

  const handleDownload = () => {
    if (file && !file.isDirectory) {
      const link = document.createElement('a')
      link.href = `http://localhost:3001/api/download?path=${encodeURIComponent(file.path)}`
      link.download = file.name
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    }
    onClose()
  }

  const handleEdit = () => {
    if (file && !file.isDirectory) {
      onEdit(file)
    }
    onClose()
  }

  const menuItems = [
    ...(file && !file.isDirectory ? [
      {
        icon: FiEye,
        label: 'Open',
        action: handleEdit,
        color: 'text-blue-400'
      },
      {
        icon: FiEdit3,
        label: 'Edit',
        action: handleEdit,
        color: 'text-green-400'
      }
    ] : []),
    {
      icon: FiEdit3,
      label: 'Rename',
      action: () => setShowRenameInput(true),
      color: 'text-yellow-400'
    },
    ...(file && !file.isDirectory ? [
      {
        icon: FiDownload,
        label: 'Download',
        action: handleDownload,
        color: 'text-purple-400'
      }
    ] : []),
    {
      icon: FiCopy,
      label: 'Copy',
      action: () => {
        // TODO: Implement copy functionality
        console.log('Copy:', file)
        onClose()
      },
      color: 'text-cyan-400'
    },
    {
      icon: FiMove,
      label: 'Move',
      action: () => {
        // TODO: Implement move functionality
        console.log('Move:', file)
        onClose()
      },
      color: 'text-orange-400'
    },
    {
      icon: FiArchive,
      label: 'Compress',
      action: () => {
        // TODO: Implement compression
        console.log('Compress:', file)
        onClose()
      },
      color: 'text-indigo-400'
    },
    {
      icon: FiInfo,
      label: 'Properties',
      action: () => {
        // TODO: Show properties modal
        console.log('Properties:', file)
        onClose()
      },
      color: 'text-gray-400'
    },
    {
      icon: FiTrash2,
      label: 'Delete',
      action: handleDelete,
      color: 'text-red-400',
      dangerous: true
    }
  ]

  // Adjust position to keep menu within viewport
  const adjustedX = Math.min(x, window.innerWidth - 200)
  const adjustedY = Math.min(y, window.innerHeight - (menuItems.length * 40 + 20))

  return (
    <AnimatePresence>
      <motion.div
        ref={menuRef}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="fixed z-50 bg-white/10 backdrop-blur-md border border-white/20 rounded-xl shadow-xl py-2 min-w-[180px]"
        style={{ left: adjustedX, top: adjustedY }}
      >
        {file && (
          <div className="px-3 py-2 border-b border-white/10 mb-1">
            <p className="text-white font-medium text-sm truncate">{file.name}</p>
            <p className="text-white/50 text-xs">
              {file.isDirectory ? 'Folder' : `${(file.size / 1024).toFixed(1)} KB`}
            </p>
          </div>
        )}

        {showRenameInput ? (
          <div className="px-3 py-2">
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  handleRename()
                } else if (e.key === 'Escape') {
                  setShowRenameInput(false)
                }
              }}
              onBlur={() => setShowRenameInput(false)}
              className="w-full px-2 py-1 bg-white/20 border border-white/30 rounded text-white text-sm focus:outline-none focus:ring-1 focus:ring-blue-400"
              autoFocus
            />
          </div>
        ) : (
          <div className="space-y-1">
            {menuItems.map((item, index) => (
              <motion.button
                key={index}
                whileHover={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
                whileTap={{ scale: 0.98 }}
                onClick={item.action}
                className={`
                  w-full flex items-center space-x-3 px-3 py-2 text-left transition-colors
                  ${item.dangerous ? 'hover:bg-red-500/20' : 'hover:bg-white/10'}
                `}
              >
                <item.icon className={`h-4 w-4 ${item.color}`} />
                <span className={`text-sm ${item.dangerous ? 'text-red-400' : 'text-white'}`}>
                  {item.label}
                </span>
              </motion.button>
            ))}
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  )
}

export default ContextMenu
