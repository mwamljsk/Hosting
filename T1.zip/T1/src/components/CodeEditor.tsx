import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import Editor from '@monaco-editor/react'
import { FiSave, FiDownload, FiMaximize2, FiMinimize2, FiX, FiFile } from 'react-icons/fi'
import axios from 'axios'
import toast from 'react-hot-toast'
import { useTheme } from '../contexts/ThemeContext'

interface CodeEditorProps {
  file: any
}

const CodeEditor: React.FC<CodeEditorProps> = ({ file }) => {
  const { isDark } = useTheme()
  const [content, setContent] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [isModified, setIsModified] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)

  // Load file content
  useEffect(() => {
    if (file && file.path) {
      loadFileContent()
    }
  }, [file])

  const loadFileContent = async () => {
    if (!file?.path) return
    
    setIsLoading(true)
    try {
      const response = await axios.get('http://localhost:3001/api/file-content', {
        params: { path: file.path }
      })
      
      if (response.data.isText) {
        setContent(response.data.content)
        setIsModified(false)
      } else {
        toast.error('This file cannot be edited (binary file)')
        setContent('')
      }
    } catch (error: any) {
      toast.error('Failed to load file content')
      setContent('')
    } finally {
      setIsLoading(false)
    }
  }

  const saveFile = async () => {
    if (!file?.path || !isModified) return
    
    setIsSaving(true)
    try {
      await axios.post('http://localhost:3001/api/save-file', {
        path: file.path,
        content
      })
      toast.success('File saved successfully')
      setIsModified(false)
    } catch (error: any) {
      toast.error('Failed to save file')
    } finally {
      setIsSaving(false)
    }
  }

  const downloadFile = async () => {
    if (!file?.path) return
    
    try {
      const blob = new Blob([content], { type: 'text/plain' })
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = file.name
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
      toast.success('File downloaded successfully')
    } catch (error) {
      toast.error('Failed to download file')
    }
  }

  const getLanguage = (filename: string) => {
    const ext = filename.split('.').pop()?.toLowerCase()
    const languageMap: { [key: string]: string } = {
      'js': 'javascript',
      'jsx': 'javascript',
      'ts': 'typescript',
      'tsx': 'typescript',
      'py': 'python',
      'java': 'java',
      'cpp': 'cpp',
      'c': 'c',
      'h': 'c',
      'css': 'css',
      'scss': 'scss',
      'less': 'less',
      'html': 'html',
      'xml': 'xml',
      'json': 'json',
      'yaml': 'yaml',
      'yml': 'yaml',
      'md': 'markdown',
      'sh': 'shell',
      'bash': 'shell',
      'sql': 'sql',
      'php': 'php',
      'rb': 'ruby',
      'go': 'go',
      'rs': 'rust',
      'swift': 'swift',
      'kt': 'kotlin',
      'scala': 'scala',
      'lua': 'lua',
      'perl': 'perl',
      'r': 'r',
      'dockerfile': 'dockerfile'
    }
    return languageMap[ext || ''] || 'plaintext'
  }

  if (!file) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center text-white/50">
          <FiFile className="h-16 w-16 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium">No file selected</p>
          <p className="text-sm">Select a file from the file list to edit</p>
        </div>
      </div>
    )
  }

  const editorContainerClass = isFullscreen 
    ? 'fixed inset-0 z-50 bg-gray-900' 
    : 'h-full'

  return (
    <motion.div 
      className={editorContainerClass}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10 bg-white/5 backdrop-blur-sm">
        <div className="flex items-center space-x-3">
          <FiFile className="text-blue-400" />
          <div>
            <h3 className="text-white font-medium">{file.name}</h3>
            <p className="text-white/50 text-sm">{file.path}</p>
          </div>
          {isModified && (
            <div className="w-2 h-2 bg-orange-400 rounded-full"></div>
          )}
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={saveFile}
            disabled={!isModified || isSaving}
            className={`
              flex items-center space-x-2 px-3 py-2 rounded-lg transition-colors
              ${isModified 
                ? 'bg-green-500 hover:bg-green-600 text-white' 
                : 'bg-white/10 text-white/50 cursor-not-allowed'
              }
            `}
          >
            <FiSave className={isSaving ? 'animate-spin' : ''} />
            <span>Save</span>
          </button>

          <button
            onClick={downloadFile}
            className="flex items-center space-x-2 px-3 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white transition-colors"
          >
            <FiDownload />
            <span>Download</span>
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors"
          >
            {isFullscreen ? <FiMinimize2 /> : <FiMaximize2 />}
          </button>

          {isFullscreen && (
            <button
              onClick={() => setIsFullscreen(false)}
              className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors"
            >
              <FiX />
            </button>
          )}
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1" style={{ height: isFullscreen ? 'calc(100vh - 80px)' : 'calc(100% - 80px)' }}>
        {isLoading ? (
          <div className="h-full flex items-center justify-center">
            <div className="flex items-center space-x-2 text-white">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
              <span>Loading file...</span>
            </div>
          </div>
        ) : (
          <Editor
            height="100%"
            language={getLanguage(file.name)}
            value={content}
            onChange={(value) => {
              setContent(value || '')
              setIsModified(true)
            }}
            theme={isDark ? 'vs-dark' : 'light'}
            options={{
              fontSize: 14,
              fontFamily: 'JetBrains Mono, Consolas, Monaco, monospace',
              lineNumbers: 'on',
              rulers: [80, 120],
              minimap: { enabled: true },
              scrollBeyondLastLine: false,
              automaticLayout: true,
              tabSize: 2,
              insertSpaces: true,
              wordWrap: 'on',
              renderWhitespace: 'selection',
              bracketPairColorization: { enabled: true },
              guides: {
                bracketPairs: true,
                indentation: true
              },
              suggest: {
                showKeywords: true,
                showSnippets: true
              },
              quickSuggestions: {
                other: true,
                comments: true,
                strings: true
              },
              parameterHints: { enabled: true },
              codeLens: true,

              folding: true,
              foldingStrategy: 'indentation',
              showFoldingControls: 'mouseover',
              unfoldOnClickAfterEndOfLine: true,
              smoothScrolling: true,
              cursorBlinking: 'smooth',
              cursorSmoothCaretAnimation: 'on'
            }}
            onMount={(editor) => {
              // Focus the editor
              editor.focus()
            }}
          />
        )}
      </div>

      {/* Status Bar */}
      <div className="px-4 py-2 bg-white/5 border-t border-white/10 text-xs text-white/70 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <span>Language: {getLanguage(file.name)}</span>
          <span>Lines: {content.split('\n').length}</span>
          <span>Characters: {content.length}</span>
        </div>
        <div className="flex items-center space-x-4">
          {isModified && <span className="text-orange-400">Modified</span>}
          {isSaving && <span className="text-blue-400">Saving...</span>}
        </div>
      </div>
    </motion.div>
  )
}

export default CodeEditor
