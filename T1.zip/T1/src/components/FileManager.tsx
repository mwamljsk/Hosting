import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  FiFolder, 
  FiFile, 
  FiPlus, 
  FiUpload, 
  FiDownload, 
  FiTrash2, 
  FiEdit3, 
  FiCopy, 
  FiMove, 
  FiSearch,
  FiGrid,
  FiList,
  FiHome,
  FiMonitor,
  FiTerminal,
  FiSun,
  FiMoon,
  FiSettings,
  FiRefreshCw
} from 'react-icons/fi'
import { useTheme } from '../contexts/ThemeContext'
import FileList from './FileList'
import CodeEditor from './CodeEditor'
import Terminal from './Terminal'
import SystemMonitor from './SystemMonitor'
import UploadModal from './UploadModal'
import CreateModal from './CreateModal'
import ContextMenu from './ContextMenu'
import { useFileManager } from '../hooks/useFileManager'

const FileManager: React.FC = () => {
  const { isDark, toggleTheme } = useTheme()
  const {
    currentPath,
    files,
    selectedFiles,
    isLoading,
    error,
    navigateToPath,
    refreshFiles,
    createFile,
    createFolder,
    deleteFiles,
    renameFile,
    uploadFiles
  } = useFileManager()

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list')
  const [activeTab, setActiveTab] = useState<'files' | 'editor' | 'terminal' | 'monitor'>('files')
  const [searchQuery, setSearchQuery] = useState('')
  const [showUploadModal, setShowUploadModal] = useState(false)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; file?: any } | null>(null)
  const [editingFile, setEditingFile] = useState<any>(null)

  // Glassmorphism styles
  const glassStyles = `
    backdrop-blur-md bg-white/10 border border-white/20 
    ${isDark ? 'bg-gray-900/20' : 'bg-white/20'}
    shadow-xl rounded-xl
  `

  const filteredFiles = files.filter(file =>
    file.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleFileClick = (file: any) => {
    if (file.isDirectory) {
      navigateToPath(file.path)
    } else {
      setEditingFile(file)
      setActiveTab('editor')
    }
  }

  const handleContextMenu = (e: React.MouseEvent, file?: any) => {
    e.preventDefault()
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      file
    })
  }

  return (
    <div className="h-screen flex flex-col p-4 space-y-4">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`${glassStyles} p-4`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <motion.h1 
              className="text-2xl font-bold text-white"
              whileHover={{ scale: 1.05 }}
            >
              🚀 Futuristic File Manager
            </motion.h1>
            <div className="text-sm text-white/70">
              {currentPath}
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Search */}
            <div className="relative">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/50" />
              <input
                type="text"
                placeholder="Search files..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* View mode toggle */}
            <div className="flex bg-white/10 rounded-lg p-1">
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded ${viewMode === 'list' ? 'bg-purple-500' : 'hover:bg-white/10'} text-white transition-colors`}
              >
                <FiList />
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded ${viewMode === 'grid' ? 'bg-purple-500' : 'hover:bg-white/10'} text-white transition-colors`}
              >
                <FiGrid />
              </button>
            </div>

            {/* Theme toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors"
            >
              {isDark ? <FiSun /> : <FiMoon />}
            </button>

            {/* Refresh */}
            <button
              onClick={refreshFiles}
              className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors"
              disabled={isLoading}
            >
              <FiRefreshCw className={isLoading ? 'animate-spin' : ''} />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 mt-4">
          {[
            { id: 'files', label: 'Files', icon: FiFolder },
            { id: 'editor', label: 'Editor', icon: FiEdit3 },
            { id: 'terminal', label: 'Terminal', icon: FiTerminal },
            { id: 'monitor', label: 'System', icon: FiMonitor }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                activeTab === tab.id 
                  ? 'bg-purple-500 text-white' 
                  : 'text-white/70 hover:bg-white/10 hover:text-white'
              }`}
            >
              <tab.icon />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex space-x-4 overflow-hidden">
        {/* Files Tab */}
        {activeTab === 'files' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex-1 flex flex-col space-y-4"
          >
            {/* Toolbar */}
            <div className={`${glassStyles} p-4`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => navigateToPath('/')}
                    className="flex items-center space-x-2 px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors"
                  >
                    <FiHome />
                    <span>Home</span>
                  </button>
                  
                  <button
                    onClick={() => navigateToPath(currentPath.split('/').slice(0, -1).join('/') || '/')}
                    className="px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-colors"
                    disabled={currentPath === '/'}
                  >
                    ← Back
                  </button>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setShowCreateModal(true)}
                    className="flex items-center space-x-2 px-3 py-2 bg-green-500 hover:bg-green-600 rounded-lg text-white transition-colors"
                  >
                    <FiPlus />
                    <span>New</span>
                  </button>
                  
                  <button
                    onClick={() => setShowUploadModal(true)}
                    className="flex items-center space-x-2 px-3 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white transition-colors"
                  >
                    <FiUpload />
                    <span>Upload</span>
                  </button>
                </div>
              </div>
            </div>

            {/* File List */}
            <div className={`${glassStyles} flex-1 overflow-hidden`}>
              <FileList
                files={filteredFiles}
                viewMode={viewMode}
                selectedFiles={selectedFiles}
                onFileClick={handleFileClick}
                onContextMenu={handleContextMenu}
                isLoading={isLoading}
                error={error}
              />
            </div>
          </motion.div>
        )}

        {/* Code Editor Tab */}
        {activeTab === 'editor' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`flex-1 ${glassStyles}`}
          >
            <CodeEditor file={editingFile} />
          </motion.div>
        )}

        {/* Terminal Tab */}
        {activeTab === 'terminal' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`flex-1 ${glassStyles}`}
          >
            <Terminal />
          </motion.div>
        )}

        {/* System Monitor Tab */}
        {activeTab === 'monitor' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`flex-1 ${glassStyles}`}
          >
            <SystemMonitor />
          </motion.div>
        )}
      </div>

      {/* Modals */}
      {showUploadModal && (
        <UploadModal
          currentPath={currentPath}
          onClose={() => setShowUploadModal(false)}
          onUpload={uploadFiles}
        />
      )}

      {showCreateModal && (
        <CreateModal
          currentPath={currentPath}
          onClose={() => setShowCreateModal(false)}
          onCreate={createFile}
          onCreateFolder={createFolder}
        />
      )}

      {/* Context Menu */}
      {contextMenu && (
        <ContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          file={contextMenu.file}
          onClose={() => setContextMenu(null)}
          onDelete={deleteFiles}
          onRename={renameFile}
          onEdit={(file) => {
            setEditingFile(file)
            setActiveTab('editor')
            setContextMenu(null)
          }}
        />
      )}
    </div>
  )
}

export default FileManager
