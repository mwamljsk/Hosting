import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { 
  FiCpu, 
  FiHardDrive, 
  FiMonitor, 
  FiServer, 
  FiClock,
  FiRefreshCw,
  FiActivity
} from 'react-icons/fi'
import axios from 'axios'
import { formatBytes } from '../utils/formatters'

interface SystemInfo {
  cpu: {
    usage: number
    cores: number
  }
  memory: {
    total: number
    free: number
    used: number
    usagePercent: number
  }
  disk: Array<{
    fs: string
    type: string
    size: number
    used: number
    available: number
    usagePercent: number
  }>
  os: {
    platform: string
    distro: string
    release: string
    hostname: string
    uptime: number
  }
}

const SystemMonitor: React.FC = () => {
  const [systemInfo, setSystemInfo] = useState<SystemInfo | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [autoRefresh, setAutoRefresh] = useState(true)

  const loadSystemInfo = async () => {
    setIsLoading(true)
    setError(null)
    
    try {
      const response = await axios.get('http://localhost:3001/api/system-info')
      setSystemInfo(response.data)
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to load system information'
      setError(errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadSystemInfo()
  }, [])

  useEffect(() => {
    if (!autoRefresh) return

    const interval = setInterval(loadSystemInfo, 2000)
    return () => clearInterval(interval)
  }, [autoRefresh])

  const formatUptime = (seconds: number) => {
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    
    if (days > 0) {
      return `${days}d ${hours}h ${minutes}m`
    } else if (hours > 0) {
      return `${hours}h ${minutes}m`
    } else {
      return `${minutes}m`
    }
  }

  const getUsageColor = (percentage: number) => {
    if (percentage < 50) return 'text-green-400'
    if (percentage < 80) return 'text-yellow-400'
    return 'text-red-400'
  }

  const getUsageBarColor = (percentage: number) => {
    if (percentage < 50) return 'bg-green-400'
    if (percentage < 80) return 'bg-yellow-400'
    return 'bg-red-400'
  }

  const ProgressBar: React.FC<{ percentage: number; className?: string }> = ({ 
    percentage, 
    className = '' 
  }) => (
    <div className={`w-full bg-white/10 rounded-full h-2 ${className}`}>
      <motion.div 
        className={`h-2 rounded-full ${getUsageBarColor(percentage)}`}
        initial={{ width: 0 }}
        animate={{ width: `${percentage}%` }}
        transition={{ duration: 0.5 }}
      />
    </div>
  )

  if (error) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center text-red-400">
          <FiServer className="h-16 w-16 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium">Error loading system information</p>
          <p className="text-sm opacity-70 mb-4">{error}</p>
          <button
            onClick={loadSystemInfo}
            className="px-4 py-2 bg-red-500 hover:bg-red-600 rounded-lg text-white transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="h-full p-6 overflow-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <FiMonitor className="h-6 w-6 text-blue-400" />
          <h2 className="text-xl font-bold text-white">System Monitor</h2>
          {isLoading && (
            <FiRefreshCw className="h-4 w-4 text-white animate-spin" />
          )}
        </div>

        <div className="flex items-center space-x-2">
          <label className="flex items-center space-x-2 text-white/70 text-sm">
            <input
              type="checkbox"
              checked={autoRefresh}
              onChange={(e) => setAutoRefresh(e.target.checked)}
              className="rounded"
            />
            <span>Auto-refresh</span>
          </label>
          
          <button
            onClick={loadSystemInfo}
            disabled={isLoading}
            className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors"
          >
            <FiRefreshCw className={isLoading ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      {!systemInfo ? (
        <div className="flex items-center justify-center h-64">
          <div className="flex items-center space-x-2 text-white">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
            <span>Loading system information...</span>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* CPU Information */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6"
          >
            <div className="flex items-center space-x-3 mb-4">
              <FiCpu className="h-6 w-6 text-blue-400" />
              <h3 className="text-lg font-semibold text-white">CPU</h3>
            </div>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-white/70">Usage</span>
                  <span className={`font-bold ${getUsageColor(systemInfo.cpu.usage)}`}>
                    {systemInfo.cpu.usage.toFixed(1)}%
                  </span>
                </div>
                <ProgressBar percentage={systemInfo.cpu.usage} />
              </div>
              
              <div className="flex justify-between">
                <span className="text-white/70">Cores</span>
                <span className="text-white">{systemInfo.cpu.cores}</span>
              </div>
            </div>
          </motion.div>

          {/* Memory Information */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6"
          >
            <div className="flex items-center space-x-3 mb-4">
              <FiActivity className="h-6 w-6 text-green-400" />
              <h3 className="text-lg font-semibold text-white">Memory</h3>
            </div>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-white/70">Usage</span>
                  <span className={`font-bold ${getUsageColor(systemInfo.memory.usagePercent)}`}>
                    {systemInfo.memory.usagePercent.toFixed(1)}%
                  </span>
                </div>
                <ProgressBar percentage={systemInfo.memory.usagePercent} />
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-white/70">Total</span>
                  <div className="text-white font-medium">
                    {formatBytes(systemInfo.memory.total)}
                  </div>
                </div>
                <div>
                  <span className="text-white/70">Used</span>
                  <div className="text-white font-medium">
                    {formatBytes(systemInfo.memory.used)}
                  </div>
                </div>
                <div>
                  <span className="text-white/70">Free</span>
                  <div className="text-white font-medium">
                    {formatBytes(systemInfo.memory.free)}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* System Information */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6"
          >
            <div className="flex items-center space-x-3 mb-4">
              <FiServer className="h-6 w-6 text-purple-400" />
              <h3 className="text-lg font-semibold text-white">System</h3>
            </div>
            
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-white/70">Platform</span>
                <span className="text-white">{systemInfo.os.platform}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Distribution</span>
                <span className="text-white">{systemInfo.os.distro}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Release</span>
                <span className="text-white">{systemInfo.os.release}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Hostname</span>
                <span className="text-white">{systemInfo.os.hostname}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/70">Uptime</span>
                <span className="text-white">{formatUptime(systemInfo.os.uptime)}</span>
              </div>
            </div>
          </motion.div>

          {/* Disk Information */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-6"
          >
            <div className="flex items-center space-x-3 mb-4">
              <FiHardDrive className="h-6 w-6 text-orange-400" />
              <h3 className="text-lg font-semibold text-white">Storage</h3>
            </div>
            
            <div className="space-y-4">
              {systemInfo.disk.map((disk, index) => (
                <div key={disk.fs} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-white/70 text-sm">
                      {disk.fs} ({disk.type})
                    </span>
                    <span className={`font-bold text-sm ${getUsageColor(disk.usagePercent)}`}>
                      {disk.usagePercent.toFixed(1)}%
                    </span>
                  </div>
                  <ProgressBar percentage={disk.usagePercent} />
                  <div className="flex justify-between text-xs text-white/60">
                    <span>{formatBytes(disk.used)} used</span>
                    <span>{formatBytes(disk.available)} free</span>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  )
}

export default SystemMonitor
