import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FiFile, FiFolder, FiX } from 'react-icons/fi'

interface CreateModalProps {
  currentPath: string
  onClose: () => void
  onCreate: (name: string, content?: string) => Promise<void>
  onCreateFolder: (name: string) => Promise<void>
}

const CreateModal: React.FC<CreateModalProps> = ({
  currentPath,
  onClose,
  onCreate,
  onCreateFolder
}) => {
  const [type, setType] = useState<'file' | 'folder'>('file')
  const [name, setName] = useState('')
  const [content, setContent] = useState('')
  const [isCreating, setIsCreating] = useState(false)

  const handleCreate = async () => {
    if (!name.trim()) return

    setIsCreating(true)
    try {
      if (type === 'file') {
        await onCreate(name, content)
      } else {
        await onCreateFolder(name)
      }
      onClose()
    } catch (error) {
      console.error('Failed to create:', error)
    } finally {
      setIsCreating(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleCreate()
    }
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-6 w-full max-w-md"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Create New</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-lg text-white transition-colors"
            >
              <FiX />
            </button>
          </div>

          {/* Type Selection */}
          <div className="mb-6">
            <p className="text-white/70 text-sm mb-3">What would you like to create?</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setType('file')}
                className={`
                  flex items-center space-x-3 p-4 rounded-lg border transition-colors
                  ${type === 'file'
                    ? 'border-blue-400 bg-blue-400/10 text-blue-400'
                    : 'border-white/20 hover:border-white/30 text-white/70 hover:text-white'
                  }
                `}
              >
                <FiFile />
                <span>File</span>
              </button>
              <button
                onClick={() => setType('folder')}
                className={`
                  flex items-center space-x-3 p-4 rounded-lg border transition-colors
                  ${type === 'folder'
                    ? 'border-blue-400 bg-blue-400/10 text-blue-400'
                    : 'border-white/20 hover:border-white/30 text-white/70 hover:text-white'
                  }
                `}
              >
                <FiFolder />
                <span>Folder</span>
              </button>
            </div>
          </div>

          {/* Name Input */}
          <div className="mb-6">
            <label className="block text-white/70 text-sm mb-2">
              {type === 'file' ? 'File name' : 'Folder name'}
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={type === 'file' ? 'example.txt' : 'New Folder'}
              className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              autoFocus
            />
            <p className="text-white/50 text-xs mt-1">
              Location: {currentPath}
            </p>
          </div>

          {/* Content Input (for files only) */}
          {type === 'file' && (
            <div className="mb-6">
              <label className="block text-white/70 text-sm mb-2">
                Initial content (optional)
              </label>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Enter file content..."
                rows={4}
                className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              />
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-white/70 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleCreate}
              disabled={!name.trim() || isCreating}
              className={`
                px-6 py-2 rounded-lg font-medium transition-colors
                ${!name.trim() || isCreating
                  ? 'bg-gray-500 text-gray-300 cursor-not-allowed'
                  : 'bg-blue-500 hover:bg-blue-600 text-white'
                }
              `}
            >
              {isCreating ? 'Creating...' : `Create ${type}`}
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

export default CreateModal
