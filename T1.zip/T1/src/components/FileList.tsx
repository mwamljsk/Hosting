import React from 'react'
import { motion } from 'framer-motion'
import { 
  FiFolder, 
  FiFile, 
  FiImage, 
  FiVideo, 
  FiMusic, 
  FiFileText, 
  FiCode,
  FiArchive,
  FiDatabase,
  FiSettings
} from 'react-icons/fi'
import { formatBytes, formatDate } from '../utils/formatters'

interface FileItem {
  name: string
  path: string
  isDirectory: boolean
  size: number
  modified: string
  permissions: string
  extension: string | null
  mimeType: string | null
}

interface FileListProps {
  files: FileItem[]
  viewMode: 'grid' | 'list'
  selectedFiles: string[]
  onFileClick: (file: FileItem) => void
  onContextMenu: (e: React.MouseEvent, file: FileItem) => void
  isLoading: boolean
  error: string | null
}

const FileList: React.FC<FileListProps> = ({
  files,
  viewMode,
  selectedFiles,
  onFileClick,
  onContextMenu,
  isLoading,
  error
}) => {
  // Get file icon based on type
  const getFileIcon = (file: FileItem) => {
    if (file.isDirectory) return FiFolder
    
    if (file.mimeType) {
      if (file.mimeType.startsWith('image/')) return FiImage
      if (file.mimeType.startsWith('video/')) return FiVideo
      if (file.mimeType.startsWith('audio/')) return FiMusic
      if (file.mimeType.startsWith('text/')) return FiFileText
    }
    
    if (file.extension) {
      const ext = file.extension.toLowerCase()
      if (['.js', '.jsx', '.ts', '.tsx', '.py', '.java', '.cpp', '.c', '.h', '.css', '.html', '.xml', '.json'].includes(ext)) {
        return FiCode
      }
      if (['.zip', '.rar', '.7z', '.tar', '.gz'].includes(ext)) {
        return FiArchive
      }
      if (['.db', '.sqlite', '.sql'].includes(ext)) {
        return FiDatabase
      }
      if (['.config', '.ini', '.conf'].includes(ext)) {
        return FiSettings
      }
    }
    
    return FiFile
  }

  // Get file color based on type
  const getFileColor = (file: FileItem) => {
    if (file.isDirectory) return 'text-blue-400'
    
    if (file.mimeType) {
      if (file.mimeType.startsWith('image/')) return 'text-green-400'
      if (file.mimeType.startsWith('video/')) return 'text-purple-400'
      if (file.mimeType.startsWith('audio/')) return 'text-pink-400'
      if (file.mimeType.startsWith('text/')) return 'text-gray-400'
    }
    
    if (file.extension) {
      const ext = file.extension.toLowerCase()
      if (['.js', '.jsx', '.ts', '.tsx'].includes(ext)) return 'text-yellow-400'
      if (['.py'].includes(ext)) return 'text-green-500'
      if (['.java'].includes(ext)) return 'text-orange-400'
      if (['.cpp', '.c', '.h'].includes(ext)) return 'text-blue-500'
      if (['.zip', '.rar', '.7z', '.tar', '.gz'].includes(ext)) return 'text-red-400'
    }
    
    return 'text-gray-300'
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="flex items-center space-x-2 text-white">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
          <span>Loading files...</span>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-red-400 text-center">
          <FiFile className="h-16 w-16 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium">Error loading files</p>
          <p className="text-sm opacity-70">{error}</p>
        </div>
      </div>
    )
  }

  if (files.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-white/50 text-center">
          <FiFolder className="h-16 w-16 mx-auto mb-4 opacity-50" />
          <p className="text-lg font-medium">Empty directory</p>
          <p className="text-sm">No files or folders to display</p>
        </div>
      </div>
    )
  }

  // Grid view
  if (viewMode === 'grid') {
    return (
      <div className="p-4 h-full overflow-auto">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {files.map((file, index) => {
            const Icon = getFileIcon(file)
            const isSelected = selectedFiles.includes(file.path)
            
            return (
              <motion.div
                key={file.path}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.02 }}
                className={`
                  relative group cursor-pointer p-3 rounded-lg transition-all duration-200
                  hover:bg-white/10 hover:scale-105 hover:shadow-lg
                  ${isSelected ? 'bg-purple-500/30 ring-2 ring-purple-400' : ''}
                `}
                onClick={() => onFileClick(file)}
                onContextMenu={(e) => onContextMenu(e, file)}
              >
                <div className="flex flex-col items-center text-center space-y-2">
                  <Icon className={`h-12 w-12 ${getFileColor(file)}`} />
                  <div className="text-xs text-white break-all line-clamp-2">
                    {file.name}
                  </div>
                  {!file.isDirectory && (
                    <div className="text-xs text-white/50">
                      {formatBytes(file.size)}
                    </div>
                  )}
                </div>
                
                {/* Selection indicator */}
                {isSelected && (
                  <div className="absolute top-1 right-1 w-3 h-3 bg-purple-500 rounded-full"></div>
                )}
              </motion.div>
            )
          })}
        </div>
      </div>
    )
  }

  // List view
  return (
    <div className="h-full overflow-auto">
      {/* Header */}
      <div className="sticky top-0 bg-white/5 backdrop-blur-sm border-b border-white/10 px-4 py-2">
        <div className="grid grid-cols-12 gap-4 text-xs font-medium text-white/70 uppercase tracking-wider">
          <div className="col-span-6">Name</div>
          <div className="col-span-2">Size</div>
          <div className="col-span-2">Modified</div>
          <div className="col-span-2">Permissions</div>
        </div>
      </div>

      {/* File rows */}
      <div className="p-2">
        {files.map((file, index) => {
          const Icon = getFileIcon(file)
          const isSelected = selectedFiles.includes(file.path)
          
          return (
            <motion.div
              key={file.path}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.01 }}
              className={`
                group grid grid-cols-12 gap-4 px-2 py-3 rounded-lg cursor-pointer
                transition-all duration-200 hover:bg-white/5
                ${isSelected ? 'bg-purple-500/20 ring-1 ring-purple-400' : ''}
              `}
              onClick={() => onFileClick(file)}
              onContextMenu={(e) => onContextMenu(e, file)}
            >
              {/* Name */}
              <div className="col-span-6 flex items-center space-x-3 min-w-0">
                <Icon className={`h-5 w-5 flex-shrink-0 ${getFileColor(file)}`} />
                <span className="text-white truncate group-hover:text-white">
                  {file.name}
                </span>
                {isSelected && (
                  <div className="w-2 h-2 bg-purple-500 rounded-full flex-shrink-0"></div>
                )}
              </div>

              {/* Size */}
              <div className="col-span-2 flex items-center text-white/60 text-sm">
                {file.isDirectory ? '-' : formatBytes(file.size)}
              </div>

              {/* Modified */}
              <div className="col-span-2 flex items-center text-white/60 text-sm">
                {formatDate(file.modified)}
              </div>

              {/* Permissions */}
              <div className="col-span-2 flex items-center text-white/60 text-sm font-mono">
                {file.permissions}
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}

export default FileList
