import React, { useState, useEffect } from 'react'
import { Toaster } from 'react-hot-toast'
import FileManager from './components/FileManager'
import { ThemeProvider } from './contexts/ThemeContext'
import './App.css'

function App() {
  return (
    <ThemeProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="fixed inset-0 opacity-20" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-opacity='0.03'%3E%3Cpolygon fill='%23ffffff' points='50 0 60 40 100 50 60 60 50 100 40 60 0 50 40 40'/%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
        
        <FileManager />
        
        <Toaster
          position="top-right"
          toastOptions={{
            className: 'backdrop-blur-md bg-white/10 border border-white/20 text-white',
            duration: 4000,
          }}
        />
      </div>
    </ThemeProvider>
  )
}

export default App
