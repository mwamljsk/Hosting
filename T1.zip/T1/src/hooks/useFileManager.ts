import { useState, useEffect, useCallback } from 'react'
import axios from 'axios'
import toast from 'react-hot-toast'

const API_BASE = 'http://localhost:3001/api'

interface FileItem {
  name: string
  path: string
  isDirectory: boolean
  size: number
  modified: string
  permissions: string
  extension: string | null
  mimeType: string | null
}

interface FileManagerState {
  currentPath: string
  files: FileItem[]
  selectedFiles: string[]
  isLoading: boolean
  error: string | null
}

export function useFileManager() {
  const [state, setState] = useState<FileManagerState>({
    currentPath: '/',
    files: [],
    selectedFiles: [],
    isLoading: false,
    error: null
  })

  // Load files from the server
  const loadFiles = useCallback(async (path: string) => {
    setState(prev => ({ ...prev, isLoading: true, error: null }))
    
    try {
      const response = await axios.get(`${API_BASE}/files`, {
        params: { path }
      })
      
      setState(prev => ({
        ...prev,
        currentPath: response.data.currentPath,
        files: response.data.files,
        isLoading: false
      }))
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to load files'
      setState(prev => ({ ...prev, isLoading: false, error: errorMessage }))
      toast.error(errorMessage)
    }
  }, [])

  // Navigate to a specific path
  const navigateToPath = useCallback((path: string) => {
    loadFiles(path)
  }, [loadFiles])

  // Refresh current directory
  const refreshFiles = useCallback(() => {
    loadFiles(state.currentPath)
  }, [loadFiles, state.currentPath])

  // Create a new file
  const createFile = useCallback(async (name: string, content: string = '') => {
    try {
      await axios.post(`${API_BASE}/create-file`, {
        path: state.currentPath,
        name,
        content
      })
      toast.success(`File "${name}" created successfully`)
      refreshFiles()
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to create file'
      toast.error(errorMessage)
    }
  }, [state.currentPath, refreshFiles])

  // Create a new folder
  const createFolder = useCallback(async (name: string) => {
    try {
      await axios.post(`${API_BASE}/mkdir`, {
        path: state.currentPath,
        name
      })
      toast.success(`Folder "${name}" created successfully`)
      refreshFiles()
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to create folder'
      toast.error(errorMessage)
    }
  }, [state.currentPath, refreshFiles])

  // Delete files/folders
  const deleteFiles = useCallback(async (paths: string[]) => {
    try {
      await Promise.all(
        paths.map(path => axios.delete(`${API_BASE}/delete`, { data: { path } }))
      )
      toast.success(`${paths.length} item(s) deleted successfully`)
      refreshFiles()
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to delete files'
      toast.error(errorMessage)
    }
  }, [refreshFiles])

  // Rename file/folder
  const renameFile = useCallback(async (oldPath: string, newName: string) => {
    try {
      await axios.post(`${API_BASE}/rename`, {
        oldPath,
        newName
      })
      toast.success('Item renamed successfully')
      refreshFiles()
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to rename item'
      toast.error(errorMessage)
    }
  }, [refreshFiles])

  // Move files
  const moveFiles = useCallback(async (sourcePaths: string[], destinationPath: string) => {
    try {
      await Promise.all(
        sourcePaths.map(source => 
          axios.post(`${API_BASE}/move`, { source, destination: destinationPath })
        )
      )
      toast.success(`${sourcePaths.length} item(s) moved successfully`)
      refreshFiles()
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to move files'
      toast.error(errorMessage)
    }
  }, [refreshFiles])

  // Copy files
  const copyFiles = useCallback(async (sourcePaths: string[], destinationPath: string) => {
    try {
      await Promise.all(
        sourcePaths.map(source => 
          axios.post(`${API_BASE}/copy`, { source, destination: destinationPath })
        )
      )
      toast.success(`${sourcePaths.length} item(s) copied successfully`)
      refreshFiles()
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to copy files'
      toast.error(errorMessage)
    }
  }, [refreshFiles])

  // Upload files
  const uploadFiles = useCallback(async (files: FileList, path: string = state.currentPath) => {
    const formData = new FormData()
    Array.from(files).forEach(file => {
      formData.append('files', file)
    })
    formData.append('path', path)

    try {
      const response = await axios.post(`${API_BASE}/upload`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        },
        onUploadProgress: (progressEvent) => {
          const percentCompleted = Math.round(
            (progressEvent.loaded * 100) / (progressEvent.total || 1)
          )
          // You can implement a progress bar here
          console.log(`Upload Progress: ${percentCompleted}%`)
        }
      })
      
      toast.success(`${files.length} file(s) uploaded successfully`)
      refreshFiles()
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to upload files'
      toast.error(errorMessage)
    }
  }, [state.currentPath, refreshFiles])

  // Download file
  const downloadFile = useCallback(async (filePath: string) => {
    try {
      const response = await axios.get(`${API_BASE}/download`, {
        params: { path: filePath },
        responseType: 'blob'
      })
      
      const url = window.URL.createObjectURL(new Blob([response.data]))
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', filePath.split('/').pop() || 'file')
      document.body.appendChild(link)
      link.click()
      link.remove()
      window.URL.revokeObjectURL(url)
      
      toast.success('File downloaded successfully')
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to download file'
      toast.error(errorMessage)
    }
  }, [])

  // Create ZIP archive
  const createZip = useCallback(async (paths: string[], outputName: string) => {
    try {
      const outputPath = `${state.currentPath}/${outputName}.zip`
      await axios.post(`${API_BASE}/zip`, {
        paths,
        outputPath
      })
      toast.success('ZIP archive created successfully')
      refreshFiles()
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to create ZIP archive'
      toast.error(errorMessage)
    }
  }, [state.currentPath, refreshFiles])

  // Extract ZIP archive
  const extractZip = useCallback(async (zipPath: string, extractPath: string = state.currentPath) => {
    try {
      await axios.post(`${API_BASE}/unzip`, {
        zipPath,
        extractPath
      })
      toast.success('ZIP archive extracted successfully')
      refreshFiles()
    } catch (error: any) {
      const errorMessage = error.response?.data?.error || 'Failed to extract ZIP archive'
      toast.error(errorMessage)
    }
  }, [state.currentPath, refreshFiles])

  // Select/deselect files
  const toggleFileSelection = useCallback((filePath: string) => {
    setState(prev => ({
      ...prev,
      selectedFiles: prev.selectedFiles.includes(filePath)
        ? prev.selectedFiles.filter(path => path !== filePath)
        : [...prev.selectedFiles, filePath]
    }))
  }, [])

  const selectAllFiles = useCallback(() => {
    setState(prev => ({
      ...prev,
      selectedFiles: prev.files.map(file => file.path)
    }))
  }, [])

  const clearSelection = useCallback(() => {
    setState(prev => ({
      ...prev,
      selectedFiles: []
    }))
  }, [])

  // Load initial files on mount
  useEffect(() => {
    loadFiles('/')
  }, [loadFiles])

  return {
    ...state,
    navigateToPath,
    refreshFiles,
    createFile,
    createFolder,
    deleteFiles,
    renameFile,
    moveFiles,
    copyFiles,
    uploadFiles,
    downloadFile,
    createZip,
    extractZip,
    toggleFileSelection,
    selectAllFiles,
    clearSelection
  }
}
