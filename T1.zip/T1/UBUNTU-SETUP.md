# 🚀 Futuristic File Manager - Ubuntu Setup Guide

## Quick Start Commands for Ubuntu

Run these commands in your terminal to get the file manager working:

### 1. 📁 Navigate to the project directory
```bash
cd futuristic-file-manager
```

### 2. 🔧 Make scripts executable
```bash
chmod +x setup-ubuntu.sh start-filemanager.sh stop-filemanager.sh
```

### 3. 🏗️ Run the setup (installs all dependencies)
```bash
./setup-ubuntu.sh
```

### 4. 🚀 Start the file manager
```bash
./start-filemanager.sh
```

### 5. 🌐 Open your browser
Navigate to: **http://localhost:5173**

---

## Manual Setup (Alternative Method)

If the scripts don't work, follow these manual steps:

### Step 1: Install Node.js (if not installed)
```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install pnpm
npm install -g pnpm
```

### Step 2: Install Dependencies
```bash
# Install backend dependencies
cd server
npm install
cd ..

# Install frontend dependencies
pnpm install
```

### Step 3: Start Servers (Use 2 Terminal Windows)

**Terminal 1 - Backend Server:**
```bash
cd server
npm start
```

**Terminal 2 - Frontend Server:**
```bash
pnpm dev
```

### Step 4: Access the Application
Open your browser and go to: **http://localhost:5173**

---

## 🛑 Stopping the Servers

### Using the stop script:
```bash
./stop-filemanager.sh
```

### Manual method:
Press `Ctrl+C` in both terminal windows

### Force stop (if needed):
```bash
sudo pkill -f "node.*server.js"
sudo pkill -f "vite"
```

---

## 🔧 Troubleshooting

### Issue: "Failed to load files"
**Solution:** Make sure both servers are running:
- Backend on port 3001: `http://localhost:3001`
- Frontend on port 5173: `http://localhost:5173`

### Issue: Port already in use
**Solution:** Kill existing processes:
```bash
sudo lsof -ti:3001 | xargs sudo kill -9
sudo lsof -ti:5173 | xargs sudo kill -9
```

### Issue: Permission denied
**Solution:** Make sure you have the necessary permissions:
```bash
sudo chown -R $USER:$USER .
chmod +x *.sh
```

### Issue: Dependencies not installing
**Solution:** Clear caches and reinstall:
```bash
# Clear npm cache
npm cache clean --force

# Clear pnpm cache
pnpm store prune

# Reinstall
cd server && npm install && cd ..
pnpm install
```

---

## 📋 Requirements

- **Ubuntu 18.04+** (or any Debian-based Linux)
- **Node.js 16+** (LTS recommended)
- **npm or pnpm**
- **Modern web browser** (Chrome, Firefox, Safari, Edge)

---

## 🔒 Security Note

This file manager provides **FULL SYSTEM ACCESS** as requested. It can:
- Access all files and directories on your system
- Execute terminal commands
- Modify system files

**⚠️ Important:** Only use this on trusted systems and networks. Do not expose this to the internet without proper authentication and security measures.

---

## 🎯 Features Included

✅ **Complete File Management** - Browse, create, delete, rename, move files/folders  
✅ **Drag & Drop Upload** - Upload files with progress tracking  
✅ **Code Editor** - Monaco editor with syntax highlighting  
✅ **Terminal Interface** - Execute shell commands with live output  
✅ **System Monitor** - CPU, RAM, disk usage, OS information  
✅ **Archive Operations** - ZIP/UNZIP functionality  
✅ **File Preview** - Text, images, videos, PDFs  
✅ **Batch Operations** - Multi-select functionality  
✅ **Dark/Light Theme** - Modern glassmorphism design  
✅ **Mobile Responsive** - Works on all devices  

---

## 📞 Need Help?

If you encounter any issues, check the log files:
```bash
# Backend logs
tail -f logs/backend.log

# Frontend logs  
tail -f logs/frontend.log
```

The application should now work perfectly on your Ubuntu system! 🎉
