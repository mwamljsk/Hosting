#!/bin/bash

# 🚀 Futuristic File Manager - Ubuntu Setup Script
# This script will set up and run the file manager on Ubuntu

echo "🚀 Setting up Futuristic File Manager for Ubuntu..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Installing Node.js..."
    
    # Install Node.js using NodeSource repository
    curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
    sudo apt-get install -y nodejs
    
    echo "✅ Node.js installed successfully"
else
    echo "✅ Node.js is already installed"
fi

# Check if npm is available
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not available. Installing npm..."
    sudo apt-get update
    sudo apt-get install -y npm
    echo "✅ npm installed successfully"
else
    echo "✅ npm is already available"
fi

# Install pnpm globally if not already installed
if ! command -v pnpm &> /dev/null; then
    echo "📦 Installing pnpm..."
    npm install -g pnpm
    echo "✅ pnpm installed successfully"
else
    echo "✅ pnpm is already installed"
fi

echo ""
echo "🔧 Installing dependencies..."

# Install backend dependencies
echo "📦 Installing backend dependencies..."
cd server
npm install
cd ..

# Install frontend dependencies
echo "📦 Installing frontend dependencies..."
pnpm install

echo ""
echo "✅ Setup complete!"
echo ""
echo "🎯 To start the File Manager:"
echo "1. Run: ./start-filemanager.sh"
echo "   OR"
echo "2. Run manually:"
echo "   - Terminal 1: cd server && npm start"
echo "   - Terminal 2: pnpm dev"
echo ""
echo "🌐 The application will be available at:"
echo "   http://localhost:5173 (Development mode)"
echo ""
echo "🔒 Security Note: This file manager has full system access as requested."
echo "    Only use this on trusted networks and systems."
