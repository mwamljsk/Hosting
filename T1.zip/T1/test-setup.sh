#!/bin/bash

# 🧪 Futuristic File Manager - System Test Script
# This script tests if your system is ready to run the file manager

echo "🧪 Testing system requirements for Futuristic File Manager..."
echo ""

# Test 1: Check Node.js
echo "1️⃣ Checking Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo "   ✅ Node.js found: $NODE_VERSION"
else
    echo "   ❌ Node.js not found. Run: curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash - && sudo apt-get install -y nodejs"
fi

# Test 2: Check npm
echo "2️⃣ Checking npm..."
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm --version)
    echo "   ✅ npm found: $NPM_VERSION"
else
    echo "   ❌ npm not found. Run: sudo apt-get install -y npm"
fi

# Test 3: Check pnpm
echo "3️⃣ Checking pnpm..."
if command -v pnpm &> /dev/null; then
    PNPM_VERSION=$(pnpm --version)
    echo "   ✅ pnpm found: $PNPM_VERSION"
else
    echo "   ⚠️  pnpm not found. Run: npm install -g pnpm"
fi

# Test 4: Check ports
echo "4️⃣ Checking required ports..."
if lsof -Pi :3001 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo "   ⚠️  Port 3001 is in use. Stop the process or use a different port."
else
    echo "   ✅ Port 3001 is available"
fi

if lsof -Pi :5173 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo "   ⚠️  Port 5173 is in use. Stop the process or use a different port."
else
    echo "   ✅ Port 5173 is available"
fi

# Test 5: Check dependencies
echo "5️⃣ Checking project dependencies..."
if [ -d "server/node_modules" ]; then
    echo "   ✅ Backend dependencies installed"
else
    echo "   ❌ Backend dependencies missing. Run: cd server && npm install"
fi

if [ -d "node_modules" ]; then
    echo "   ✅ Frontend dependencies installed"
else
    echo "   ❌ Frontend dependencies missing. Run: pnpm install"
fi

# Test 6: Check file permissions
echo "6️⃣ Checking file permissions..."
if [ -x "start-filemanager.sh" ]; then
    echo "   ✅ Start script is executable"
else
    echo "   ❌ Start script not executable. Run: chmod +x *.sh"
fi

echo ""
echo "🎯 Test Summary:"
echo "If all tests show ✅, you're ready to run: ./start-filemanager.sh"
echo "If any tests show ❌, follow the suggested commands to fix the issues."
echo ""
