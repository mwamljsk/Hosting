#!/bin/bash

# 🏗️ Futuristic File Manager - Production Build Script
# This script builds the application for production deployment

echo "🏗️ Building Futuristic File Manager for production..."

# Check if dependencies are installed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing frontend dependencies..."
    pnpm install
fi

if [ ! -d "server/node_modules" ]; then
    echo "📦 Installing backend dependencies..."
    cd server && npm install && cd ..
fi

echo ""
echo "🔨 Building frontend for production..."

# Build the frontend
pnpm build

if [ $? -eq 0 ]; then
    echo "✅ Frontend build completed successfully!"
else
    echo "❌ Frontend build failed!"
    exit 1
fi

echo ""
echo "🚀 Starting production server..."

# Start the backend server which will serve the built frontend
cd server
echo "🌐 Production server starting on port 3001..."
echo "📍 Access your File Manager at: http://localhost:3001"
echo ""
echo "🛑 Press Ctrl+C to stop the server"
echo ""

# Run the production server
npm start
