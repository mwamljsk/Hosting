#!/bin/bash

# 🛑 Futuristic File Manager - Stop Script for Ubuntu
# This script stops both backend and frontend servers

echo "🛑 Stopping Futuristic File Manager..."

# Function to check if a process is running
is_running() {
    local pid=$1
    if kill -0 $pid 2>/dev/null; then
        return 0
    else
        return 1
    fi
}

# Stop servers using saved PIDs
if [ -f logs/backend.pid ]; then
    BACKEND_PID=$(cat logs/backend.pid)
    if is_running $BACKEND_PID; then
        echo "🔄 Stopping backend server (PID: $BACKEND_PID)..."
        kill $BACKEND_PID
        sleep 2
        if is_running $BACKEND_PID; then
            echo "🔨 Force stopping backend server..."
            kill -9 $BACKEND_PID
        fi
        echo "✅ Backend server stopped"
    else
        echo "ℹ️  Backend server was not running"
    fi
    rm -f logs/backend.pid
fi

if [ -f logs/frontend.pid ]; then
    FRONTEND_PID=$(cat logs/frontend.pid)
    if is_running $FRONTEND_PID; then
        echo "🔄 Stopping frontend server (PID: $FRONTEND_PID)..."
        kill $FRONTEND_PID
        sleep 2
        if is_running $FRONTEND_PID; then
            echo "🔨 Force stopping frontend server..."
            kill -9 $FRONTEND_PID
        fi
        echo "✅ Frontend server stopped"
    else
        echo "ℹ️  Frontend server was not running"
    fi
    rm -f logs/frontend.pid
fi

# Kill any remaining processes on the ports
echo "🧹 Cleaning up any remaining processes..."
sudo lsof -ti:3001 | xargs sudo kill -9 2>/dev/null || true
sudo lsof -ti:5173 | xargs sudo kill -9 2>/dev/null || true

echo ""
echo "✅ All servers stopped successfully!"
echo "🗂️  Log files preserved in logs/ directory"
