const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const archiver = require('archiver');
const unzipper = require('unzipper');
const chokidar = require('chokidar');
const { spawn } = require('child_process');
const si = require('systeminformation');
const mime = require('mime-types');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'dist')));

// Storage configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = req.body.path || '/tmp';
    fs.ensureDir(uploadPath)
      .then(() => cb(null, uploadPath))
      .catch(err => cb(err));
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 100 * 1024 * 1024 // 100MB limit
  }
});

// Security: Basic path validation to prevent directory traversal
function validatePath(inputPath) {
  const resolvedPath = path.resolve(inputPath);
  // Allow access to the entire system for this file manager
  return resolvedPath;
}

// File system operations
app.get('/api/files', async (req, res) => {
  try {
    const dirPath = req.query.path || process.cwd();
    const validatedPath = validatePath(dirPath);
    
    if (!await fs.pathExists(validatedPath)) {
      return res.status(404).json({ error: 'Directory not found' });
    }
    
    const items = await fs.readdir(validatedPath, { withFileTypes: true });
    const fileList = await Promise.all(items.map(async (item) => {
      const itemPath = path.join(validatedPath, item.name);
      const stats = await fs.stat(itemPath);
      
      return {
        name: item.name,
        path: itemPath,
        isDirectory: item.isDirectory(),
        size: item.isDirectory() ? 0 : stats.size,
        modified: stats.mtime,
        permissions: (stats.mode & 0o777).toString(8),
        extension: item.isDirectory() ? null : path.extname(item.name).toLowerCase(),
        mimeType: item.isDirectory() ? null : mime.lookup(item.name) || 'application/octet-stream'
      };
    }));
    
    res.json({
      currentPath: validatedPath,
      parent: path.dirname(validatedPath),
      files: fileList.sort((a, b) => {
        if (a.isDirectory && !b.isDirectory) return -1;
        if (!a.isDirectory && b.isDirectory) return 1;
        return a.name.localeCompare(b.name);
      })
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create directory
app.post('/api/mkdir', async (req, res) => {
  try {
    const { path: dirPath, name } = req.body;
    const newDirPath = path.join(validatePath(dirPath), name);
    await fs.ensureDir(newDirPath);
    res.json({ success: true, path: newDirPath });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create file
app.post('/api/create-file', async (req, res) => {
  try {
    const { path: dirPath, name, content = '' } = req.body;
    const newFilePath = path.join(validatePath(dirPath), name);
    await fs.writeFile(newFilePath, content);
    res.json({ success: true, path: newFilePath });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Rename file/directory
app.post('/api/rename', async (req, res) => {
  try {
    const { oldPath, newName } = req.body;
    const validatedOldPath = validatePath(oldPath);
    const newPath = path.join(path.dirname(validatedOldPath), newName);
    await fs.move(validatedOldPath, newPath);
    res.json({ success: true, newPath });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete file/directory
app.delete('/api/delete', async (req, res) => {
  try {
    const { path: itemPath } = req.body;
    const validatedPath = validatePath(itemPath);
    await fs.remove(validatedPath);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Move files/directories
app.post('/api/move', async (req, res) => {
  try {
    const { source, destination } = req.body;
    const validatedSource = validatePath(source);
    const validatedDestination = validatePath(destination);
    
    const targetPath = path.join(validatedDestination, path.basename(validatedSource));
    await fs.move(validatedSource, targetPath);
    res.json({ success: true, newPath: targetPath });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Copy files/directories
app.post('/api/copy', async (req, res) => {
  try {
    const { source, destination } = req.body;
    const validatedSource = validatePath(source);
    const validatedDestination = validatePath(destination);
    
    const targetPath = path.join(validatedDestination, path.basename(validatedSource));
    await fs.copy(validatedSource, targetPath);
    res.json({ success: true, newPath: targetPath });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Read file content
app.get('/api/file-content', async (req, res) => {
  try {
    const filePath = validatePath(req.query.path);
    const stats = await fs.stat(filePath);
    
    if (stats.isDirectory()) {
      return res.status(400).json({ error: 'Path is a directory' });
    }
    
    const mimeType = mime.lookup(filePath);
    
    // For text files, return content as text
    if (mimeType && mimeType.startsWith('text/') || 
        ['.json', '.js', '.css', '.html', '.xml', '.md', '.py', '.java', '.cpp', '.c', '.h'].includes(path.extname(filePath))) {
      const content = await fs.readFile(filePath, 'utf8');
      res.json({ 
        content, 
        mimeType,
        isText: true,
        size: stats.size 
      });
    } else {
      // For binary files, return file info only
      res.json({ 
        mimeType,
        isText: false,
        size: stats.size,
        url: `/api/download?path=${encodeURIComponent(filePath)}`
      });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Save file content
app.post('/api/save-file', async (req, res) => {
  try {
    const { path: filePath, content } = req.body;
    const validatedPath = validatePath(filePath);
    await fs.writeFile(validatedPath, content);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Upload files
app.post('/api/upload', upload.array('files'), async (req, res) => {
  try {
    const uploadedFiles = req.files.map(file => ({
      name: file.filename,
      path: file.path,
      size: file.size
    }));
    
    res.json({ 
      success: true, 
      files: uploadedFiles 
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Download files
app.get('/api/download', async (req, res) => {
  try {
    const filePath = validatePath(req.query.path);
    const stats = await fs.stat(filePath);
    
    if (stats.isDirectory()) {
      return res.status(400).json({ error: 'Cannot download directory directly' });
    }
    
    res.download(filePath);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create ZIP archive
app.post('/api/zip', async (req, res) => {
  try {
    const { paths, outputPath } = req.body;
    const validatedOutputPath = validatePath(outputPath);
    
    const output = fs.createWriteStream(validatedOutputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });
    
    output.on('close', () => {
      res.json({ 
        success: true, 
        path: validatedOutputPath,
        size: archive.pointer()
      });
    });
    
    archive.on('error', (err) => {
      throw err;
    });
    
    archive.pipe(output);
    
    for (const itemPath of paths) {
      const validatedPath = validatePath(itemPath);
      const stats = await fs.stat(validatedPath);
      const name = path.basename(validatedPath);
      
      if (stats.isDirectory()) {
        archive.directory(validatedPath, name);
      } else {
        archive.file(validatedPath, { name });
      }
    }
    
    await archive.finalize();
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Extract ZIP archive
app.post('/api/unzip', async (req, res) => {
  try {
    const { zipPath, extractPath } = req.body;
    const validatedZipPath = validatePath(zipPath);
    const validatedExtractPath = validatePath(extractPath);
    
    await fs.createReadStream(validatedZipPath)
      .pipe(unzipper.Extract({ path: validatedExtractPath }))
      .promise();
    
    res.json({ success: true, extractPath: validatedExtractPath });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// System information
app.get('/api/system-info', async (req, res) => {
  try {
    const [cpu, mem, fsSize, osInfo, time] = await Promise.all([
      si.currentLoad(),
      si.mem(),
      si.fsSize(),
      si.osInfo(),
      si.time()
    ]);
    
    res.json({
      cpu: {
        usage: cpu.currentLoad,
        cores: cpu.cpus.length
      },
      memory: {
        total: mem.total,
        free: mem.free,
        used: mem.used,
        usagePercent: (mem.used / mem.total) * 100
      },
      disk: fsSize.map(disk => ({
        fs: disk.fs,
        type: disk.type,
        size: disk.size,
        used: disk.used,
        available: disk.available,
        usagePercent: (disk.used / disk.size) * 100
      })),
      os: {
        platform: osInfo.platform,
        distro: osInfo.distro,
        release: osInfo.release,
        hostname: osInfo.hostname,
        uptime: time.uptime
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Socket.IO for real-time features
const terminals = new Map();

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);
  
  // Simplified terminal functionality
  socket.on('create-terminal', () => {
    try {
      socket.emit('terminal-ready');
      socket.emit('terminal-output', 'Welcome to Futuristic File Manager Terminal!\r\n');
      socket.emit('terminal-output', 'Type commands below (basic command execution supported):\r\n');
      socket.emit('terminal-output', '$ ');
    } catch (error) {
      socket.emit('terminal-error', error.message);
    }
  });
  
  socket.on('execute-command', (command) => {
    try {
      if (!command.trim()) {
        socket.emit('terminal-output', '\r\n$ ');
        return;
      }
      
      const args = command.trim().split(' ');
      const cmd = args[0];
      const cmdArgs = args.slice(1);
      
      socket.emit('terminal-output', `\r\n`);
      
      const child = spawn(cmd, cmdArgs, {
        cwd: process.cwd(),
        env: process.env
      });
      
      child.stdout.on('data', (data) => {
        socket.emit('terminal-output', data.toString());
      });
      
      child.stderr.on('data', (data) => {
        socket.emit('terminal-output', data.toString());
      });
      
      child.on('close', (code) => {
        socket.emit('terminal-output', `\r\n$ `);
      });
      
      child.on('error', (error) => {
        socket.emit('terminal-output', `Error: ${error.message}\r\n$ `);
      });
      
    } catch (error) {
      socket.emit('terminal-output', `Error: ${error.message}\r\n$ `);
    }
  });
  
  socket.on('terminal-resize', ({ cols, rows }) => {
    // Terminal resize is not needed for simplified version
  });
  
  // File watching for real-time updates
  socket.on('watch-directory', (dirPath) => {
    try {
      const validatedPath = validatePath(dirPath);
      const watcher = chokidar.watch(validatedPath, {
        ignored: /(^|[\/\\])\../, // ignore dotfiles
        persistent: true
      });
      
      watcher.on('all', (event, path) => {
        socket.emit('file-change', { event, path });
      });
      
      socket.on('disconnect', () => {
        watcher.close();
      });
    } catch (error) {
      socket.emit('watch-error', error.message);
    }
  });
  
  socket.on('disconnect', () => {
    terminals.delete(socket.id);
    console.log('Client disconnected:', socket.id);
  });
});

// Serve the React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'dist', 'index.html'));
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`🚀 File Manager Server running on port ${PORT}`);
  console.log(`📁 Root directory: ${process.cwd()}`);
});
