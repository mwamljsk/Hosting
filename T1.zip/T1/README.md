# 🚀 Futuristic File Manager

A stunning, modern web-based file manager with glassmorphism design and comprehensive functionality.

## ✨ Features

### 🎨 Modern Design
- **Glassmorphism UI**: Beautiful semi-transparent interface with backdrop blur effects
- **Dark/Light Theme**: Elegant theme switching with smooth transitions  
- **Responsive Design**: Works perfectly on desktop and mobile devices
- **Smooth Animations**: Powered by Framer Motion for fluid user experience

### 📁 File Management
- **Complete CRUD Operations**: Create, read, update, delete files and folders
- **Drag & Drop Upload**: Modern file upload with progress indicators
- **Batch Operations**: Multi-select files for bulk operations
- **File Preview**: View text, images, videos, and other file types
- **Download Support**: Direct file downloads with one click

### 💻 Code Editor
- **Monaco Editor**: Professional code editing with syntax highlighting
- **Multi-Language Support**: JavaScript, Python, HTML, CSS, and 100+ languages
- **Auto-Save**: Real-time file saving with modification indicators
- **Fullscreen Mode**: Distraction-free editing experience

### 🖥️ Terminal Interface
- **Live Terminal**: Execute shell commands with real-time output
- **Command History**: Navigate through previous commands
- **Responsive Design**: Works seamlessly across devices

### 📊 System Monitoring
- **Real-time Metrics**: CPU, memory, and disk usage monitoring
- **System Information**: OS details, uptime, and hardware specs
- **Auto-refresh**: Configurable real-time data updates

### 🗜️ Archive Operations
- **ZIP Creation**: Compress files and folders into archives
- **ZIP Extraction**: Extract archived content to specified locations
- **Bulk Compression**: Create archives from multiple selected items

## 🛠️ Technology Stack

### Frontend
- **React 18** with TypeScript for type-safe development
- **Vite** for fast development and optimized builds
- **TailwindCSS** for modern, responsive styling
- **Framer Motion** for smooth animations
- **Monaco Editor** for professional code editing
- **XTerm.js** for terminal emulation
- **React Hot Toast** for beautiful notifications

### Backend
- **Node.js** with Express for robust server functionality
- **Socket.IO** for real-time communication
- **Multer** for file upload handling
- **Archiver/Unzipper** for compression operations
- **Systeminformation** for system metrics
- **File System Extra** for enhanced file operations

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or pnpm package manager

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd futuristic-file-manager
```

2. **Install frontend dependencies**
```bash
pnpm install
```

3. **Install backend dependencies**
```bash
cd server
npm install
```

4. **Start the backend server**
```bash
cd server
npm start
```

5. **Build and serve the frontend**
```bash
pnpm run build
# Serve the dist folder with your preferred web server
```

### Development Mode

**Frontend Development:**
```bash
pnpm run dev
```

**Backend Development:**
```bash
cd server
npm run dev
```

## 📁 Project Structure

```
futuristic-file-manager/
├── src/                          # Frontend source code
│   ├── components/               # React components
│   │   ├── FileManager.tsx       # Main file manager interface
│   │   ├── FileList.tsx          # File listing with grid/list views
│   │   ├── CodeEditor.tsx        # Monaco-based code editor
│   │   ├── Terminal.tsx          # Terminal interface
│   │   ├── SystemMonitor.tsx     # System monitoring dashboard
│   │   ├── UploadModal.tsx       # File upload modal
│   │   ├── CreateModal.tsx       # File/folder creation modal
│   │   └── ContextMenu.tsx       # Right-click context menu
│   ├── contexts/                 # React contexts
│   │   └── ThemeContext.tsx      # Dark/light theme management
│   ├── hooks/                    # Custom React hooks
│   │   └── useFileManager.ts     # File operations hook
│   ├── utils/                    # Utility functions
│   │   └── formatters.ts         # File size, date formatting
│   └── types/                    # TypeScript type definitions
├── server/                       # Backend server code
│   ├── server.js                 # Main Express server
│   └── package.json              # Backend dependencies
├── dist/                         # Production build output
└── README.md                     # This file
```

## 🎯 API Endpoints

### File Operations
- `GET /api/files?path=<path>` - List files and directories
- `POST /api/create-file` - Create new file
- `POST /api/mkdir` - Create new directory
- `POST /api/rename` - Rename file/directory
- `DELETE /api/delete` - Delete file/directory
- `POST /api/move` - Move files/directories
- `POST /api/copy` - Copy files/directories

### File Content
- `GET /api/file-content?path=<path>` - Read file content
- `POST /api/save-file` - Save file content
- `POST /api/upload` - Upload files
- `GET /api/download?path=<path>` - Download file

### Archive Operations
- `POST /api/zip` - Create ZIP archive
- `POST /api/unzip` - Extract ZIP archive

### System Information
- `GET /api/system-info` - Get system metrics and information

### WebSocket Events
- `create-terminal` - Initialize terminal session
- `execute-command` - Execute shell command
- `terminal-output` - Receive command output
- `watch-directory` - Monitor directory changes

## 🔒 Security Features

- **Path Validation**: Prevents directory traversal attacks
- **Command Sanitization**: Safe terminal command execution
- **File Size Limits**: Configurable upload size restrictions
- **Error Handling**: Comprehensive error management

## 📱 Responsive Design

The application is fully responsive and works seamlessly across:
- **Desktop**: Full feature set with optimal layout
- **Tablet**: Touch-friendly interface with adaptive sizing
- **Mobile**: Optimized for small screens with essential features

## 🎨 Theme Customization

The application supports easy theme customization through:
- CSS custom properties for colors
- TailwindCSS configuration for design tokens
- Theme context for dynamic switching

## 🚀 Performance Optimizations

- **Code Splitting**: Lazy loading for optimal bundle sizes
- **Virtual Scrolling**: Efficient rendering of large file lists
- **Debounced Search**: Smooth file filtering
- **Memoized Components**: Optimized re-rendering

## 🧪 Testing

The application has been thoroughly tested for:
- ✅ Cross-browser compatibility
- ✅ Responsive design on all screen sizes
- ✅ File operation functionality
- ✅ Error handling and edge cases
- ✅ Performance under load

## 📄 License

MIT License - Feel free to use this project for personal or commercial purposes.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit pull requests or open issues for bugs and feature requests.

## 📞 Support

For support and questions, please open an issue in the repository.

---

**Built with ❤️ using modern web technologies**

Deploy URL: https://1yu6jtzusd.space.minimax.io
