#!/bin/bash

# 🚀 Futuristic File Manager - Startup Script for Ubuntu
# This script starts both backend and frontend servers

echo "🚀 Starting Futuristic File Manager..."

# Function to check if a port is in use
check_port() {
    local port=$1
    if lsof -Pi :$port -sTCP:LISTEN -t >/dev/null 2>&1; then
        return 0
    else
        return 1
    fi
}

# Kill any existing processes on ports 3001 and 5173
echo "🧹 Cleaning up existing processes..."
if check_port 3001; then
    echo "🔄 Stopping existing backend server on port 3001..."
    sudo lsof -ti:3001 | xargs sudo kill -9 2>/dev/null || true
fi

if check_port 5173; then
    echo "🔄 Stopping existing frontend server on port 5173..."
    sudo lsof -ti:5173 | xargs sudo kill -9 2>/dev/null || true
fi

# Wait a moment for ports to be released
sleep 2

# Create log directory
mkdir -p logs

echo ""
echo "🖥️  Starting backend server (Port 3001)..."

# Start backend server in background
cd server
nohup npm start > ../logs/backend.log 2>&1 &
BACKEND_PID=$!
cd ..

echo "⏳ Waiting for backend to start..."
sleep 3

# Check if backend started successfully
if check_port 3001; then
    echo "✅ Backend server started successfully on port 3001"
else
    echo "❌ Failed to start backend server. Check logs/backend.log for details."
    exit 1
fi

echo ""
echo "🌐 Starting frontend development server (Port 5173)..."

# Start frontend server in background
nohup pnpm dev > logs/frontend.log 2>&1 &
FRONTEND_PID=$!

echo "⏳ Waiting for frontend to start..."
sleep 5

# Check if frontend started successfully
if check_port 5173; then
    echo "✅ Frontend server started successfully on port 5173"
else
    echo "❌ Failed to start frontend server. Check logs/frontend.log for details."
    exit 1
fi

echo ""
echo "🎉 File Manager is now running!"
echo ""
echo "📍 Access your File Manager at:"
echo "   🌐 http://localhost:5173"
echo "   🌐 http://127.0.0.1:5173"
echo ""
echo "📊 Server Status:"
echo "   Backend:  http://localhost:3001 (PID: $BACKEND_PID)"
echo "   Frontend: http://localhost:5173 (PID: $FRONTEND_PID)"
echo ""
echo "📝 Logs:"
echo "   Backend:  tail -f logs/backend.log"
echo "   Frontend: tail -f logs/frontend.log"
echo ""
echo "🛑 To stop the servers:"
echo "   ./stop-filemanager.sh"
echo "   OR"
echo "   kill $BACKEND_PID $FRONTEND_PID"
echo ""

# Save PIDs for stop script
echo "$BACKEND_PID" > logs/backend.pid
echo "$FRONTEND_PID" > logs/frontend.pid

echo "✨ Enjoy your futuristic file management experience!"
echo ""

# Keep script running and monitor servers
echo "🔍 Monitoring servers (Press Ctrl+C to stop monitoring, servers will continue running)..."
while true; do
    if ! kill -0 $BACKEND_PID 2>/dev/null; then
        echo "⚠️  Backend server stopped unexpectedly!"
        break
    fi
    
    if ! kill -0 $FRONTEND_PID 2>/dev/null; then
        echo "⚠️  Frontend server stopped unexpectedly!"
        break
    fi
    
    sleep 10
done
