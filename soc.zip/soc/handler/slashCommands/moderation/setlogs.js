const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlog')
    .setDescription('Enable or disable specific logs and set their log channel.')
    .addStringOption(option =>
      option.setName('type')
        .setDescription('Select the type of log')
        .setRequired(true)
        .addChoices(
          { name: 'Ban Add', value: 'guildBanAdd' },
          { name: 'Ban Remove', value: 'guildBanRemove' },
          { name: 'Nickname Update', value: 'nicknameUpdate' },
          { name: 'Role Update', value: 'roleUpdate' }
        ))
    .addChannelOption(option =>
      option.setName('channel')
        .setDescription('Channel to send the logs to')
        .setRequired(true))
    .addBooleanOption(option =>
      option.setName('enable')
        .setDescription('Enable or disable this log')
        .setRequired(true)),

  run: async (client, interaction) => {
    const type = interaction.options.getString('type');
    const channel = interaction.options.getChannel('channel');
    const enable = interaction.options.getBoolean('enable');

    if (!interaction.member.permissions.has('ADMINISTRATOR')) {
      return interaction.reply({ content: 'You need administrator permission to use this command.', ephemeral: true });
    }

    // Fetch or initialize settings
    const guildId = interaction.guild.id;
    const data = await client.db18.get(guildId) || { logs: {} };

    data.logs[type] = {
      enabled: enable,
      channelId: channel.id
    };

    await client.db18.set(guildId, data);

    interaction.reply({
      content: `Log type \`${type}\` has been ${enable ? 'enabled' : 'disabled'} and will be sent to ${channel}.`,
      ephemeral: true
    });
  }
};