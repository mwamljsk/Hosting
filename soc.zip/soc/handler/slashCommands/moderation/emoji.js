const { SlashCommandBuilder } = require('@discordjs/builders');

const { EmbedBuilder } = require('discord.js');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('add-emoji')

        .setDescription('إضافة إيموجي إلى السيرفر')

        .addStringOption(option =>

            option.setName('emojis')

                .setDescription('الإيموجيات التي تريد إضافتها')

                .setRequired(true)),

    async execute(interaction) {

        const emojis = interaction.options.getString('emojis');

        const emojisInfo = emojis.match(/<(a?):(\w+):(\d+)>/g) || [];

        const addedEmojis = [];

        if (emojisInfo.length > 30) {

            const embed = new EmbedBuilder()

                .setColor(0xFF0000)

                .setDescription('❌ لا يمكنك إضافة أكثر من 30 إيموجي في رسالة واحدة.');

            await interaction.reply({ embeds: [embed] });

            return;

        }

        const maxEmojis = interaction.guild.premiumTier === 3 ? 500 : 50;

        const currentEmojis = interaction.guild.emojis.cache.size;

        const remainingSlots = maxEmojis - currentEmojis;

        if (remainingSlots <= 0) {

            const embed = new EmbedBuilder()

                .setColor(0xFF0000)

                .setDescription(`❌ لا يمكن إضافة المزيد من الإيموجيات. السيرفر ممتلئ!

                \nالإيموجيات الحالية: ${currentEmojis}/${maxEmojis}`);

            await interaction.reply({ embeds: [embed] });

            return;

        }

        let addedCount = 0;

        for (const emoji of emojisInfo) {

            const [, animated, name, id] = emoji.match(/<(a?):(\w+):(\d+)>/);

            const url = `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}`;

            

            if (addedCount >= remainingSlots) break;

            await interaction.guild.emojis.create({ attachment: url, name: name }).then((emoji) => {

                addedEmojis.push(emoji);

                addedCount++;

            });

        }

        const embed = new EmbedBuilder().setColor(0x888888);

        if (addedEmojis.length > 0) {

            embed.setDescription(

                `✅ تم إضافة ${addedEmojis.length} إيموجي بنجاح!  

                \nتم إضافة: ${addedEmojis.map((e) => e.toString()).join(' ')}  

                \nالإيموجيات الحالية: ${currentEmojis + addedEmojis.length}/${maxEmojis}`

            );

        } else {

            embed.setDescription('❌ لم يتم إضافة أي إيموجيات.');

        }

        await interaction.reply({ embeds: [embed] });

    },

};