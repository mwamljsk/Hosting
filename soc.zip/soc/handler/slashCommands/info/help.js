const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
const helpData = require('../../database/help.json'); // افترض أن هذا الملف موجود ويحتوي على بيانات المساعدة

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('عرض قائمة المساعدة للأوامر')
        .addStringOption(option =>
            option.setName('command')
                .setDescription('عرض تفاصيل أمر معين')
                .setRequired(false)
        ),
    async execute(message, args, client) { // في v13، يتم تمرير message و args و client
        const cmdName = args[0]; // يتم الحصول على اسم الأمر من الأرغومنت الأول
        const supportLink = "https://discord.gg/gwZunABahx";
        const inviteLink = "https://discord.com/api/oauth2/authorize?client_id=777502015999574036&permissions=8&scope=bot%20applications.commands";
        const dashboardLink = "http://5.9.12.94:15794/";
        const commandsList = "http://5.9.12.94:15794/commands";

        console.log(`Command requested: ${cmdName}`); // Debugging log

        if (cmdName) {
            const command = client.commands.get(cmdName);

            if (!command) {
                console.log(`Command not found: ${cmdName}`); // Debugging log
                return message.reply({
                    content: "❌ لم يتم العثور على هذا الأمر.",
                    ephemeral: true, // قد لا يكون هذا الخيار متاحًا في الرسائل العادية في v13
                });
            }

            if (!command.data) {
                console.log(`Command data not found for: ${cmdName}`); // Debugging log
                return message.reply({
                    content: "❌ لا توجد بيانات لهذا الأمر.",
                    ephemeral: true, // قد لا يكون هذا الخيار متاحًا في الرسائل العادية في v13
                });
            }

            const commandHelp = helpData[command.data.name]; // البحث عن بيانات المساعدة باستخدام اسم الأمر كمفتاح

            if (!commandHelp) {
                console.log(`Help data not found for command: ${command.data.name}`); // Debugging log
                return message.reply({
                    content: "❌ لا توجد معلومات مساعدة لهذا الأمر.",
                    ephemeral: true // قد لا يكون هذا الخيار متاحًا في الرسائل العادية في v13
                });
            }

            console.log(`Help data for command: ${command.data.name}`, commandHelp); // Debugging log

            const embed = new MessageEmbed() // استخدام MessageEmbed في v13
                .setColor(0x0099FF)
                .setTitle(`🔹 المساعدة لأمر: ${command.data.name}`)
                .setDescription(command.data.description || "لا يوجد وصف لهذا الأمر.")
                .addFields([
                    {
                        name: "📌 كيفية الاستخدام:",
                        value: commandHelp.usage || "❌ لا يوجد معلومات عن الاستخدام.",
                    },
                    {
                        name: "📝 أمثلة:",
                        value: commandHelp.examples || "❌ لا توجد أمثلة متاحة.",
                    },
                ]);

            return message.reply({ embeds: [embed] });

        } else {
            const row = new MessageActionRow() // استخدام MessageActionRow و MessageButton في v13
                .addComponents(
                    new MessageButton()
                        .setLabel("📌 أضف البوت إلى سيرفرك")
                        .setStyle(5) // LINK style
                        .setURL(inviteLink),
                    new MessageButton()
                        .setLabel("📊 لوحة التحكم")
                        .setStyle(5) // LINK style
                        .setURL(dashboardLink)
                );

            return message.reply({
                content: `**${message.guild.name}** prefix is \`/\`\n\n📜 **قائمة الأوامر:** <${commandsList}>\n📊 **لوحة التحكم:** <${dashboardLink}>\n❓ **الدعم الفني:** <${supportLink}>`,
                components: [row],
            });
        }
    },
};
