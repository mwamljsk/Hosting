const { MessageEmbed } = require("discord.js");

const createEmbed = (client, ID, added, allGuilds) => {
  const description = added
    ? `<a:arrow:904283126442897468> | ${added} no prefix to <@${ID}> for ${allGuilds ? 'all guilds' : 'this guild'}`
    : `<a:line:904281070680293426> | Already ${added ? 'added' : 'removed'} no prefix to <@${ID}> for ${allGuilds ? 'all guilds' : 'this guild'}`;

  return new MessageEmbed()
    .setColor("#2f3136")
    .setAuthor(client.user.tag, client.user.displayAvatarURL())
    .setDescription(description);
};
console.log(`Done`); 
module.exports = { createEmbed };
