const client = require("../index.js");
const { MessageEmbed } = require("discord.js");

client.on("guildBanAdd", async (ban) => {
  try {
    const { user, guild } = ban;
    if (!guild || user.bot) return;

    const premium = await client.db12.get(`${guild.id}_premium`);
    const data = await client.db18.get(guild.id);
    const config = data?.logs?.banAdd;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    let executor = null;
    let reason = "No reason provided.";
    try {
      const fetchedLogs = await guild.fetchAuditLogs({
        limit: 5,
        type: "MEMBER_BAN_ADD"
      });
      const banLog = fetchedLogs.entries.find(entry => entry.target.id === user.id);
      if (banLog) {
        executor = banLog.executor;
        reason = banLog.reason || reason;
      }
    } catch (err) {
      console.warn("Audit log fetch failed:", err);
    }

    if (premium?.active === true) {
      const embed = new MessageEmbed()
        .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL({ dynamic: true }) })
        .setTitle("**PREMIUM - Member Banned**")
        .addFields(
          { name: "User", value: `${user} (\`${user.id}\`)`, inline: true },
          { name: "Banned By", value: executor ? `${executor.tag} (\`${executor.id}\`)` : "Unknown", inline: true },
          { name: "Reason", value: reason, inline: false },
          { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
        )
        .setColor("GOLD")
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: "PREMIUM Logs", iconURL: guild.iconURL({ dynamic: true }) })
        .setTimestamp();

      await logChannel.send({ embeds: [embed] });

      // تخزين التفاصيل المتقدمة
      await client.db18.set(`bans.${guild.id}.${user.id}`, {
        userTag: user.tag,
        userId: user.id,
        executor: executor?.tag || "Unknown",
        executorId: executor?.id || null,
        reason,
        timestamp: Date.now()
      });

      // عداد الحظر
      const banCount = await client.db18.get(`banStats.${guild.id}.${executor?.id}`) || 0;
      await client.db18.set(`banStats.${guild.id}.${executor?.id}`, banCount + 1);

      if (banCount + 1 >= 5) {
        const alertEmbed = new MessageEmbed()
          .setTitle("**Anti-Raid Alert**")
          .setColor("DARK_RED")
          .setDescription(`User **${executor.tag}** has banned **${banCount + 1}** members within a short time.`)
          .addField("User ID", `\`${executor.id}\``, true)
          .addField("Recommended Action", "Check permissions or suspend the user.")
          .setTimestamp();

        if (config.alertChannelId) {
          const alertChannel = guild.channels.cache.get(config.alertChannelId);
          if (alertChannel?.isText()) {
            await alertChannel.send({ embeds: [alertEmbed] });
          }
        }
      }

    } else {
      // السيرفر العادي
      const embed = new MessageEmbed()
        .setTitle("Member Banned")
        .setDescription(`${user.tag} was banned.`)
        .addFields(
          { name: "User", value: `${user} (\`${user.id}\`)`, inline: true },
          { name: "Banned By", value: executor ? `${executor.tag}` : "Unknown", inline: true },
          { name: "Reason", value: reason }
        )
        .setColor("RED")
        .setTimestamp();

      await logChannel.send({ embeds: [embed] });
    }

  } catch (err) {
    console.error("Error in guildBanAdd:", err);
  }
});