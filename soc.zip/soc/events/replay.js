const client = require('../index.js');
const { EmbedBuilder } = require('discord.js');

client.on("messageCreate", async (message) => {
  if (message.author.bot || !message.guild) return;

  const guildId = message.guild.id;
  const content = message.content.toLowerCase().trim();
  const replies = await client.db22.get(`replay_${guildId}`) || [];

  if (!Array.isArray(replies) || replies.length === 0) return;

  for (const r of replies) {
    if (r.channelAllow?.length && !r.channelAllow.includes(message.channel.id)) continue;
    if (r.channelIgnore?.length && r.channelIgnore.includes(message.channel.id)) continue;

    const trigger = r.trigger?.toLowerCase().trim();
    if (!trigger) continue;

    if (content === trigger) {
      let response = r.response || "";

      // استبدال المتغيرات في الرد
      response = response
        .replace(/{user}/gi, `<@${message.author.id}>`)
        .replace(/{mention}/gi, `<@${message.author.id}>`)
        .replace(/{username}/gi, message.author.username)
        .replace(/{tag}/gi, message.author.tag)
        .replace(/{id}/gi, message.author.id)
        .replace(/{server}/gi, message.guild.name)
        .replace(/{channel}/gi, `<#${message.channel.id}>`)
        .replace(/{avatar}/gi, message.author.displayAvatarURL({ dynamic: true }));

      // أنواع الردود:
      const type = r.type || "normal"; // normal, embed, reply, both

      if (type === "embed" || type === "both") {
        const embed = new EmbedBuilder()
          .setDescription(response)
          .setColor(r.color || "#00FFFF")
          .setTimestamp();

        if (r.title) embed.setTitle(r.title);
        if (r.footer) embed.setFooter({ text: r.footer });
        if (r.image) embed.setImage(r.image);

        if (type === "embed") {
          await message.channel.send({
            embeds: [embed],
            allowedMentions: { repliedUser: false }
          });
        } else if (type === "both") {
          await message.reply({
            embeds: [embed],
            allowedMentions: { repliedUser: false }
          });
        }
      } else if (type === "reply") {
        await message.reply({
          content: `${response} ${r.emoji || ""}`.trim(),
          allowedMentions: { repliedUser: false }
        });
      } else {
        await message.channel.send({
          content: `${response} ${r.emoji || ""}`.trim(),
          allowedMentions: { repliedUser: false }
        });
      }
      
      break;
    }
  }
});