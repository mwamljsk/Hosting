// channelUpdate.js
const { MessageEmbed } = require('discord.js');
const client = require('../index.js');

client.on('channelUpdate', async (oldChannel, newChannel) => {
  if (!newChannel.guild) return;
  const data = await client.db18.get(newChannel.guild.id);
  const config = data?.logs?.channelUpdate;
  if (!config?.enabled || !config.channelId) return;

  const logCh = newChannel.guild.channels.cache.get(config.channelId);
  if (!logCh?.isText()) return;

  const fetchedLogs = await newChannel.guild.fetchAuditLogs({ type: 'CHANNEL_UPDATE', limit: 1 });
  const audit = fetchedLogs.entries.first();
  const executor = audit?.executor;

  const changes = [];

  if (oldChannel.name !== newChannel.name) {
    changes.push({ name: 'Name', old: oldChannel.name, new: newChannel.name });
  }

  if (oldChannel.topic !== newChannel.topic) {
    changes.push({ name: 'Topic', old: oldChannel.topic || 'None', new: newChannel.topic || 'None' });
  }

  if (oldChannel.nsfw !== newChannel.nsfw) {
    changes.push({ name: 'NSFW', old: oldChannel.nsfw ? 'Yes' : 'No', new: newChannel.nsfw ? 'Yes' : 'No' });
  }

  if (changes.length === 0) return; // Skip if no relevant changes

  const embed = new MessageEmbed()
    .setColor('ORANGE')
    .setTitle('Channel Updated')
    .setThumbnail(newChannel.guild.iconURL({ dynamic: true }))
    .addField('Channel', `<#${newChannel.id}> (${newChannel.name})`, true)
    .addField('Updated By', executor ? `${executor.tag}` : 'Unknown', true)
    .setFooter({ text: `Server: ${newChannel.guild.name}`, iconURL: newChannel.guild.iconURL() })
    .setTimestamp();

  if (executor?.avatarURL()) {
    embed.setAuthor({ name: `By: ${executor.tag}`, iconURL: executor.avatarURL({ dynamic: true }) });
  }

  for (const change of changes) {
    embed.addField(`${change.name} Changed`, `\`${change.old}\` ➔ \`${change.new}\``);
  }

  logCh.send({ embeds: [embed] });
});