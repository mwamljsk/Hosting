const client = require('../index.js');
const { MessageEmbed } = require('discord.js');
  client.on('inviteDelete', async (invite) => {
    const data = await client.db18.get(invite.guild.id);
    const config = data?.logs?.inviteDelete;
    if (!config?.enabled || !config.channelId) return;

    const logCh = invite.guild.channels.cache.get(config.channelId);
    if (!logCh?.isText()) return;

    const embed = new MessageEmbed()
      .setColor('RED')
      .setTitle('Invite Deleted')
      .addFields(
        { name: 'Code', value: invite.code, inline: true },
        { name: 'Channel', value: `<#${invite.channel?.id || 'Unknown'}>`, inline: true }
      )
      .setTimestamp();

    logCh.send({ embeds: [embed] });
  });
