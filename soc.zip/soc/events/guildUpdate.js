const client = require("../index.js");
const { MessageEmbed } = require("discord.js");

client.on("guildUpdate", async (oldGuild, newGuild) => {
  try {
    // تحقق من وجود القناة المسجلة في إعدادات السيرفر
    const data = await client.db18.get(newGuild.id);
    const config = data?.logs?.guildUpdate;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = newGuild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    // افحص التغييرات في السيرفر
    let changes = [];
    if (oldGuild.name !== newGuild.name) {
      changes.push(`Name changed from **${oldGuild.name}** to **${newGuild.name}**`);
    }
    if (oldGuild.iconURL() !== newGuild.iconURL()) {
      changes.push(`Icon updated`);
    }
    if (oldGuild.region !== newGuild.region) {
      changes.push(`Region changed from **${oldGuild.region}** to **${newGuild.region}**`);
    }
    if (oldGuild.verificationLevel !== newGuild.verificationLevel) {
      changes.push(`Verification level changed from **${oldGuild.verificationLevel}** to **${newGuild.verificationLevel}**`);
    }
    if (oldGuild.afkTimeout !== newGuild.afkTimeout) {
      changes.push(`AFK Timeout changed from **${oldGuild.afkTimeout / 60} minutes** to **${newGuild.afkTimeout / 60} minutes**`);
    }

    if (changes.length === 0) return; // إذا لم يكن هناك تغييرات لا ترسل رسالة

    let embed;

    // إذا كان السيرفر بريميوم، أضف المزيد من التفاصيل
    const premium = await client.db12.get(`${newGuild.id}_premium`);
    if (premium?.active) {
      embed = new MessageEmbed()
        .setTitle("**PREMIUM - Server Updated**")
        .setDescription(changes.join("\n"))
        .setColor("GOLD")
        .setThumbnail(newGuild.iconURL({ dynamic: true }))
        .setFooter({ text: "PREMIUM Logs", iconURL: newGuild.iconURL({ dynamic: true }) })
        .setTimestamp();
    } else {
      // في حالة السيرفر العادي، رسالته تكون أقل تفصيلاً
      embed = new MessageEmbed()
        .setTitle("Server Updated")
        .setDescription(changes.join("\n"))
        .setColor("BLUE")
        .setThumbnail(newGuild.iconURL({ dynamic: true }))
        .setFooter({ text: "Server Logs", iconURL: newGuild.iconURL({ dynamic: true }) })
        .setTimestamp();
    }

    // إرسال التغييرات إلى القناة
    await logChannel.send({ embeds: [embed] });

    // تخزين التحديثات إذا كان السيرفر بريميوم
    if (premium?.active) {
      await client.db18.set(`guildUpdates.${newGuild.id}`, {
        nameChange: oldGuild.name !== newGuild.name ? { from: oldGuild.name, to: newGuild.name } : null,
        iconChange: oldGuild.iconURL() !== newGuild.iconURL() ? { from: oldGuild.iconURL(), to: newGuild.iconURL() } : null,
        regionChange: oldGuild.region !== newGuild.region ? { from: oldGuild.region, to: newGuild.region } : null,
        verificationLevelChange: oldGuild.verificationLevel !== newGuild.verificationLevel ? { from: oldGuild.verificationLevel, to: newGuild.verificationLevel } : null,
        afkTimeoutChange: oldGuild.afkTimeout !== newGuild.afkTimeout ? { from: oldGuild.afkTimeout / 60, to: newGuild.afkTimeout / 60 } : null,
        timestamp: Date.now(),
      });
    }

  } catch (err) {
    console.error("Error in guildUpdate:", err);
  }
});