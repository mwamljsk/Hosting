const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

client.on("messageUpdate", async (oldMessage, newMessage) => {
  try {
    if (!oldMessage.guild || oldMessage.partial || oldMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;

    const premium = await client.db12.get(`${oldMessage.guild.id}_premium`);
    const data = await client.db18.get(oldMessage.guild.id);
    const config = data?.logs?.messageUpdate;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = oldMessage.guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    if (premium?.active === true) {
      const embed = new MessageEmbed()
        .setColor("ORANGE")
        .setAuthor({ name: oldMessage.author.tag, iconURL: oldMessage.author.displayAvatarURL({ dynamic: true }) })
        .setTitle("**PREMIUM - Message Edited**")
        .setDescription([
          `**Channel:** <#${oldMessage.channel.id}> (\`${oldMessage.channel.name}\`)`,
          `**Message ID:** \`${oldMessage.id}\``
        ].join('\n'))
        .addFields(
          { name: "Author", value: `${oldMessage.author} (\`${oldMessage.author.id}\`)`, inline: false },
          { name: "Old Content", value: oldMessage.content || "No content", inline: false },
          { name: "New Content", value: newMessage.content || "No content", inline: false },
          { name: "Edited At", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
        )
        .setThumbnail(oldMessage.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp()
        .setFooter({ text: `PREMIUM Logs | ${oldMessage.guild.name}`, iconURL: oldMessage.guild.iconURL({ dynamic: true }) });

      await logChannel.send({ embeds: [embed] });

    } else {
      const embed = new MessageEmbed()    
    .setColor("YELLOW")    
    .setTitle("Message Edited")    
    .addFields(    
      { name: "User", value: `${oldMessage.author.tag}`, inline: true },    
      { name: "Channel", value: `${oldMessage.channel}`, inline: true },    
      { name: "Old", value: oldMessage.content || "None" },    
      { name: "New", value: newMessage.content || "None" }    
    )    
    .setTimestamp();    

      await logChannel.send({ embeds: [embed] });
    }

  } catch (err) {
    console.error("Error in messageUpdate:", err);
  }
});