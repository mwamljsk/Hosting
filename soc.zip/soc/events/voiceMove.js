const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

client.on('voiceStateUpdate', async (oldState, newState) => {
  try {
    const guild = newState.guild;
    if (!guild) return;

    const premium = await client.db12.get(`${guild.id}_premium`);
    const data = await client.db18.get(guild.id);
    const config = data?.logs?.voiceMove;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    // إذا المستخدم تحرك من روم إلى روم (وليس ميوت أو انميوت)
    if (oldState.channelId !== newState.channelId && oldState.channel && newState.channel) {
      const member = newState.member;

      // بريميوم
      if (premium?.active === true) {
        const embed = new MessageEmbed()
          .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL({ dynamic: true }) })
          .setTitle("**PREMIUM - Voice Channel Moved**")
          .addFields(
            { name: "Member", value: `${member} (\`${member.id}\`)`, inline: true },
            { name: "From Channel", value: `${oldState.channel} (\`${oldState.channelId}\`)`, inline: true },
            { name: "To Channel", value: `${newState.channel} (\`${newState.channelId}\`)`, inline: true },
            { name: "Moved By Bot?", value: newState?.guild?.me?.voice?.channelId === newState.channelId ? "Yes (maybe)" : "No", inline: true },
            { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
          )
          .setColor("#3498db")
          .setFooter({ text: `PREMIUM Voice Logs | ${guild.name}`, iconURL: guild.iconURL({ dynamic: true }) })
          .setTimestamp();

        await logChannel.send({ embeds: [embed] });
      } else {
        // عادي
        const embed = new MessageEmbed()
          .setTitle("Voice Channel Moved")
          .setDescription(`${member} moved from <#${oldState.channelId}> to <#${newState.channelId}>`)
          .setColor("#2ecc71")
          .setTimestamp();

        await logChannel.send({ embeds: [embed] });
      }
    }
  } catch (err) {
    console.error("Error in voiceStateUpdate (voiceMove):", err);
  }
});