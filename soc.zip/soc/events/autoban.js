const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

client.on('guildMemberAdd', async (member) => {
  const guild = member.guild;
  const user = member.user;

  // فحص إذا موجود في قائمة الحظر التلقائي
  const key = `autoban_${guild.id}`;
  const autobanList = await client.db26.get(key) || [];

  if (!autobanList.includes(user.id)) return;

  try {
    await guild.members.ban(user.id, { reason: 'Auto-ban: User is in the auto-ban list.' });

    // إرسال رسالة لوق الحظر إن وجد
    const data = await client.db18.get(guild.id);
    const logSettings = data?.logs?.guildBanAdd;

    if (logSettings?.enabled && logSettings?.channelId) {
      const logChannel = guild.channels.cache.get(logSettings.channelId);
      if (logChannel && logChannel.isText()) {
        const time = new Date().toLocaleString('en-US', { timeZone: 'UTC', hour12: false });

        const embed = new MessageEmbed()
          .setTitle('Auto-Ban Executed')
          .setColor('DARK_RED')
          .setThumbnail(user.displayAvatarURL({ dynamic: true }))
          .addField('User', `${user.tag} (\`${user.id}\`)`, true)
          .addField('Reason', `Auto-ban list`)
          .addField('Time', `${time} UTC`)
          .setFooter(`Auto-ban triggered`)
          .setTimestamp();

        await logChannel.send({ embeds: [embed] });
      }
    }

  } catch (err) {
    console.error(`[AutoBan] Failed to ban user ${user.tag}:`, err);
  }
});