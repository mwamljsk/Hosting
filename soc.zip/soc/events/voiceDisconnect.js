const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

client.on('voiceStateUpdate', async (oldState, newState) => {
  try {
    const guild = newState.guild;
    if (!guild) return;

    const premium = await client.db12.get(`${guild.id}_premium`);
    const data = await client.db18.get(guild.id);
    const config = data?.logs?.voiceLeave;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    // إذا خرج من روم صوتي (old موجود وnew ما بيه channel)
    if (oldState.channel && !newState.channel) {
      const member = newState.member;

      if (premium?.active === true) {
        const embed = new MessageEmbed()
          .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL({ dynamic: true }) })
          .setTitle("**PREMIUM - Left Voice Channel**")
          .addFields(
            { name: "Member", value: `${member} (\`${member.id}\`)`, inline: true },
            { name: "Channel", value: `${oldState.channel} (\`${oldState.channelId}\`)`, inline: true },
            { name: "Bot?", value: member.user.bot ? "Yes" : "No", inline: true },
            { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
          )
          .setColor("#e74c3c")
          .setFooter({ text: `PREMIUM Voice Logs | ${guild.name}`, iconURL: guild.iconURL({ dynamic: true }) })
          .setTimestamp();

        await logChannel.send({ embeds: [embed] });
      } else {
        const embed = new MessageEmbed()
          .setTitle("Voice Channel Left")
          .setDescription(`${member} left <#${oldState.channelId}>`)
          .setColor("#e67e22")
          .setTimestamp();

        await logChannel.send({ embeds: [embed] });
      }
    }
  } catch (err) {
    console.error("Error in voiceStateUpdate (voiceLeave):", err);
  }
});