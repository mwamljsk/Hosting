const client = require('../index.js');
const { Collection } = require("discord.js");

const messageTimestamps = new Collection();
const muteDurations = new Map();

client.on("messageCreate", async (message) => {
  if (!message.guild || message.author.bot) return;

  const antispam = await client.db26.get(`${message.guild.id}_antispam`);
  if (!antispam?.enabled) return;

  const limit = 5; // messages
  const interval = 5000; // 5 seconds
  const userId = message.author.id;
  const now = Date.now();

  // Get or create Muted role
  let muteRole = message.guild.roles.cache.find(r => r.name === "Muted");
  if (!muteRole) {
    try {
      muteRole = await message.guild.roles.create({
        name: "Muted",
        color: "#000000",
        permissions: []
      });

      message.guild.channels.cache.forEach(async (channel) => {
        await channel.permissionOverwrites.edit(muteRole, {
          SEND_MESSAGES: false,
          ADD_REACTIONS: false,
          SPEAK: false
        });
      });
    } catch (err) {
      console.error("Failed to create Muted role:", err);
      return;
    }
  }

  // Store timestamps
  if (!messageTimestamps.has(userId)) {
    messageTimestamps.set(userId, []);
  }

  const timestamps = messageTimestamps.get(userId).filter(t => now - t < interval);
  timestamps.push(now);
  messageTimestamps.set(userId, timestamps);

  // If spam detected
  if (timestamps.length >= limit) {
    const previousDuration = muteDurations.get(userId) || 10 * 60 * 1000; // 10 minutes
    muteDurations.set(userId, previousDuration * 2); // double each time

    try {
      await message.member.roles.add(muteRole);
      await message.channel.send(`${message.author.tag} has been muted for ${previousDuration / 60000} minutes for spamming.`);

      setTimeout(async () => {
        if (message.member.roles.cache.has(muteRole.id)) {
          await message.member.roles.remove(muteRole);
        }
      }, previousDuration);
    } catch (err) {
      console.error("Failed to mute:", err);
    }

    messageTimestamps.set(userId, []); // Reset counter
  }
});