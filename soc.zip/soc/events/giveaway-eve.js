const client = require('../index.js');
const { MessageEmbed } = require('discord.js');
const emoji = require('../emoji.js');

setInterval(async () => {
  const allGiveaways = await client.db24.all();

  for (const giveaway of allGiveaways) {
    const data = giveaway.value;

    if (!data || !data.endTime || Date.now() < data.endTime) continue;

    const channel = await client.channels.fetch(data.channelId).catch(() => null);
    if (!channel || channel.type !== 'GUILD_TEXT') continue;

    const msg = await channel.messages.fetch(data.messageId).catch(() => null);
    if (!msg) continue;

    const reaction = msg.reactions.cache.find(r => r.emoji.name === emoji.reactions.party || r.emoji.toString() === emoji.reactions.party);
    if (!reaction) {
      console.log(`No reaction found for message ${msg.id}`);
      continue;
    }

    const users = await reaction.users.fetch().catch(() => null);
    if (!users || users.size === 0) {
      console.log(`No users reacted on message ${msg.id}`);
      continue;
    }

    const participants = users.filter(u => !u.bot);
    const uniqueParticipants = [...participants.keys()];

    if (uniqueParticipants.length === 0) {
      const noWinEmbed = new MessageEmbed()
        .setTitle(`${emoji.util.cross} Giveaway Ended`)
        .setColor('RED')
        .setDescription(`No one participated in the giveaway for **${data.prize}**.`)
        .setFooter({ text: `Giveaway ID: ${msg.id}` });

      await channel.send({ embeds: [noWinEmbed] });
      await client.db24.delete(`giveaway_${msg.id}`);
      continue;
    }

    const winners = [];
    for (let i = 0; i < data.winnerCount && uniqueParticipants.length > 0; i++) {
      const index = Math.floor(Math.random() * uniqueParticipants.length);
      const winnerId = uniqueParticipants.splice(index, 1)[0];
      winners.push(`<@${winnerId}>`);
    }

    const hostTag = await client.users.fetch(data.host).then(u => u.tag).catch(() => 'Unknown');

    const winEmbed = new MessageEmbed()
      .setTitle(`${emoji.fun.confetti} Giveaway Ended!`)
      .setColor('GREEN')
      .addFields(
        { name: 'Prize', value: data.prize, inline: true },
        { name: 'Winners', value: winners.join(', ') || 'None', inline: true }
      )
      .setFooter({ text: `Hosted by ${hostTag}` })
      .setTimestamp();

    await channel.send({ content: winners.join(', ') || 'No winners selected!', embeds: [winEmbed] });
    await client.db24.delete(`giveaway_${msg.id}`);
  }
}, 10 * 1000); // كل 10 ثواني