const client = require('../index.js');
const { MessageEmbed } = require('discord.js');
  client.on('messageUnpin', async (message) => {
    const data = await client.db18.get(message.guild.id);
    const config = data?.logs?.messageUnpin;
    if (!config?.enabled || !config.channelId) return;

    const logCh = message.guild.channels.cache.get(config.channelId);
    if (!logCh?.isText()) return;

    const embed = new MessageEmbed()
      .setColor('ORANGE')
      .setTitle('Message Unpinned')
      .addFields(
        { name: 'Message', value: message.content || 'No content', inline: true },
        { name: 'Channel', value: `<#${message.channel.id}>`, inline: true }
      )
      .setTimestamp();

    logCh.send({ embeds: [embed] });
  });
