const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

client.on("guildMemberUpdate", async (oldMember, newMember) => {
  const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
  const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));

  if (addedRoles.size === 0 && removedRoles.size === 0) return;

  const data = await client.db18.get(newMember.guild.id);
  const config = data?.logs?.roleUpdate;
  if (!config?.enabled || !config.channelId) return;

  const logChannel = newMember.guild.channels.cache.get(config.channelId);
  if (!logChannel || !logChannel.isText()) return;

  const embed = new MessageEmbed()
    .setColor("ORANGE")
    .setTitle("Roles Updated")
    .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
    .addField("User", `${newMember.user.tag} (\`${newMember.id}\`)`)
    .setTimestamp();

  if (addedRoles.size > 0)
    embed.addField("Added Roles", addedRoles.map(r => r.name).join(", "), false);

  if (removedRoles.size > 0)
    embed.addField("Removed Roles", removedRoles.map(r => r.name).join(", "), false);

  await logChannel.send({ embeds: [embed] });
});