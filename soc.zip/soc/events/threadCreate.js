const client = require('../index.js');
const { MessageEmbed } = require('discord.js');
  client.on('threadCreate', async (thread) => {
    const data = await client.db18.get(thread.guild.id);
    const config = data?.logs?.threadCreate;
    if (!config?.enabled || !config.channelId) return;

    const logCh = thread.guild.channels.cache.get(config.channelId);
    if (!logCh?.isText()) return;

    const embed = new MessageEmbed()
      .setColor('BLUE')
      .setTitle('Thread Created')
      .addFields(
        { name: 'Thread', value: thread.name, inline: true },
        { name: 'Channel', value: `<#${thread.parentId}>`, inline: true }
      )
      .setTimestamp();

    logCh.send({ embeds: [embed] });
  });