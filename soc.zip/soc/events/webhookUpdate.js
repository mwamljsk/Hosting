const client = require('../index.js');
const { MessageEmbed } = require('discord.js');
  client.on('webhookUpdate', async (channel) => {
    const data = await client.db18.get(channel.guild.id);
    const config = data?.logs?.webhookUpdate;
    if (!config?.enabled || !config.channelId) return;

    const logCh = channel.guild.channels.cache.get(config.channelId);
    if (!logCh?.isText()) return;

    const fetchedLogs = await channel.guild.fetchAuditLogs({ type: 'WEBHOOK_UPDATE', limit: 1 });
    const webhookLog = fetchedLogs.entries.first();
    const executor = webhookLog?.executor;

    const embed = new MessageEmbed()
      .setColor('BLUE')
      .setTitle('Webhook Updated')
      .addFields(
        { name: 'Channel', value: `<#${channel.id}>`, inline: true },
        { name: 'By', value: executor ? `${executor.tag}` : 'Unknown', inline: true }
      )
      .setTimestamp()
      .setFooter(channel.guild.name, channel.guild.iconURL({ dynamic: true }));

    logCh.send({ embeds: [embed] });
  });
