const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

client.on('voiceStateUpdate', async (oldState, newState) => {
  try {
    const guild = newState.guild;
    if (!guild) return;

    const premium = await client.db12.get(`${guild.id}_premium`);
    const data = await client.db18.get(guild.id);
    const config = data?.logs?.voiceDeafen;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    // تحقق من تغيير حالة الصم
    if (oldState.serverDeaf !== newState.serverDeaf) {
      const member = newState.member;

      if (premium?.active === true) {
        const embed = new MessageEmbed()
          .setAuthor({ name: member.user.tag, iconURL: member.user.displayAvatarURL({ dynamic: true }) })
          .setTitle("**PREMIUM - Voice Deafen State Changed**")
          .addFields(
            { name: "Member", value: `${member} (\`${member.id}\`)`, inline: true },
            { name: "Deafened", value: newState.serverDeaf ? "Yes" : "No", inline: true },
            { name: "Bot?", value: member.user.bot ? "Yes" : "No", inline: true },
            { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
          )
          .setColor(newState.serverDeaf ? "#e74c3c" : "#2ecc71")
          .setFooter({ text: `PREMIUM Voice Logs | ${guild.name}`, iconURL: guild.iconURL({ dynamic: true }) })
          .setTimestamp();

        await logChannel.send({ embeds: [embed] });
      } else {
        const embed = new MessageEmbed()
          .setTitle("Voice Deafen State Changed")
          .setDescription(`${member} is now ${newState.serverDeaf ? "deafened" : "undeafened"} in the voice channel.`)
          .setColor(newState.serverDeaf ? "#e74c3c" : "#2ecc71")
          .setTimestamp();

        await logChannel.send({ embeds: [embed] });
      }
    }
  } catch (err) {
    console.error("Error in voiceStateUpdate (voiceDeafen):", err);
  }
});