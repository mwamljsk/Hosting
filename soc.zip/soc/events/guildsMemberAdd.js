const client = require("../index.js");
const { MessageEmbed } = require("discord.js");

client.on("guildMemberAdd", async (member) => {
  try {
    const { user, guild } = member;
    if (!guild || user.bot) return;

    const premium = await client.db12.get(`${guild.id}_premium`);
    const data = await client.db18.get(guild.id);
    const config = data?.logs?.memberAdd;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    let embed;

    if (premium?.active) {
      // إذا كان السيرفر بريميوم، أضف المزيد من التفاصيل مثل الذي دعا العضو
      const invites = await guild.invites.fetch();
      const usedInvite = invites.find(invite => invite.uses > 0 && invite.inviter); // البحث عن الدعوة المستخدمة

      const inviter = usedInvite?.inviter || { tag: 'Unknown', avatarURL: () => null };
      const inviteCode = usedInvite?.code || 'Unknown';

      embed = new MessageEmbed()
        .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL({ dynamic: true }) })
        .setTitle("**PREMIUM - Member Joined**")
        .addFields(
          { name: "User", value: `[${user.tag}](https://discord.com/users/${user.id}) (\`${user.id}\`)`, inline: true },
          { name: "Invited By", value: `${inviter.tag} (\`${inviter.id}\`)`, inline: true },
          { name: "Invite Code", value: `https://discord.gg/${inviteCode}`, inline: true },
          { name: "Is Bot", value: user.bot ? "Yes" : "No", inline: true },
          { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
        )
        .setColor("GOLD")
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: "PREMIUM Logs", iconURL: guild.iconURL({ dynamic: true }) })
        .setTimestamp();
    } else {
      // إذا كان السيرفر عادي، فقط أدخل رسالة بسيطة
      embed = new MessageEmbed()
        .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL({ dynamic: true }) })
        .setTitle("Member Joined")
        .addField("User", `${user.tag} (\`${user.id}\`)`, true)
        .setColor("GREEN")
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: "Server Logs", iconURL: guild.iconURL({ dynamic: true }) })
        .setTimestamp();
    }

    await logChannel.send({ embeds: [embed] });

    // إذا كان السيرفر بريميوم، خزّن بيانات العضو في قاعدة البيانات
    if (premium?.active) {
      await client.db18.set(`joins.${guild.id}.${user.id}`, {
        userTag: user.tag,
        userId: user.id,
        inviterTag: usedInvite?.inviter?.tag || null,
        inviterId: usedInvite?.inviter?.id || null,
        inviteCode: usedInvite?.code || null,
        isBot: user.bot,
        timestamp: Date.now()
      });
    }

  } catch (err) {
    console.error("Error in guildMemberAdd:", err);
  }
});