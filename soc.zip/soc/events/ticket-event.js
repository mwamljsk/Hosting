const client = require('../index.js');
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const guild = interaction.guild;
  const user = interaction.user;

  // Check if the interaction is for opening a ticket
  if (interaction.customId === 'create_ticket') {
    const existingChannel = guild.channels.cache.find(c =>
      c.name === `ticket-${user.username}` // Change to ticket-username
    );

    if (existingChannel) {
      return interaction.reply({ content: 'You already have an open ticket!', ephemeral: true });
    }

    // Ensure the TICKETS category exists or create it if it doesn't
    let category = guild.channels.cache.find(c => c.name === "TICKETS" && c.type === 'GUILD_CATEGORY');
    if (!category) {
      category = await guild.channels.create('TICKETS', {
        type: 'GUILD_CATEGORY'
      });
    }

    // Create the ticket channel with ticket-username format
    const ticketChannel = await guild.channels.create(`ticket-${user.username}`, {
      type: 'GUILD_TEXT',
      parent: category.id,
      permissionOverwrites: [
        {
          id: guild.id,
          deny: ['VIEW_CHANNEL']
        },
        {
          id: user.id,
          allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'READ_MESSAGE_HISTORY']
        },
        {
          id: client.user.id,
          allow: ['VIEW_CHANNEL', 'SEND_MESSAGES', 'MANAGE_CHANNELS']
        }
      ]
    });

    await interaction.reply({ content: `Your ticket has been opened: <#${ticketChannel.id}>`, ephemeral: true });

    const welcomeEmbed = new MessageEmbed()
      .setColor('BLUE')
      .setTitle('New Ticket')
      .setDescription(`${user} Welcome!\nPlease describe your issue, and we'll assist you shortly.`);

    await ticketChannel.send({ content: `${user}`, embeds: [welcomeEmbed] });

    // Send buttons for closing, deleting, and reopening the ticket
    const actionRow = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('close_ticket')
          .setLabel('Close Ticket')
          .setStyle('DANGER'),
        new MessageButton()
          .setCustomId('delete_ticket')
          .setLabel('Delete Ticket')
          .setStyle('DANGER'),
        new MessageButton()
          .setCustomId('reopen_ticket')
          .setLabel('Reopen Ticket')
          .setStyle('SUCCESS')
      );

    await ticketChannel.send({ content: 'Choose an action:', components: [actionRow] });
  }

  // Handle closing the ticket
  if (interaction.customId === 'close_ticket') {
    const ticketChannel = interaction.channel;
    if (!ticketChannel.name.startsWith('ticket-')) return;

    const closeEmbed = new MessageEmbed()
      .setColor('RED')
      .setTitle('Ticket Closed')
      .setDescription('Your ticket has been closed. If you need further assistance, you can open a new ticket.');

    await ticketChannel.send({ embeds: [closeEmbed] });
    await ticketChannel.permissionOverwrites.edit(ticketChannel.guild.id, {
      VIEW_CHANNEL: false
    });

    // Hide the close button and show reopen & delete buttons
    const reopenAndDeleteRow = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('reopen_ticket')
          .setLabel('Reopen Ticket')
          .setStyle('SUCCESS'),
        new MessageButton()
          .setCustomId('delete_ticket')
          .setLabel('Delete Ticket')
          .setStyle('DANGER')
      );

    await interaction.reply({ content: 'The ticket has been closed.', ephemeral: true });
    await ticketChannel.send({ content: 'Choose an action:', components: [reopenAndDeleteRow] });
  }

  // Handle deleting the ticket
  if (interaction.customId === 'delete_ticket') {
    const ticketChannel = interaction.channel;
    if (!ticketChannel.name.startsWith('ticket-')) return;

    await ticketChannel.delete();
    await interaction.reply({ content: 'The ticket has been deleted.', ephemeral: true });
  }

  // Handle reopening the ticket
  if (interaction.customId === 'reopen_ticket') {
    const ticketChannel = interaction.channel;
    if (!ticketChannel.name.startsWith('ticket-')) return;

    const reopenEmbed = new MessageEmbed()
      .setColor('GREEN')
      .setTitle('Ticket Reopened')
      .setDescription('Your ticket has been reopened. You can now continue the conversation.');

    await ticketChannel.send({ embeds: [reopenEmbed] });
    await ticketChannel.permissionOverwrites.edit(ticketChannel.guild.id, {
      VIEW_CHANNEL: true
    });

    // Hide the reopen button and show the close button
    const closeRow = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('close_ticket')
          .setLabel('Close Ticket')
          .setStyle('DANGER'),
        new MessageButton()
          .setCustomId('delete_ticket')
          .setLabel('Delete Ticket')
          .setStyle('DANGER')
      );

    await interaction.reply({ content: 'The ticket has been reopened.', ephemeral: true });
    await ticketChannel.send({ components: [closeRow] });
  }
});