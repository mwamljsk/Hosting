const client = require("../index.js");
const { MessageEmbed } = require("discord.js");

client.on("guildMemberRemove", async (member) => {
  try {
    const { user, guild } = member;
    if (!guild || user.bot) return;

    const premium = await client.db12.get(`${guild.id}_premium`);
    const data = await client.db18.get(guild.id);
    const config = data?.logs?.memberRemove;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    const embed = new MessageEmbed()
      .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL({ dynamic: true }) })
      .setTitle(premium?.active ? "**PREMIUM - Member Left**" : "Member Left")
      .addFields(
        { name: "User", value: `[${user.tag}](https://discord.com/users/${user.id}) (\`${user.id}\`)`, inline: true },
        { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
      )
      .setColor(premium?.active ? "GREEN" : "BLUE")
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: premium?.active ? "PREMIUM Logs" : "Server Logs", iconURL: guild.iconURL({ dynamic: true }) })
      .setTimestamp();

    await logChannel.send({ embeds: [embed] });

    // If the server is premium, store the data
    if (premium?.active) {
      await client.db18.set(`leaves.${guild.id}.${user.id}`, {
        userTag: user.tag,
        userId: user.id,
        timestamp: Date.now()
      });
    }

  } catch (err) {
    console.error("Error in guildMemberRemove:", err);
  }
});

client.on("guildMemberKick", async (kick) => {
  try {
    const { user, guild, executor } = kick;
    if (!guild || user.bot) return;

    const premium = await client.db12.get(`${guild.id}_premium`);
    const data = await client.db18.get(guild.id);
    const config = data?.logs?.memberKick;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    const embed = new MessageEmbed()
      .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL({ dynamic: true }) })
      .setTitle(premium?.active ? "**PREMIUM - Member Kicked**" : "Member Kicked")
      .addFields(
        { name: "User", value: `[${user.tag}](https://discord.com/users/${user.id}) (\`${user.id}\`)`, inline: true },
        { name: "Kicked By", value: executor ? `[${executor.tag}](https://discord.com/users/${executor.id})` : "Unknown", inline: true },
        { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
      )
      .setColor(premium?.active ? "RED" : "ORANGE")
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: premium?.active ? "PREMIUM Logs" : "Server Logs", iconURL: guild.iconURL({ dynamic: true }) })
      .setTimestamp();

    await logChannel.send({ embeds: [embed] });

    // If the server is premium, store the data
    if (premium?.active) {
      await client.db18.set(`kicks.${guild.id}.${user.id}`, {
        userTag: user.tag,
        userId: user.id,
        executorTag: executor?.tag || null,
        executorId: executor?.id || null,
        timestamp: Date.now()
      });
    }

  } catch (err) {
    console.error("Error in guildMemberKick:", err);
  }
});