const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

client.on("messageDelete", async (message) => {
  try {
    if (!message.guild || message.partial || message.author?.bot) return;

    const premium = await client.db12.get(`${message.guild.id}_premium`);
    const data = await client.db18.get(message.guild.id);
    const config = data?.logs?.messageDelete;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = message.guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    // إذا السيرفر بريميوم
    if (premium?.active === true) {
      const embed = new MessageEmbed()
        .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
        .setTitle("**PREMIUM - Message Deleted**")
        .setDescription([
          `**Channel:** <#${message.channel.id}> (\`${message.channel.name}\`)`,
          `**Message ID:** \`${message.id}\``,
          message.channel.isThread() ? "**Thread Channel:** Yes" : ""
        ].filter(Boolean).join('\n'))
        .addFields(
          { name: "Author", value: `${message.author} (\`${message.author.id}\`)`, inline: false },
          { name: "Content", value: message.content || "No content", inline: false },
          { name: "Message Type", value: message.embeds.length > 0 ? "Embed" : message.attachments.size > 0 ? "Attachment" : "Text", inline: true },
          { name: "Has Links?", value: /https?:\/\//.test(message.content) ? "Yes" : "No", inline: true },
          { name: "Deleted At", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
        )
        .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
        .setTimestamp()
        .setFooter({ text: `PREMIUM Logs | ${message.guild.name}`, iconURL: message.guild.iconURL({ dynamic: true }) });

      if (message.attachments.size > 0) {
        const img = message.attachments.find(att => att.contentType?.startsWith('image/'));
        if (img) embed.setImage(img.url);
        else embed.addField("Attachments", message.attachments.map(a => a.url).join('\n'), false);
      }

      if (message.reference?.messageId) {
        try {
          const repliedMsg = await message.channel.messages.fetch(message.reference.messageId);
          embed.addField("Replied To", `[${repliedMsg.author.tag}]: ${repliedMsg.content?.slice(0, 100) || "Embed/Attachment"}`, false);
        } catch {
          embed.addField("Replied To", "Unable to fetch original replied message.", false);
        }
      }

      await logChannel.send({ embeds: [embed] });

      // حفظ نسخة في قاعدة البيانات
      await client.db18.set(`deletedMessages.${message.guild.id}.${message.id}`, {
        content: message.content || null,
        author: {
          tag: message.author.tag,
          id: message.author.id
        },
        channel: {
          id: message.channel.id,
          name: message.channel.name
        },
        timestamp: Date.now(),
        hasAttachment: message.attachments.size > 0,
        hasEmbed: message.embeds.length > 0,
        repliedTo: message.reference?.messageId || null
      });
    } else {
      // النسخة العادية إذا ما عنده بريميوم
      const embed = new MessageEmbed()
        .setTitle("Message Deleted")    
        .setDescription(`A message was deleted in <#${message.channel.id}>`)    
        .addField("Author", message.author.tag || "Unknown", true)    
        .addField("Content", message.content || "No content", false)    
        .addField("Deleted At", new Date().toISOString(), false)    
        .setTimestamp();
      await logChannel.send({ embeds: [embed] });    
    }
  } catch (err) {
    console.error("Error in messageDelete:", err);
  }
});