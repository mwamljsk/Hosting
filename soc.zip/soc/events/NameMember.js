const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

client.on("guildMemberUpdate", async (oldMember, newMember) => {
  if (oldMember.nickname === newMember.nickname) return;

  const data = await client.db18.get(newMember.guild.id);
  const config = data?.logs?.nicknameUpdate;
  if (!config?.enabled || !config.channelId) return;

  const logChannel = newMember.guild.channels.cache.get(config.channelId);
  if (!logChannel || !logChannel.isText()) return;

  const embed = new MessageEmbed()
    .setColor("BLUE")
    .setTitle("Nickname Changed")
    .setThumbnail(newMember.user.displayAvatarURL({ dynamic: true }))
    .addFields(
      { name: "User", value: `${newMember.user.tag} (\`${newMember.id}\`)`, inline: true },
      { name: "Old Nickname", value: oldMember.nickname || "None", inline: true },
      { name: "New Nickname", value: newMember.nickname || "None", inline: true }
    )
    .setTimestamp();

  await logChannel.send({ embeds: [embed] });
});