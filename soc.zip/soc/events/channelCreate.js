const client = require('../index.js');
// channelCreate.js
const { MessageEmbed } = require('discord.js');

  client.on('channelCreate', async (channel) => {
    if (!channel.guild) return;
    const data = await client.db18.get(channel.guild.id);
    const config = data?.logs?.channelCreate;
    if (!config?.enabled || !config.channelId) return;

    const logCh = channel.guild.channels.cache.get(config.channelId);
    if (!logCh?.isText()) return;

    const fetchedLogs = await channel.guild.fetchAuditLogs({ type: 'CHANNEL_CREATE', limit: 1 });
    const audit = fetchedLogs.entries.first();
    const executor = audit?.executor;

    const embed = new MessageEmbed()
      .setColor('GREEN')
      .setTitle('Channel Created')
      .setThumbnail(channel.guild.iconURL({ dynamic: true }))
      .addFields(
        { name: 'Channel', value: `<#${channel.id}> (${channel.name})`, inline: true },
        { name: 'Type', value: `${channel.type}`, inline: true },
        { name: 'Created By', value: executor ? `${executor.tag}` : 'Unknown', inline: true }
      )
      .setFooter({ text: `Server: ${channel.guild.name}`, iconURL: channel.guild.iconURL() })
      .setTimestamp();

    if (executor?.avatarURL()) embed.setAuthor({ name: `By: ${executor.tag}`, iconURL: executor.avatarURL({ dynamic: true }) });

    logCh.send({ embeds: [embed] });
  });
