const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    const mentionedUsers = message.mentions.users;
    if (mentionedUsers.size > 0) {
        mentionedUsers.forEach(async (user) => {
            const mentionedUserAfkData = await client.db13.get(`${user.id}_afk`);
            if (mentionedUserAfkData) {
                const afkDurationInSeconds = Math.floor((Date.now() - mentionedUserAfkData.time) / 1000);
                const afkDuration = formatDuration(afkDurationInSeconds);
                const sanitizedReason = sanitizeMentions(mentionedUserAfkData.reason);

                // حفظ الرسالة في قاعدة البيانات
                const log = {
                    content: message.content,
                    author: message.author.tag,
                    link: `https://discord.com/channels/${message.guild.id}/${message.channel.id}/${message.id}`,
                    timestamp: new Date().toISOString()
                };

                let storedLogs = await client.db13.get(`${user.id}_afk_messages`) || [];
                storedLogs.push(log);
                await client.db13.set(`${user.id}_afk_messages`, storedLogs);

                await message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor("RANDOM")
                            .setDescription(`**${user.tag}** went AFK for ${afkDuration}: ${sanitizedReason}`)
                    ]
                });
            }
        });
    }

    const authorAfkData = await client.db13.get(`${message.author.id}_afk`);
    if (authorAfkData) {
        const afkDurationInSeconds = Math.floor((Date.now() - authorAfkData.time) / 1000);
        const afkDuration = formatDuration(afkDurationInSeconds);

        await client.db13.delete(`${message.author.id}_afk`);

        const storedLogs = await client.db13.get(`${message.author.id}_afk_messages`) || [];

        const embed = new MessageEmbed()
            .setColor("BLUE")
            .setTitle(`Welcome back, ${message.author.username}!`)
            .setDescription(`You were AFK for ${afkDuration}. Here's what you missed:`)
            .setTimestamp();

        if (storedLogs.length > 0) {
            storedLogs.slice(-10).forEach((log, index) => {
                const time = new Date(log.timestamp).toLocaleTimeString();
                embed.addField(
                    `#${index + 1} [${time}]`,
                    `[${log.author}: Click here to go Message](${log.link})`
                );
            });
        } else {
            embed.setDescription(`You were AFK for ${afkDuration}, but no one mentioned you.`);
        }

        await message.channel.send({ content: `<@${message.author.id}>`, embeds: [embed] });

        await client.db13.delete(`${message.author.id}_afk_messages`);
    }
});

// أدوات مساعدة
function formatDuration(seconds) {
    const days = Math.floor(seconds / 86400);
    seconds -= days * 86400;
    const hours = Math.floor(seconds / 3600);
    seconds -= hours * 3600;
    const minutes = Math.floor(seconds / 60);
    seconds -= minutes * 60;

    let duration = '';
    if (days > 0) duration += `${days} day${days > 1 ? 's' : ''} `;
    if (hours > 0) duration += `${hours} hour${hours > 1 ? 's' : ''} `;
    if (minutes > 0) duration += `${minutes} minute${minutes > 1 ? 's' : ''} `;
    if (seconds > 0 || duration === '') duration += `${seconds} second${seconds !== 1 ? 's' : ''}`;

    return duration.trim();
}

function sanitizeMentions(text) {
    return text.replace(/@(everyone|here|&[0-9]+)/g, '');
}

function truncate(str, max) {
    return str.length > max ? str.slice(0, max - 3) + "..." : str;
}