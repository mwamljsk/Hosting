const client = require("../index.js");
const { MessageEmbed } = require("discord.js");

client.on("voiceStateUpdate", async (oldState, newState) => {
  try {
    // تحقق من وجود القناة المسجلة في إعدادات السيرفر
    const data = await client.db18.get(newState.guild.id);
    const config = data?.logs?.voiceMute;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = newState.guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    // تحقق إذا كان العضو تم تقييد صوته أو رفع تقييد الصوت
    if (oldState.serverMute !== newState.serverMute) {
      const user = newState.member;
      const executor = newState.guild.members.cache.get(newState.client.user.id);
      
      const premium = await client.db12.get(`${newState.guild.id}_premium`);
      let embed;

      // إذا كان تقييد الصوت
      if (newState.serverMute) {
        let reason = "No reason provided.";
        
        // محاولة جلب سبب التقييد من Audit Logs
        try {
          const fetchedLogs = await newState.guild.fetchAuditLogs({
            limit: 1,
            type: "MUTE_MEMBER",
          });
          const muteLog = fetchedLogs.entries.first();
          if (muteLog?.target?.id === user.id) {
            reason = muteLog.reason || reason;
          }
        } catch (err) {
          console.warn("Audit log fetch failed:", err);
        }

        // إنشاء الـ Embed
        embed = new MessageEmbed()
          .setTitle(premium?.active ? "**PREMIUM - Member Muted**" : "Member Muted")
          .setDescription(`${user.tag} (\`${user.id}\`) was muted.`)
          .addFields(
            { name: "Muted By", value: executor ? `${executor.tag} (\`${executor.id}\`)` : "Unknown", inline: true },
            { name: "Reason", value: reason, inline: false },
            { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
          )
          .setColor(premium?.active ? "GOLD" : "RED")
          .setThumbnail(user.displayAvatarURL({ dynamic: true }))
          .setFooter({ text: premium?.active ? "PREMIUM Logs" : "Server Logs", iconURL: newState.guild.iconURL({ dynamic: true }) })
          .setTimestamp();

        await logChannel.send({ embeds: [embed] });

        // إذا كان السيرفر بريميوم، خزّن معلومات الحظر في قاعدة البيانات
        if (premium?.active) {
          await client.db18.set(`voiceMute.${newState.guild.id}.${user.id}`, {
            userTag: user.tag,
            userId: user.id,
            executor: executor?.tag || null,
            executorId: executor?.id || null,
            reason,
            timestamp: Date.now(),
          });
        }
      } else {
        // إذا تم رفع تقييد الصوت
        embed = new MessageEmbed()
          .setTitle(premium?.active ? "**PREMIUM - Member Unmuted**" : "Member Unmuted")
          .setDescription(`${user.tag} (\`${user.id}\`) was unmuted.`)
          .addFields(
            { name: "Unmuted By", value: executor ? `${executor.tag} (\`${executor.id}\`)` : "Unknown", inline: true },
            { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
          )
          .setColor(premium?.active ? "GOLD" : "GREEN")
          .setThumbnail(user.displayAvatarURL({ dynamic: true }))
          .setFooter({ text: premium?.active ? "PREMIUM Logs" : "Server Logs", iconURL: newState.guild.iconURL({ dynamic: true }) })
          .setTimestamp();

        await logChannel.send({ embeds: [embed] });

        // إذا كان السيرفر بريميوم، خزّن معلومات رفع التقييد
        if (premium?.active) {
          await client.db18.set(`voiceUnmute.${newState.guild.id}.${user.id}`, {
            userTag: user.tag,
            userId: user.id,
            executor: executor?.tag || null,
            executorId: executor?.id || null,
            timestamp: Date.now(),
          });
        }
      }
    }
  } catch (err) {
    console.error("Error in voiceStateUpdate:", err);
  }
});