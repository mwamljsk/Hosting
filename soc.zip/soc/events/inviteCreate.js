const client = require('../index.js');
const { MessageEmbed } = require('discord.js');
  client.on('inviteCreate', async (invite) => {
    const data = await client.db18.get(invite.guild.id);
    const config = data?.logs?.inviteCreate;
    if (!config?.enabled || !config.channelId) return;

    const logCh = invite.guild.channels.cache.get(config.channelId);
    if (!logCh?.isText()) return;

    const embed = new MessageEmbed()
      .setColor('GREEN')
      .setTitle('Invite Created')
      .addFields(
        { name: 'Code', value: invite.code, inline: true },
        { name: 'Channel', value: `<#${invite.channel.id}>`, inline: true },
        { name: 'Inviter', value: invite.inviter ? `${invite.inviter.tag}` : 'Unknown', inline: true },
        { name: 'Max Uses', value: invite.maxUses ? `${invite.maxUses}` : 'Unlimited', inline: true },
        { name: 'Expires', value: invite.expiresAt ? `<t:${Math.floor(invite.expiresAt / 1000)}:R>` : 'Never', inline: true }
      )
      .setTimestamp();

    logCh.send({ embeds: [embed] });
  });
