const client = require("../index.js");
const { MessageEmbed } = require("discord.js");

client.on("guildBanRemove", async (ban) => {
  try {
    const { user, guild } = ban;
    if (!guild || user.bot) return;

    const premium = await client.db12.get(`${guild.id}_premium`);
    const data = await client.db18.get(guild.id);
    const config = data?.logs?.banRemove;
    if (!config?.enabled || !config.channelId) return;

    const logChannel = guild.channels.cache.get(config.channelId);
    if (!logChannel?.isText()) return;

    // Fetch audit log
    let executor = null;
    let reason = "No reason provided.";
    try {
      const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: "MEMBER_BAN_REMOVE" });
      const banLog = fetchedLogs.entries.find(entry => entry.target.id === user.id);
      if (banLog) {
        executor = banLog.executor;
        reason = banLog.reason || reason;
      }
    } catch (err) {
      console.warn("Failed to fetch audit log:", err);
    }

    // Build embed
    const embed = new MessageEmbed()
      .setAuthor({ name: user.tag, iconURL: user.displayAvatarURL({ dynamic: true }) })
      .setTitle(premium?.active ? "**PREMIUM - Member Unbanned**" : "Member Unbanned")
      .addFields(
        { name: "User", value: `[${user.tag}](https://discord.com/users/${user.id}) (\`${user.id}\`)`, inline: true },
        { name: "Unbanned By", value: executor ? `[${executor.tag}](https://discord.com/users/${executor.id})` : "Unknown", inline: true },
        { name: "Reason", value: reason, inline: false },
        { name: "Time", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
      )
      .setColor(premium?.active ? "GREEN" : "BLUE")
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: premium?.active ? "PREMIUM Logs" : "Server Logs", iconURL: guild.iconURL({ dynamic: true }) })
      .setTimestamp();

    await logChannel.send({ embeds: [embed] });

    // Store in database if premium
    if (premium?.active) {
      await client.db18.set(`unbans.${guild.id}.${user.id}`, {
        userTag: user.tag,
        userId: user.id,
        executorTag: executor?.tag || null,
        executorId: executor?.id || null,
        reason,
        timestamp: Date.now()
      });
    }

  } catch (err) {
    console.error("Error in guildBanRemove:", err);
  }
});