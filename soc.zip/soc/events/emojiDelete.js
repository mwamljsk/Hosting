const client = require('../index.js');
const { MessageEmbed } = require('discord.js');

  client.on('emojiDelete', async (emoji) => {
    const data = await client.db18.get(emoji.guild.id);
    const config = data?.logs?.emojiDelete;
    if (!config?.enabled || !config.channelId) return;

    const logCh = emoji.guild.channels.cache.get(config.channelId);
    if (!logCh?.isText()) return;

    const embed = new MessageEmbed()
      .setColor('RED')
      .setTitle('Emoji Deleted')
      .addFields(
        { name: 'Name', value: emoji.name, inline: true },
        { name: 'ID', value: emoji.id, inline: true }
      )
      .setTimestamp();

    logCh.send({ embeds: [embed] });
  });
