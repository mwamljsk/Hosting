const client = require('../index.js');
// roleCreate.js
const { MessageEmbed } = require('discord.js');


  client.on('roleCreate', async (role) => {
    const data = await client.db18.get(role.guild.id);
    const config = data?.logs?.roleCreate;
    if (!config?.enabled || !config.channelId) return;

    const logCh = role.guild.channels.cache.get(config.channelId);
    if (!logCh?.isText()) return;

    const fetchedLogs = await role.guild.fetchAuditLogs({ type: 'ROLE_CREATE', limit: 1 });
    const audit = fetchedLogs.entries.first();
    const executor = audit?.executor;

    const embed = new MessageEmbed()
      .setColor('GREEN')
      .setTitle('Role Created')
      .addFields(
        { name: 'Role', value: `${role.name}`, inline: true },
        { name: 'ID', value: role.id, inline: true },
        { name: 'Created By', value: executor ? `${executor.tag}` : 'Unknown', inline: true }
      )
      .setFooter({ text: `Server: ${role.guild.name}`, iconURL: role.guild.iconURL() })
      .setTimestamp();

    if (executor?.avatarURL()) embed.setAuthor({ name: `By: ${executor.tag}`, iconURL: executor.avatarURL({ dynamic: true }) });

    logCh.send({ embeds: [embed] });
  });

// emojiCreate.js

  client.on('emojiCreate', async (emoji) => {
    const data = await client.db18.get(emoji.guild.id);
    const config = data?.logs?.emojiCreate;
    if (!config?.enabled || !config.channelId) return;

    const logCh = emoji.guild.channels.cache.get(config.channelId);
    if (!logCh?.isText()) return;

    const fetchedLogs = await emoji.guild.fetchAuditLogs({ type: 'EMOJI_CREATE', limit: 1 });
    const audit = fetchedLogs.entries.first();
    const executor = audit?.executor;

    const embed = new MessageEmbed()
      .setColor('YELLOW')
      .setTitle('Emoji Created')
      .addFields(
        { name: 'Emoji', value: `${emoji}`, inline: true },
        { name: 'Name', value: emoji.name, inline: true },
        { name: 'Created By', value: executor ? `${executor.tag}` : 'Unknown', inline: true }
      )
      .setFooter({ text: `Server: ${emoji.guild.name}`, iconURL: emoji.guild.iconURL() })
      .setTimestamp();

    if (executor?.avatarURL()) embed.setAuthor({ name: `By: ${executor.tag}`, iconURL: executor.avatarURL({ dynamic: true }) });

    logCh.send({ embeds: [embed] });
  });
