//const { SlashCommandBuilder } = require('discord.js');
const { MessageEmbed } = require("discord.js");
const { SlashCommandBuilder } = require('@discordjs/builders');
const { inspect } = require("util");
const { EvalAccess } = require('../../owner.json');

module.exports = {

    data: new SlashCommandBuilder()

        .setName('setlogs')

        .setDescription('Setup different log channels.')

        .addSubcommand(subcommand =>

            subcommand

                .setName('deletemessage')

                .setDescription('Set the channel for deleted message logs.')

                .addChannelOption(option => option.setName('channel').setDescription('Select a channel').setRequired(true))

        )

        .addSubcommand(subcommand =>

            subcommand

                .setName('bans')

                .setDescription('Set the channel for ban logs.')

                .addChannelOption(option => option.setName('channel').setDescription('Select a channel').setRequired(true))

        )

        .addSubcommand(subcommand =>

            subcommand

                .setName('kick')

                .setDescription('Set the channel for kick logs.')

                .addChannelOption(option => option.setName('channel').setDescription('Select a channel').setRequired(true))

        )

        .addSubcommand(subcommand =>

            subcommand

                .setName('role')

                .setDescription('Set the channel for role changes logs.')

                .addChannelOption(option => option.setName('channel').setDescription('Select a channel').setRequired(true))

        ),

    async execute(interaction) {

        const channel = interaction.options.getChannel('channel');

        const subcommand = interaction.options.getSubcommand();

        await interaction.client.db17.set(`${interaction.guild.id}_log_${subcommand}`, channel.id);

        

        return interaction.reply({ content: `✅ Log channel for **${subcommand}** set to ${channel}!`, ephemeral: true });

    },

};