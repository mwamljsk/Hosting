// config.js أو الملف المناسب

module.exports = {

  ownerId: '544869116771696672',

  // باقي الإعدادات...

};