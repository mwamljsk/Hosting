module.exports = {
  
  reactions: {
    party: '<:vslgiveaway:1336616356438867968>'  
  },
  
  util: {
    clock: '⏰',
    cross: '<:redsmalldot:1337835169163509793>',
    info: '<:info:1336635560235892838>'
    
  },
  fun: {
    confetti: '🎊',
    gift: '<:vslgiveaway:1336616356438867968>'
  },
  id: {
    antinuke: "<:raidreport:1336615897862901760>",
    automod: "<:automod:1336618803324387388>",
    autorole: "<:insights:1336616232014712832>",
    moderation: "<:moderatororange:1336616056156061718>",
    customroles: "<:event:1336618449127870494>",
    vanityroles: "<:event:1336618449127870494>",
    voiceroles: "<:editor:1336636595532599306>",
    ignore: "<:join:1336618660206346250>",
    nightmode: "<:insights:1336616232014712832>",
    premium: "<:ownerbad:1336641514406805604>",
    media: "<:secguidefolder:1336640138968825899>",
    owner: "<:owner:1336615693189120062>",
    boost: "<:booster:1336615988887814195>",
    games: "<:gem:1336641843986956379>",
    welcome: "<:join:1336618660206346250>",
    leave: "<:leave:1336618638702149703>",
    nsfw: "<:stageg:1336616690292883478>",
    information: "<:info:1336635560235892838>",
    utility: "<:vslticket:1336616487292768367>",
    greet: "<:join:1336618660206346250>",
  },
  badges: {
    owner: "<:owner:1336615693189120062>",
    dev: "<:mod:1336636275779833896>",
    admin: "<:admin:1336029631391989791>",
    staff: "<:investigator:1336029619249348650>",
    partner: "<:partner_2:1336636116857782312>",
    supporter: "<:staffred:1337834468781723750>",
    sponsor: "<:managmentneon:1337835939715878912>",
    os: "<:mod:1336636275779833896>",
    vip: "<:vip:1336636065934479370>",
    friend: "<:discordinvite:1336641960051740716>",
    bug: "<:headadmin:1336642585204232233>",
  },
  util: {
    enabled: "<a:ssus:853028508769976350>",
    disabled: "<a:errors:853028674151383131>",
    enabler: "<:discordon:1336616310515175435>",
    disabler: "<a:Modretor:779986892564201473>",
    arrow: "<:redsmalldot:1337835169163509793>",
    tick: "<:saturn:1336628280836751360>",
    cross: "<a:error:853028465636933713>",
    loading: "<a:ttsloading:1336627679100670022>",
  },
  flag: {
    nitro: "<:nitro:1336615864127979530>",
    booster: "<:booster:1336615988887814195>",
    hypesquad: "",
    hype1: "",
    hype2: "",
    hype3: "",
    soc: "<:soc:1358085895403868242>",
    soc_2:"<:soc_so:1358085985262637429>",
    bug1: "<:headadmin:1336642585204232233>",
    bug2: "<:headadmin:1336642585204232233>",
    verifieddev: "<:verified:1336615824114581524>",
    partner: "<:MekoEarlySupporter:1258793928686043259>",
    activedev: "<:adminbadge:1336642226486509608>",
    verifiedbot: "<:verified:1336615824114581524>",
    staff: "<:discordstuff:1336616250222051368>",
  },
};
