const prefix = process.env.prefix || '/'
const status = `${prefix}help`;

module.exports = {
  bot: {
    info: {
      prefix: '*',
      token: 'Nzc3NTAyMDE1OTk5NTc0MDM2.GMJeXR.sBFumx2EpKFjMQwY1ktjuCG4X4giidPL25y5iA',
      invLink: 'https://discord.com/oauth2/authorize?client_id=777502015999574036',
      privacy: 'https://github.com/Policy.md',
      terms: 'https://github.com/Artions.md',
    },
    presence: {
      name: status,
      type: 'PLAYING',
     /* url: 'https://twitch.tv/pewdiepie'*/
    },
    credits: {
      developerId: '544869116771696672',
      supportServer: 'https://discord.gg/gwZunABahx'
    },
  }
}
