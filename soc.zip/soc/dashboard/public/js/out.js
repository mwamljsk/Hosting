document.addEventListener('DOMContentLoaded', () => {

    // الكود لفتح القوائم الجانبية عند الضغط

    const serverItems = document.querySelectorAll('.server-item');

    const serverDataSection = document.getElementById('server-data');

    const dataTableBody = document.querySelector('#data-table tbody');

    serverItems.forEach(item => {

        item.addEventListener('click', () => {

            const serverId = item.getAttribute('data-server-id');

            showServerData(serverId);

        });

    });

    function showServerData(serverId) {

        // إخفاء القسم عند اختيار سيرفر آخر

        serverDataSection.style.display = 'block';

        dataTableBody.innerHTML = ''; // مسح البيانات القديمة في الجدول

        // استدعاء بيانات السيرفر المحدد (هنا نقوم بتوليد بيانات افتراضية، يجب عليك استبدالها باستخدام API بوت ديسكورد)

        getServerData(serverId).then(data => {

            // ملأ الجدول بالبيانات

            data.forEach(user => {

                const row = document.createElement('tr');

                row.innerHTML = `

                    <td>${user.username}</td>

                    <td>${user.status}</td>

                    <td>${user.loginTime}</td>

                    <td>${user.logoutTime || 'N/A'}</td>

                `;

                dataTableBody.appendChild(row);

            });

        });

    }

    async function getServerData(serverId) {

        // هنا يتم استبدال هذه الوظيفة بتفاعل مع الـ API الخاص بالبوت لجلب بيانات السيرفر الحقيقية

        // في هذه الحالة نستخدم بيانات افتراضية لتوضيح الفكرة

        // بيانات افتراضية للمستخدمين

        const users = [

            {

                username: 'USER1',

                status: 'Online',

                loginTime: '2025-01-13 08:00:00',

                logoutTime: null

            },

            {

                username: 'USER2',

                status: 'Offline',

                loginTime: '2025-01-13 07:50:00',

                logoutTime: '2025-01-13 08:30:00'

            }

        ];

        // هذا هو المكان الذي تقوم فيه بكتابة الكود الفعلي لجلب البيانات من السيرفر باستخدام discord.js

        // مثال: عبر `client.guilds.cache.get(serverId)` لجلب السيرفر من البوت وتحليل البيانات

        return new Promise(resolve => {

            setTimeout(() => {

                resolve(users); // افتراضياً نرجع البيانات بعد 1 ثانية

            }, 1000);

        });

    }

});