document.addEventListener('DOMContentLoaded', () => {

    const menuToggle = document.getElementById('menu-toggle');

    const serverList = document.getElementById('server-list');

    menuToggle.addEventListener('click', () => {

        if (menuToggle.textContent === '☰') {

            menuToggle.textContent = '✕';

            serverList.style.display = 'block';

        } else {

            menuToggle.textContent = '☰';

            serverList.style.display = 'none';

        }

    });

});