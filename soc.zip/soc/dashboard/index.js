const express = require('express');

const session = require('express-session');
const passport = require('passport');
const router = express.Router();
const DiscordStrategy = require('passport-discord').Strategy;
//const db = require("../database");
const path = require('path');
const config = require('../config.json');

const Discord = require('discord.js');
const { MessageEmbed } = require('discord.js');
const SQLiteStore = require('connect-sqlite3')(session);
const bodyParser = require('body-parser');


/*const client = new Discord.Client({ intents: [
    Discord.Intents.FLAGS.GUILDS,
    Discord.Intents.FLAGS.GUILD_MESSAGES
] });*/
/*
const client = new Discord.Client({ 
    intents: [
        Discord.Intents.FLAGS.GUILDS, // لإدارة السيرفرات
        Discord.Intents.FLAGS.GUILD_MESSAGES, // لإدارة الرسائل
        Discord.Intents.FLAGS.GUILD_MEMBERS, // للحصول على بيانات الأعضاء
        Discord.Intents.FLAGS.GUILD_BANS, // لإدارة الحظر
        Discord.Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS, // لإدارة الإيموجي والملصقات
        Discord.Intents.FLAGS.GUILD_WEBHOOKS, // لإدارة الوِب هوكس
        Discord.Intents.FLAGS.GUILD_INVITES, // لإدارة الدعوات
        Discord.Intents.FLAGS.GUILD_VOICE_STATES, // لإدارة الصوت
        Discord.Intents.FLAGS.GUILD_PRESENCES // لمعرفة حالة الأعضاء
    ]
});
// إنشاء تطبيق Express
// استيراد كائن client الموحد من ملف تشغيل البوت
*/
const client = require('../index.js');


const app = express();
const fs = require('fs');
const db17 = client.db17;
const db19 = client.db19;
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
// مسار ملف logs.json

const logsPath = path.join(__dirname, 'logs.json');

// قراءة ملف logs.json

function readLogs() {

    if (!fs.existsSync(logsPath)) {

        fs.writeFileSync(logsPath, JSON.stringify({ guilds: {} }, null, 4));

    }

    return JSON.parse(fs.readFileSync(logsPath, 'utf8'));

}

// تحديث ملف logs.json

function updateLogs(data) {

    fs.writeFileSync(logsPath, JSON.stringify(data, null, 4));

}

// إضافة أو تحديث إعدادات اللوجات

function setLogChannel(guildId, channelId) {

    const logs = readLogs();

    logs.guilds[guildId] = { logChannelId: channelId };

    updateLogs(logs);

}

// جلب إعدادات اللوجات

function getLogChannel(guildId) {

    const logs = readLogs();

    return logs.guilds[guildId]?.logChannelId;

}

/*
client.on('messageDelete', async (message) => {

    if (message.author.bot) return; // تجاهل الرسائل من البوتات

    const guildId = message.guild.id;

    const logChannelId = getLogChannel(guildId);

    if (logChannelId) {

        const logChannel = message.guild.channels.cache.get(logChannelId);

        if (logChannel) {

            logChannel.send(`تم حذف رسالة من ${message.author.tag}:\n${message.content}`);

        }

    }

});*/


// إعداد الجلسة
/*
app.use(session({

    secret: 'Q1W2E3R4T5YUIOPALKJHGFDSZXCVBNM98765430uqieodnkmnbvcxzlpokjihuygtfrdeswaq',

    resave: false,

    saveUninitialized: false

}));
*/
// إعداد Passport

app.use(session({
  store: new SQLiteStore({
    // يمكنك تغيير المسار واسم الملف
    db: 'sessions.sqlite',
    dir: './database',
    table: 'sessions'
  }),
  secret: 'Q1W2E3R4T5YUIOPALKJHGFDSZXCVBNM98765430uqieodnkmnbvcxzlpokjihuygtfrdeswaq',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 7 * 24 * 60 * 60 * 1000,  // جلسة صالحة أسبوع كامل
    secure: false,                    // إذا كان لديك HTTPS، اجعلها true
    httpOnly: true
  }
}));

app.use(passport.initialize());
app.use(passport.session());
// إعداد Passport Strategy

passport.use(new DiscordStrategy({

    clientID: '777502015999574036',

    clientSecret: 'R8vt6JbiSN_2_32TE7auUvYA-dkUw3FJ',

    callbackURL: 'http://35.239.211.190/callback',

    scope: ['identify', 'guilds', 'email']

}, (accessToken, refreshToken, profile, done) => {

    process.nextTick(() => done(null, profile));

}));

// Serialize و Deserialize المستخدم

passport.serializeUser((user, done) => done(null, user));

passport.deserializeUser((obj, done) => done(null, obj));

// إعداد EJS لعرض الصفحات

app.set('view engine', 'ejs');

app.set('views', path.join(__dirname, 'views'));

// إعداد ملفات ثابتة (CSS, JS, etc.)

app.use(express.static(path.join(__dirname, 'public')));

// Middleware لتحديد backURL

app.get('/auth/login', (req, res, next) => {

    if (req.session.backURL) {

        req.session.backURL = req.session.backURL;

    } else if (req.headers.referer) {

        const parsed = url.parse(req.headers.referer);

        if (parsed.hostname === config.domain) {

            req.session.backURL = parsed.path;

        }

    } else {

        req.session.backURL = '/dash';

    }

    next();

}, passport.authenticate('discord'));







// استخدام SQLiteStore لحفظ الجلسات في ملف

// ... بقية الكود





// Callback Route

// قبل التعديل: app.get('/callback', passport.authenticate(...), (req, res) => { ... });

// بعد التعديل:
app.get('/callback',
  passport.authenticate('discord', {
    failureRedirect: '/error?code=999&message=AuthFailed'
  }),
  (req, res) => {
    // هنا يمكننا تسجيل دخول المستخدم نهائيًا
    // req.user الآن محفوظ في الجلسة
    const redirectTo = req.session.backURL || '/dash';
    delete req.session.backURL;   // ننظف الـ backURL بعد الاستخدام
    res.redirect(redirectTo);
  }
);

// الصفحة الرئيسية (Dashboard)
/*
app.get('/dash', async (req, res, client) => {
 if (!req.isAuthenticated()) return res.redirect('/login');
    //const db = client.db17;
    const user = req.user;
    const userId = user.id;
    //const balance = await client.db17.get(`balance_${userId}`) || 0;
    //const xp = await client.db19.get(`xp_${userId}`) || 0;
    //const rank = await client.db19.get(`rank_${userId}`) || "No Rank";
    const avatarURL = user.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
        : 'https://cdn.discordapp.com/embed/avatars/0.png'; // صورة افتراضية إذا لم يكن هناك avatar
    // الحصول على السيرفرات التي يمتلك المستخدم فيها صلاحية "Manage Server"
    const guilds = user.guilds.filter(guild => (guild.permissions & 0x20) === 0x20);
    // تمرير البيانات إلى ملف dash.ejs
    res.render('dash', {
        user: {
            username: user.username,
            avatarURL: avatarURL
        },
        guilds: guilds
    });
});



*/
/*
// في المسار /dash
// في المسار /dash
app.get('/dash', async (req, res) => {
    if (!req.isAuthenticated()) return res.redirect('/login');

    const user = req.user;
    const userId = user.id;
    const db17 = client.db17;
    const db19 = client.db19;
    const balance = await db17.get(`balance_${userId}`) || 0;
    const xp = await db19.get(`xp_${userId}`) || 0;
    const rank = await db19.get(`rank_${userId}`) || 0;
    const lvl = await db19.get(`level_${userId}`) || 0;
    const totalXp = lvl * 500;
    
    const avatarURL = user.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
        : 'https://cdn.discordapp.com/embed/avatars/0.png'; 
    
    // صورة افتراضية إذا لم يكن هناك avatar

    // الحصول على السيرفرات التي يمتلك المستخدم فيها صلاحية "Manage Server"
    const guilds = user.guilds.filter(guild => (guild.permissions & 0x20) === 0x20);

    // تمرير البيانات إلى ملف dash.ejs
    res.render('dash', {
        user: {
            username: user.username,
            avatarURL: avatarURL,
            balance: balance, 
            xp: xp, 
            rank: rank, 
            lvl: lvl, 
            totalXp: totalXp
        },
        guilds: guilds
    });
});
*/

app.get('/dash', async (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/login');

  const user = req.user;
  const userId = user.id;
  const db = client.db17;
    
  // بيانات المستخدم الأساسية
  const balance = await db.get(`balance_${userId}`) || 0;
  const xp = await client.db19.get(`xp_${userId}`) || 0;
  const rank = await client.db19.get(`rank_${userId}`) || 0;
  const lvl = await client.db19.get(`level_${userId}`) || 0;
  const totalXp = lvl * 500;
  const avatarURL = user.avatar
    ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
    : 'https://cdn.discordapp.com/embed/avatars/0.png';

  // آخر 5 معاملات
  const transactions = await db.get(`transactions_${userId}`) || [];

  // للحصول على اسم وصورة المستلم/المرسل لكل معاملة
  const detailedTx = await Promise.all(transactions.map(async tx => {
    const fromUser = await client.users.fetch(tx.from);
    const toUser   = await client.users.fetch(tx.to);
    return {
      id: tx.id,
      amount: tx.amount,
      date: tx.date,
      from: {
        id: tx.from,
        username: fromUser.username,
        avatarURL: fromUser.displayAvatarURL()
      },
      to: {
        id: tx.to,
        username: toUser.username,
        avatarURL: toUser.displayAvatarURL()
      }
    };
  }));

  // السيرفرات
  const guilds = user.guilds.filter(g => (g.permissions & 0x20) === 0x20);

  res.render('dash', {
    user: {
      id: userId,
      username: user.username,
      avatarURL,
      balance,
      xp,
      rank,
      lvl,
      totalXp
    },
    guilds,
    transactions: detailedTx 
  });
});



app.get('/transactions', async (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/login');

  const user = req.user;
  const userId = user.id;
  const db = client.db17;

  const transactions = await db.get(`transactions_${userId}`) || [];

  // الحصول على تفاصيل المعاملات
  const detailedTx = await Promise.all(transactions.map(async tx => {
    let fromUser, toUser;

    try {
      fromUser = await client.users.fetch(tx.from);
    } catch {
      fromUser = { username: 'مستخدم غير معروف', displayAvatarURL: () => 'https://cdn.discordapp.com/embed/avatars/1.png' };
    }

    try {
      toUser = await client.users.fetch(tx.to);
    } catch {
      toUser = { username: 'مستخدم غير معروف', displayAvatarURL: () => 'https://cdn.discordapp.com/embed/avatars/2.png' };
    }

    return {
      id: tx.id,
      amount: tx.amount,
      date: tx.date,
      from: {
        id: tx.from,
        username: fromUser.username,
        avatarURL: fromUser.displayAvatarURL()
      },
      to: {
        id: tx.to,
        username: toUser.username,
        avatarURL: toUser.displayAvatarURL()
      }
    };
  }));

  res.render('transactions', {
    user: {
      id: userId,
      username: user.username,
      avatar: user.avatar
    },
    transactions: detailedTx
  });
});



// صفحة الهدية اليومية
app.get('/daily', async (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/login');
  const user = req.user;
  const userId = req.user.id;
  const db17 = client.db17;
  const balance = await db17.get(`balance_${userId}`) || 0;
  const now = Date.now();

  // آخر وقت مطلِب (بمللي ثانية)
  let lastClaim = await client.db17.get(`dailySoc_${userId}`) || 0;

  // الفاصل الزمني المطلوب بين المطالبات (24 ساعة)
  const interval = 24 * 60 * 60 * 1000;
  const avatarURL = user.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
        : 'https://cdn.discordapp.com/embed/avatars/0.png'; 
  // الوقت المتبقي حتى الهدية القادمة
  const remaining = Math.max(0, interval - (now - lastClaim));

  res.render('daily', {
      user:{
    username: req.user.username,
    avatarURL: avatarURL, 
    balance: balance
      },
    balance: await client.db17.get(`balance_${userId}`) || 0,
    available: remaining === 0,
    remainingMs: remaining
  });
});

// معالجة طلب المطالبة بالهدية
app.post('/daily/claim', async (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/login');
  const user = req.user;
  const userId = req.user.id;
  const now = Date.now();
  const lastClaim = await client.db17.get(`dailySoc_${userId}`) || 0;
  const interval = 24 * 60 * 60 * 1000;

  if (now - lastClaim < interval) {
    // لم تنتهِ المدة بعد
    return res.redirect('/daily');
  }

    
  const reward = Math.floor(Math.random() * (5000 - 2000 + 1)) + 2000;
    const avatarURL = user.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
        : 'https://cdn.discordapp.com/embed/avatars/0.png';

  // تحديث الرصيد
  const current = await client.db17.get(`balance_${userId}`) || 0;
  await client.db17.set(`balance_${userId}`, current + reward);
    
  // تسجيل وقت المطالبة
  await client.db17.set(`dailySoc_${userId}`, now);

  res.redirect('/daily');
});

/*
app.get('/profile/:id', async (req, res) => {

    const userId = req.params.id;

    const balance = await client.db17.get(`balance_${userId}`) || 0;

    const xp = await client.db19.get(`xp_${userId}`) || 0;

    const rank = await client.db19.get(`rank_${userId}`) || "Unranked";

    res.json({

        id: userId,

        soc: balance,

        xp: xp,

        rank: rank

    });

});

*/

app.get('/login', (req, res) => {

    res.render('login');

});

app.get('/', (req, res) => {

       // if (!req.isAuthenticated()) return res.redirect('/login');

   // console.log(req.user); // تحقق من الكائن user

   // const guilds = req.user.guilds.filter(guild => (guild.permissions & 0x20) === 0x20);

    res.render('index', {

        //user: req.user,

        
    });

});

app.get('/servers', async (req, res) => {
    if (!req.isAuthenticated()) return res.redirect('/login');

    const user = req.user;
    const userId = user.id;
    const db17 = client.db17;
    const db19 = client.db19;
    const balance = await db17.get(`balance_${userId}`) || 0;
    const xp = await db19.get(`xp_${userId}`) || 0;
    const rank = await db19.get(`rank_${userId}`) || 0;
    const lvl = await db19.get(`level_${userId}`) || 0;
    const totalXp = lvl * 500;
   
    const avatarURL = user.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
        : 'https://cdn.discordapp.com/embed/avatars/0.png'; 
    
    // صورة افتراضية إذا لم يكن هناك avatar

    // الحصول على السيرفرات التي يمتلك المستخدم فيها صلاحية "Manage Server"
    const guildId = req.params.id;
    //const guilds = user.guilds.filter(guild => (guild.permissions & 0x20) === 0x20);
    
    const guilds = user.guilds.filter(guild => (guild.permissions & 0x20) === 0x20);
//const botGuild = client.guilds.cache.get(guilds.id);
// جهز كل سيرفر مع رابط الأيقونة (banner-style)
    /*
const preparedGuilds = guilds.map(guild => ({
  id: guild.id,
  name: guild.name,
  iconURL: guild.icon
    ? `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`
    : 'https://cdn.discordapp.com/embed/avatars/0.png'
    //,
   // memberCount: botGuild ? botGuild.memberCount : null
}));
    */
    const preparedGuilds = guilds.map(guild => {
  const botGuild = client.guilds.cache.get(guild.id);
  const botIsInGuild = !!botGuild;
  return {
    id: guild.id,
    name: guild.name,
    iconURL: guild.icon
      ? `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`
      : 'https://cdn.discordapp.com/embed/avatars/0.png',
    memberCount: botGuild ? botGuild.memberCount : null,
      botIn: botIsInGuild
  };
});
    //const guilds = req.user.guilds.find(g => g.id === guildId);
    /*const guildData = {
    id: guilds.id,
    name: guilds.name,
    iconURL: guilds.icon
      ? `https://cdn.discordapp.com/icons/${guilds.id}/${guilds.icon}.png`
      : 'https://cdn.discordapp.com/embed/avatars/0.png'
  };*/
  
    // تمرير البيانات إلى ملف server.ejs
    res.render('servers', {
        user: {
            username: user.username,
            avatarURL: avatarURL,
            balance: balance, 
            xp: xp, 
            rank: rank, 
            lvl: lvl, 
            totalXp: totalXp
        },
        gs: preparedGuilds
    });
});





app.get('/:id/overview', async (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/login');

  const guildId = req.params.id;
  const guild = req.user.guilds.find(g => g.id === guildId);

  if (!guild) return res.status(403).send('Unauthorized');

  const guildData = {
    id: guild.id,
    name: guild.name,
    iconURL: guild.icon
      ? `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`
      : 'https://cdn.discordapp.com/embed/avatars/0.png'
  };

  res.render('overview-servers', { guild: guildData });
});



app.get('/:guildId/commands/:category', (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/login');
    const user = req.user;
    const avatarURL = user.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
        : 'https://cdn.discordapp.com/embed/avatars/0.png'; 
  const guildId = req.params.guildId;
  const category = req.params.category; // general | admin | welcome | logs
  res.render('commands', { 
      user: {
            username: user.username,
            avatarURL: avatarURL,
        },
      guildId,
      category,
                         });
});

/*
app.get('/dash', (req, res) => {
        if (!req.isAuthenticated()) return res.redirect('/login');
    console.log(req.user); // تحقق من الكائن user
   
    const guilds = req.user.guilds.filter(guild => (guild.permissions & 0x20) === 0x20);
    res.render('index', {
        user: req.user,
        guilds: guilds
    });
}); 
*/

//
/*
app.get('/', (req, res) => {

    if (!req.isAuthenticated()) return res.redirect('/callback');

    console.log(req.user); // تحقق من الكائن user

    const guilds = req.user.guilds.filter(guild => (guild.permissions & 0x20) === 0x20);

    res.render('index', {

        user: req.user,

        guilds: guilds

    });

});
*/
// صفحة الأوامر

app.get('/commands', (req, res) => {

    if (!req.isAuthenticated()) return res.redirect('/login');

    // قائمة بالأوامر والشرح الخاص بها

    const commands = [

        { name: '*ping', description: 'يرجع "Pong!"' },

        { name: '*ban', description: 'يحظر عضو من السيرفر' },

        { name: '*kick', description: 'يطرد عضو من السيرفر' },

        // يمكنك إضافة المزيد من الأوامر هنا

    ];

    res.render('commands', {

        user: req.user,

        commands: commands

    });

});

// تسجيل الخروج
app.get('/logout', (req, res) => {
  // إنهاء الجلسة وإزالة بيانات المستخدم
  req.logout((err) => {
    if (err) {
      return next(err);
    }
    // إعادة التوجيه إلى الصفحة الرئيسية أو صفحة تسجيل الدخول بعد الخروج
    res.redirect('/');
  });
});

client.on('guildMemberAdd', member => {

    //console.log(`${member.user.tag} joined the server at ${new Date().toISOString()}`);

    // يمكنك هنا تخزين البيانات في قاعدة بيانات أو سجل خاص بك

});

client.on('guildMemberRemove', member => {

  //  console.log(`${member.user.tag} left the server at ${new Date().toISOString()}`);

    // يمكنك هنا تخزين البيانات في قاعدة بيانات أو سجل خاص بك

});

//invite
app.get('/invite', (req, res) => {
        res.redirect("https://discord.com/oauth2/authorize?client_id=777502015999574036&scope=bot+applications.commands+identify+guilds+applications.commands.permissions.update&response_type=code&permissions=2080374975"); 
}); 


app.get('/:guildId/overview', (req, res) => {
    const avatarURL = user.avatar

        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`

        : 'https://cdn.discordapp.com/embed/avatars/0.png'; // صورة افتراضية إذا لم يكن هناك avatar
    const guildId = req.params.guildId;
    res.render('overview', { guildId });

});


app.get('/:guildId/logs', async (req, res) => {

    if (!req.user) return res.redirect('/');

    const guildId = req.params.guildId;

    try {

        const guild = client.guilds.cache.get(guildId);

        if (!guild) return res.status(404).send('السيرفر غير موجود');

        await guild.channels.fetch(); // جلب القنوات

        const textChannels = guild.channels.cache

            .filter(channel => channel.isText()) // تصفية القنوات النصية فقط

            .map(channel => ({ id: channel.id, name: channel.name }));

        res.render('logs', { guildId, channels: textChannels });

    } catch (error) {

        console.error('Failed to fetch channels:', error);

        res.status(500).send('فشل في جلب القنوات');

    }

});


app.post('/:guildId/set-log-channel', (req, res) => {

    const guildId = req.params.guildId;

    const logChannelId = req.body.logChannel;

    setLogChannel(guildId, logChannelId);

    res.redirect(`/${guildId}/logs`);

});

const LOG_TYPES = [
  { key: 'messageDelete', name: 'Message Deleted' },
// { key: 'premiumMessageDelete', name: 'Premium MessageDelete' },
  { key: 'messageUpdate', name: 'Message Edited' },
  { key: 'guildBanAdd',    name: 'User Banned' },
  { key: 'guildBanRemove', name: 'User Unbanned' },
  { key: 'guildMemberUpdate', name: 'Guild Member Update' },
  { key: 'nicknameUpdate', name: 'Nickname Changed' },
  { key: 'roleUpdate',     name: 'Role Updated' },
  { key: 'roleCreate',     name: 'Role Create' },
  { key: 'emojiCreate',     name: 'Emoji Create' },
  { key: 'emojiDelete', name: 'Emoji Delete' },
  { key: 'inviteDelete', name: 'Invite Delete' },
  { key: 'inviteCreate', name: 'Invite Create' },
  { key: 'webhookUpdate', name: 'Webhook Update' },
  { key: 'voiceStateUpdate', name: 'Voice State Update' },
  { key: 'messagePin', name: 'Message Pin' },
  { key: 'messageUnpin', name: 'Message Unpin' },
  { key: 'guildUpdate', name: 'Guild Update' },
  { key: 'threadCreate', name: 'Thread Create' },
  { key: 'channelCreate', name: 'Channel Create' },
  { key: 'channelDelete', name: 'Channel Delete' },
  { key: 'channelUpdate', name: 'Channel Update' }, 
  { key: 'voiceMuteDeafen', name: 'Voice Mute Deafen' },
  { key: 'voiceMove', name: 'Voice Move' },
  { key: 'voiceDisconnect', name: 'Voice Disconnect' },
];

// GET: عرض صفحة الإعدادات
app.get('/:guildId/log', async (req, res) => {
    const user = req.user; // أو حسب النظام اللي تستخدمه لجلب بيانات المستخدم
  if (!user) return res.redirect('/login');
  const guildId = req.params.guildId;
  //const guild = client.guilds.cache.get(guildId);
// if (!guild) return res.status(404).send('Guild not found');
   
  const guild = client.guilds.cache.get(guildId);
    await guild.channels.fetch();
  //const guild = req.user.guilds.find(g => g.id === guildId);
  if (!guild) return res.status(403).send('Unauthorized');
  const guildData = {
    id: guild.id,
    name: guild.name,
    iconURL: guild.icon
      ? `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`
      : 'https://cdn.discordapp.com/embed/avatars/0.png'
  };

  // جلب القنوات النصية
  const textChannels = guild.channels.cache
    .filter(ch => ch.isText())
    .map(ch => ({ id: ch.id, name: ch.name }));

  const data = await client.db18.get(guildId) || {};
  const logs = data.logs || {};

  const config = LOG_TYPES.map(t => ({
    key: t.key,
    name: t.name,
    enabled: logs[t.key]?.enabled || false,
    channelId: logs[t.key]?.channelId || '',
  }));

  res.render('logs-settings', { 
      guildId, config, textChannels, guild: guildData, 
      user: {
      displayAvatarURL: () => user.displayAvatarURL, // إذا كانت دالة
      tag: user.tag }
                              });
});

app.post('/:guildId/log', async (req, res) => {
  const guildId = req.params.guildId;
  const body = req.body;
  const newLogs = {};

  LOG_TYPES.forEach(t => {
    newLogs[t.key] = {
      enabled: body[`${t.key}_enabled`] === 'on',
      channelId: body[`${t.key}_channelId`],
    };
  });

  const prev = await client.db18.get(guildId) || {};
  await client.db18.set(guildId, { ...prev, logs: newLogs });

  res.redirect(`/${guildId}/log`);
});

////////



//const moderator = require('./config/moderator.js');

app.get('/:guildId/moderator', async (req, res) => {
  const user = req.user;
  if (!user) return res.redirect('/login');

  const guildId = req.params.guildId;
  const guild = client.guilds.cache.get(guildId);
  if (!guild) return res.status(404).send('Guild not found');

  const textChannels = guild.channels.cache
    .filter(ch => ch.isText())
    .map(ch => ({ id: ch.id, name: ch.name }));

  const roles = guild.roles.cache
    .filter(r => r.name !== '@everyone')
    .map(r => ({ id: r.id, name: r.name }));

  const data = await client.db18.get(guildId) || {};
  const modSettings = data.moderator || {};
const moderator = require('./config/moderator.js');
    
  const config = moderator.map(cmd => ({
  key: cmd.key,
  name: cmd.name,
  enabled: modSettings[cmd.key]?.enabled ?? true,
  allowedChannels: modSettings[cmd.key]?.allowedChannels || [],
  ignoredChannels: modSettings[cmd.key]?.ignoredChannels || [],
  allowedRoles: modSettings[cmd.key]?.allowedRoles || [],
  aliases: modSettings[cmd.key]?.aliases || [],
}));

  res.render('moderator-settings', {
    guildId,
    config,
    textChannels,
    roles,
    guild,
    user: {
      displayAvatarURL: () => user.displayAvatarURL,
      tag: user.tag
    }
  });
});

app.post('/:guildId/moderator', async (req, res) => {
  const guildId = req.params.guildId;
  const body = req.body;

  const newSettings = {};
  const moderator = require('./config/moderator.js');
       // parseTagifyData يحول بيانات Tagify إلى Array
    const parseTagifyData = (data) => {
      try {
        const parsed = JSON.parse(data || '[]');
        return parsed.map(item => item.value);
      } catch {
        return [];
      }
    };

  moderator.forEach(cmd => {
  newSettings[cmd.key] = {
    enabled: body[`${cmd.key}_enabled`] === 'on',
    allowedChannels: Array.isArray(body[`${cmd.key}_allowedChannels`]) ? body[`${cmd.key}_allowedChannels`] : [body[`${cmd.key}_allowedChannels`]].filter(Boolean),
    ignoredChannels: Array.isArray(body[`${cmd.key}_ignoredChannels`]) ? body[`${cmd.key}_ignoredChannels`] : [body[`${cmd.key}_ignoredChannels`]].filter(Boolean),
    allowedRoles: Array.isArray(body[`${cmd.key}_allowedRoles`]) ? body[`${cmd.key}_allowedRoles`] : [body[`${cmd.key}_allowedRoles`]].filter(Boolean),
    aliases: body[`${cmd.key}_aliases`]
      ? body[`${cmd.key}_aliases`].split(',').map(a => a.trim()).filter(a => a !== '')
      : []
  };
});

  const prev = await client.db18.get(guildId) || {};
  await client.db18.set(guildId, {
    ...prev,
    moderator: newSettings,
  });

  res.redirect(`/${guildId}/moderator`);
});




  // عرض صفحة الردود
app.get("/:guildId/replay", async (req, res) => {
    if (!req.isAuthenticated()) return res.redirect('/login');
  const guildId = req.params.guildId;
  const guild = client.guilds.cache.get(guildId);
    await guild.channels.fetch();
  //const guild = req.user.guilds.find(g => g.id === guildId);
  if (!guild) return res.status(403).send('Unauthorized');
  const guildData = {
    id: guild.id,
    name: guild.name,
    iconURL: guild.icon
      ? `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png`
      : 'https://cdn.discordapp.com/embed/avatars/0.png'
  };
// const guildId = req.params.guildId;
// const guild = client.guilds.cache.get(guildId);
  //if (!guild) return res.send("Guild not found"); 
    const emojis = guild.emojis.cache.map(e => ({
  name: e.name,
  id: e.id,
  animated: e.animated
}));
    const textChannels = guild.channels.cache
  //.filter(c => c.type === 0 || c.type === 5) // 0: GUILD_TEXT, 5: ANNOUNCEMENT
   .filter(c => c.isText()) 
  .map(c => ({ id: c.id, name: c.name }));
    
    
  const data = await client.db22.get(`replay_${guildId}`) || [];
  res.render("replay", {
  guildId,
  channels: textChannels,
  replayData: data,
  guild: guildData,
  emojis
  });
});

  // إضافة رد جديد
  app.post("/:guildId/replay/add", async (req, res) => {
  const { guildId } = req.params;
  const { trigger, response, emoji, allowChannel, ignoreChannel, type, title, color, footer, image } = req.body;

  const all = await client.db22.get(`replay_${guildId}`) || [];

  const newEntry = {
    id: Date.now(),
    trigger: trigger?.trim() || "",
    response: response?.trim() || "",
    emoji: emoji || null,
    channelAllow: allowChannel ? allowChannel.split(",").map(x => x.trim()) : [],
    channelIgnore: ignoreChannel ? ignoreChannel.split(",").map(x => x.trim()) : [],
    type: type || "normal", // النوع (normal / embed / reply / both)
    title: title?.trim() || null,
    color: color?.trim() || "#00FFFF",
    footer: footer?.trim() || null,
    image: image?.trim() || null
  };

  all.push(newEntry);
  await client.db22.set(`replay_${guildId}`, all);

  res.redirect(`/${guildId}/replay`);
});

  // تعديل رد
  app.post("/:guildId/replay/edit/:id", async (req, res) => {
    const { guildId, id } = req.params;
    const { trigger, response, emoji, allowChannel, ignoreChannel } = req.body;

    const all = await client.db22.get(`replay_${guildId}`) || [];
    const index = all.findIndex(x => x.id == id);
    if (index !== -1) {
      all[index] = {
        ...all[index],
        trigger,
        response,
        emoji,
        channelAllow: allowChannel ? allowChannel.split(",").map(x => x.trim()) : [],
        channelIgnore: ignoreChannel ? ignoreChannel.split(",").map(x => x.trim()) : []
      };
      await client.db22.set(`replay_${guildId}`, all);
    }

    res.redirect(`/${guildId}/replay`);
  });

  // حذف رد
  app.post("/:guildId/replay/delete/:id", async (req, res) => {
    const { guildId, id } = req.params;

    const all = await client.db22.get(`replay_${guildId}`) || [];
    const filtered = all.filter(r => r.id != id);
    await client.db22.set(`replay_${guildId}`, filtered);

    res.redirect(`/${guildId}/replay`);
  });



////////



app.get('/:guildID/welcome', async (req, res) => {
  const guildID = req.params.guildID;
  const settings = db.get(`welcome_${guildID}`) || {};
  res.render('welcome', { guildID, settings });
});

// حفظ الإعدادات
app.post('/:guildID/welcome/save', async (req, res) => {
  const { bg, text, textX, textY, textSize, avatarX, avatarY, channel, message } = req.body;
  const guildID = req.params.guildID;

  client.db25.set(`welcome_${guildID}`, {
    bg,
    text,
    textX: parseInt(textX),
    textY: parseInt(textY),
    textSize: parseInt(textSize),
    avatarX: parseInt(avatarX),
    avatarY: parseInt(avatarY),
    channel,
    message
  });

  res.redirect(`/${guildID}/welcome`);
});

// إرسال صورة الترحيب عند انضمام عضو جديد

  

/*
  // List 
  app.get('/:guildId/replay', async (req, res) => {
    const { guildId } = req.params;
    //const guildId = req.params.guildId;       
    const guild = client.guilds.cache.get(guildId);
    //if (!guild) return res.status(404).send('السيرفر غير موجود');
       await guild.channels.fetch(); // جلب القنوات
       const textChannels = guild.channels.cache
            .filter(channel => channel.isText()) // تصفية القنوات النصية فقط
            .map(channel => ({ id: channel.id, name: channel.name }));
      
   // const { guildId } = req.params;
    //const guild = client.guilds.cache.get(guildId);
   // if (!guild) return res.status(404).send('Guild not found');

    // text & announcement channels
    //const channels = guild.channels.cache
   //   .filter(c => c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement)
    //  .map(c => ({ id: c.id, name: c.name }));

    // all custom emojis
    const emojis = guild.emojis.cache.map(e => ({
      id: e.id,
      name: e.name,
      animated: e.animated
    }));

    // saved replies
    const replayData = await client.db22.get(`replay_${guildId}`) || [];

    // your user info (adjust as you like)
    const userProfile = {
      username: req.user?.username || 'Unknown',
      image: req.user?.avatarURL() || '/default-avatar.png',
      level: req.user?.level || 1,
      rank: req.user?.rank || 'Member'
    };

    res.render('replay', { guildId, channels: textChannels, emojis, replayData, userProfile });
  });

  // Add new reply
  app.post('/:guildId/replay/add', async (req, res) => {
    const { guildId } = req.params;
    const { trigger, response, channel } = req.body;

    const list = await client.db22.get(`replay_${guildId}`) || [];
    list.push({
      id: Date.now().toString(),
      trigger,
      response,
      channelId: channel || null
    });
    await client.db22.set(`replay_${guildId}`, list);
    res.redirect(`/${guildId}/replay`);
  });

  // Delete
  app.post('/:guildId/replay/delete/:id', async (req, res) => {
    const { guildId, id } = req.params;
    let list = await client.db22.get(`replay_${guildId}`) || [];
    list = list.filter(r => r.id !== id);
    await client.db22.set(`replay_${guildId}`, list);
    res.redirect(`/${guildId}/replay`);
  });

  // Edit
  app.post('/:guildId/replay/edit/:id', async (req, res) => {
    const { guildId, id } = req.params;
    const { trigger, response, channel } = req.body;

    const list = await client.db22.get(`replay_${guildId}`) || [];
    const idx = list.findIndex(r => r.id === id);
    if (idx === -1) return res.status(404).send('Entry not found');

    list[idx] = {
      ...list[idx],
      trigger,
      response,
      channelId: channel || null
    };
    await client.db22.set(`replay_${guildId}`, list);
    res.redirect(`/${guildId}/replay`);
  });
*/
/*
// routes/api.js
router.get("/balance/:id", async (req, res) => {

  const db = require("../database");
  const userId = req.params.id;

  const balance = await db.get(`balance_${userId}`) || 0;

  res.json({ balance });

});


const apiRoutes = require("./routes/api");

app.use("/api", apiRoutes);





router.post("/gift/:id", async (req, res) => {
  const db = require("../database");
  const userId = req.params.id;

  const lastClaim = await db.get(`last_gift_${userId}`) || 0;

  const now = Date.now();

  if (now - lastClaim < 24 * 60 * 60 * 1000) {

    return res.status(400).json({ message: "لقد استلمت هديتك اليوم بالفعل." });

  }

  const giftAmount = 100;

  const currentBalance = await db.get(`balance_${userId}`) || 0;

  await db.set(`balance_${userId}`, currentBalance + giftAmount);

  await db.set(`last_gift_${userId}`, now);

  res.json({ message: `تم إضافة ${giftAmount}$ لحسابك!`, newBalance: currentBalance + giftAmount });

});

*/

//profile
app.get('/profile/:id', async (req, res) => {
    const userId = req.params.id;

    try {
        const soc = await db17.get(`balance_${userId}`) || 0;
        const xp = await db17.get(`xp_${userId}`) || 0;
        const rank = await db19.get(`rank_${userId}`) || 0;

        res.json({ soc });
    } catch (error) {
        console.error('Error fetching user data:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});


//تشغيل الخادم
app.listen(80, () => {

    console.log(`Dashboard running on port 15794`);

});