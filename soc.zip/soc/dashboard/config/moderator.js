// config/moderator.js
const moderator = [
  { key: 'ban', name: 'Ban', aliases: [] },
  { key: 'kick', name: 'Kick', aliases: [] },
  { key: 'mute', name: 'Mute', aliases: [] },
  { key: 'unmute', name: 'Unmute', aliases: [] },
  { key: 'unban', name: 'Unban', aliases: [] },
];

module.exports = moderator;