const { MessageEmbed } = require("discord.js");
const emoji = require("../../emoji.js");

module.exports = {
  name: "autobanlist",
  category: "moderation",
  UserPerms: ["ADMINISTRATOR"],
  run: async (client, message) => {
    const key = `autoban_${message.guild.id}`;
    const bannedList = await client.db26.get(key) || [];

    if (bannedList.length === 0) {
      return message.channel.send(`${emoji.util.info} | The auto-ban list is currently empty.`);
    }

    let listText = "";
    for (const id of bannedList) {
      try {
        const user = await client.users.fetch(id);
        listText += `• \`${user.tag}\` (\`${user.id}\`)\n`;
      } catch {
        listText += `• Unknown User (\`${id}\`)\n`;
      }
    }

    const embed = new MessageEmbed()
      .setTitle("Auto-Ban List")
      .setColor("ORANGE")
      .setDescription(listText.length ? listText : "No users in the list.");

    message.channel.send({ embeds: [embed] });
  }
};