const { MessageEmbed } = require('discord.js');
const ms = require('ms'); // تأكد من تثبيتها بـ npm i ms
const emoji = require('../../emoji.js');

module.exports = {
  name: 'giveaway',
  category: 'giveaways',
  UserPerms: ['MANAGE_MESSAGES'],
  usage: 'giveaway <duration> <winners> <prize>',

  run: async (client, message, args) => {
    const duration = args[0];
    const winnerCount = parseInt(args[1]);
    const prize = args.slice(2).join(' ');

    if (!duration || !ms(duration)) {
      return message.channel.send(`${emoji.util.cross} | Please provide a valid duration (e.g., \`1h\`, \`2d\`, \`30m\`).`);
    }

    if (isNaN(winnerCount) || winnerCount < 1) {
      return message.channel.send(`${emoji.util.cross} | Please provide a valid number of winners.`);
    }

    if (!prize) {
      return message.channel.send(`${emoji.util.cross} | Please provide a prize (e.g., \`Nitro\`).`);
    }

    const endTime = Date.now() + ms(duration);

    const embed = new MessageEmbed()
      .setTitle(`${emoji.fun.gift} ${prize}`)
      .setDescription(`React with ${emoji.reactions.party} to enter!\n**Winners:** ${winnerCount}\n**Ends:** <t:${Math.floor(endTime / 1000)}:R>`)
      .setColor('BLUE')
      .setFooter({ text: `Giveaway started by ${message.author.tag}` });

    const giveawayMsg = await message.channel.send({ embeds: [embed] });
    await giveawayMsg.react(emoji.reactions.party);

    // حفظ البيانات
    await client.db24.set(`giveaway_${giveawayMsg.id}`, {
      messageId: giveawayMsg.id,
      channelId: message.channel.id,
      guildId: message.guild.id,
      prize: prize,
      winnerCount: winnerCount,
      startTime: Date.now(),
      endTime: endTime,
      host: message.author.id
    });
  }
};