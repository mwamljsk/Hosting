const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');
// ملف setlog.js داخل مجلد الأوامر

module.exports = {
  name: "setlog",
  description: "Set the log channel and enable/disable specific logs.",
  usage: "!setlog <type> <#channel> <on/off>",
  run: async (client, message, args) => {
    if (!message.member.permissions.has("ADMINISTRATOR"))
      return message.reply("You need administrator permission to use this command.");

    const type = args[0];
    const channel = message.mentions.channels.first();
    const toggle = args[2]?.toLowerCase();

    const validTypes = ["guildBanAdd", "guildBanRemove", "nicknameUpdate", "roleUpdate"];

    if (!type || !validTypes.includes(type))
      return message.reply(`Invalid log type. Valid types: ${validTypes.join(", ")}`);

    if (!channel)
      return message.reply("Please mention a valid channel.");

    if (!["on", "off"].includes(toggle))
      return message.reply("Please specify `on` or `off`.");

    const data = await client.db18.get(message.guild.id) || { logs: {} };

    data.logs[type] = {
      enabled: toggle === "on",
      channelId: channel.id
    };

    await client.db18.set(message.guild.id, data);

    message.reply(`Log \`${type}\` has been **${toggle === "on" ? "enabled" : "disabled"}** and will log to ${channel}`);
  }
};