const { MessageEmbed } = require("discord.js");
const emoji = require("../../emoji.js");

module.exports = {
  name: "unautoban",
  category: "moderation",
  UserPerms: ["ADMINISTRATOR"],
  usage: "unautoban <@user|user_id>",
  run: async (client, message, args) => {
    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!user) {
      return message.channel.send(`${emoji.util.cross} | Please mention a valid user or provide a valid user ID.`);
    }

    const key = `autoban_${message.guild.id}`;
    const bannedList = await client.db26.get(key) || [];

    if (!bannedList.includes(user.id)) {
      return message.channel.send(`${emoji.util.cross} | \`${user.tag}\` is not in the auto-ban list.`);
    }

    const updatedList = bannedList.filter(id => id !== user.id);
    await client.db26.set(key, updatedList);

    message.channel.send(`${emoji.util.tick} | \`${user.tag}\` has been removed from the auto-ban list.`);
  }
};