const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');

module.exports = {
  name: 'mute',
  category: 'moderation',
  UserPerms: ['MODERATE_MEMBERS'],
  BotPerms: ['MODERATE_MEMBERS'],
  usage: 'mute <user mention/id> [reason]',
  
  run: async (client, message, args) => {
    const prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;

    const settings = await client.db18.get(message.guild.id) || {};
    const muteSettings = settings?.moderator?.mute || {
      enabled: true,
      allowedChannels: [],
      ignoredChannels: [],
      allowedRoles: []
    };

    const commandAliases = settings?.commands?.mute?.aliases || ['mute'];

    // Check if command is enabled
    if (!muteSettings.enabled) {
      return message.channel.send(`${emoji.util.cross} | This command is currently **disabled** by the server administrators.`);
    }

    // Check channel restrictions
    if (
      muteSettings.ignoredChannels.includes(message.channel.id) ||
      (muteSettings.allowedChannels.length > 0 && !muteSettings.allowedChannels.includes(message.channel.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | This command is **not allowed** in this channel.`);
    }

    // Check role restrictions
    if (
      muteSettings.allowedRoles.length > 0 &&
      !message.member.roles.cache.some(role => muteSettings.allowedRoles.includes(role.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | You are **not allowed** to use this command based on role restrictions.`);
    }

    // Mute logic
    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);

    if (!user) {
      const embed = new MessageEmbed()
        .setColor('ff0000')
        .setDescription(`\`\`\`diff
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`
> Mute a user temporarily or permanently.`)
        .addField('Aliases', '`' + commandAliases.join('`, `') + '`')
        .addField('Usage', `\`${prefix}${commandAliases[0]} <user_id> [reason]\``);
      return message.channel.send({ embeds: [embed] });
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
      return message.channel.send(`${emoji.util.cross} | This user is not a member of this server.`);
    }

    if (member.id === message.author.id) {
      return message.channel.send(`${emoji.util.cross} | You cannot mute yourself.`);
    }

    if (member.id === client.user.id) {
      return message.channel.send(`${emoji.util.cross} | You can't mute the bot.`);
    }

    if (!member.moderatable || member.roles.highest.position >= message.guild.me.roles.highest.position) {
      return message.channel.send(`${emoji.util.cross} | I cannot mute this member due to role hierarchy or missing permissions.`);
    }

    args.shift();
    const reason = args.join(' ') || 'No reason provided.';

    await member.timeout(7 * 24 * 60 * 60 * 1000, reason); // Mute for 7 days max
    await message.channel.send(`${emoji.util.tick} | Successfully muted \`${user.tag}\` | Reason: ${reason}`);
    
    try {
      await user.send(`You have been muted in **${message.guild.name}** by \`${message.author.tag}\`.\nReason: ${reason}`);
    } catch (err) {
      // Ignore DM errors
    }
  }
};