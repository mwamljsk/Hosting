const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');

module.exports = {
  name: 'kick',
  category: 'moderation',
  UserPerms: ['KICK_MEMBERS'],
  BotPerms: ['KICK_MEMBERS'],
  aboveRole: true,
  usage: 'kick <user mention/id> [reason]',
  
  run: async (client, message, args) => {
    const prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;

    const settings = await client.db18.get(message.guild.id) || {};
    const kickSettings = settings?.moderator?.kick || {
      enabled: true,
      allowedChannels: [],
      ignoredChannels: [],
      allowedRoles: []
    };

    const commandAliases = settings?.commands?.kick?.aliases || ['kick'];

    // Check if command is enabled
    if (!kickSettings.enabled) {
      return message.channel.send(`${emoji.util.cross} | This command is currently **disabled** by the server administrators.`);
    }

    // Check channel restrictions
    if (
      kickSettings.ignoredChannels.includes(message.channel.id) ||
      (kickSettings.allowedChannels.length > 0 && !kickSettings.allowedChannels.includes(message.channel.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | This command is **not allowed** in this channel.`);
    }

    // Check role restrictions
    if (
      kickSettings.allowedRoles.length > 0 &&
      !message.member.roles.cache.some(role => kickSettings.allowedRoles.includes(role.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | You are **not allowed** to use this command based on role restrictions.`);
    }

    // Kick logic
    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);

    if (!user) {
      const embed = new MessageEmbed()
        .setColor('ff0000')
        .setDescription(`\`\`\`diff
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`
> Kick a user from the server.`)
        .addField('Aliases', '`' + commandAliases.join('`, `') + '`')
        .addField('Usage', `\`${prefix}${commandAliases[0]} <user_id> [reason]\``);
      return message.channel.send({ embeds: [embed] });
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
      return message.channel.send(`${emoji.util.cross} | This user is not a member of this server.`);
    }

    if (member.id === message.author.id) {
      return message.channel.send(`${emoji.util.cross} | You cannot kick yourself.`);
    }

    if (member.id === client.user.id) {
      return message.channel.send(`${emoji.util.cross} | You can't kick the bot.`);
    }

    if (!member.kickable || member.roles.highest.position >= message.guild.me.roles.highest.position) {
      return message.channel.send(`${emoji.util.cross} | I cannot kick this member due to role hierarchy or missing permissions.`);
    }

    args.shift();
    const reason = args.join(' ') || 'No reason provided.';

    await member.kick(reason);
    await message.channel.send(`${emoji.util.tick} | Successfully kicked \`${user.tag}\` | Reason: ${reason}`);
    
    try {
      await user.send(`You have been kicked from **${message.guild.name}** by \`${message.author.tag}\`.\nReason: ${reason}`);
    } catch (err) {
      // Ignore DM errors
    }
  }
};