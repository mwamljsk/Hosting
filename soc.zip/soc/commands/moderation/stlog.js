module.exports = {

  name: 'setlogchannel',

  description: 'Set the channel where deleted messages will be logged.',

  async execute(message, args) {

    if (!message.member.permissions.has('MANAGE_CHANNELS')) {

      return message.reply("You don't have permission to set the log channel.");

    }

    const channel = message.mentions.channels.first();

    if (!channel) {

      return message.reply("Please mention a valid channel.");

    }

    // تحديث قاعدة البيانات مع channelId

    try {

      await message.client.db18.run(`UPDATE members_np SET channelId = ?`, [channel.id]);

      message.reply(`Log channel has been set to ${channel}`);

    } catch (error) {

      console.error(error);

      message.reply("There was an error setting the log channel.");

    }

  },

};