const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');

module.exports = {
  name: 'unmute',
  category: 'moderation',
  UserPerms: ['MODERATE_MEMBERS'],
  BotPerms: ['MODERATE_MEMBERS'],
  usage: 'unmute <user mention/id>',
  
  run: async (client, message, args) => {
    const prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;

    const settings = await client.db18.get(message.guild.id) || {};
    const unmuteSettings = settings?.moderator?.unmute || {
      enabled: true,
      allowedChannels: [],
      ignoredChannels: [],
      allowedRoles: []
    };

    const commandAliases = settings?.commands?.unmute?.aliases || ['unmute'];

    if (!unmuteSettings.enabled) {
      return message.channel.send(`${emoji.util.cross} | This command is currently **disabled** by the server administrators.`);
    }

    if (
      unmuteSettings.ignoredChannels.includes(message.channel.id) ||
      (unmuteSettings.allowedChannels.length > 0 && !unmuteSettings.allowedChannels.includes(message.channel.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | This command is **not allowed** in this channel.`);
    }

    if (
      unmuteSettings.allowedRoles.length > 0 &&
      !message.member.roles.cache.some(role => unmuteSettings.allowedRoles.includes(role.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | You are **not allowed** to use this command based on role restrictions.`);
    }

    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!user) {
      const embed = new MessageEmbed()
        .setColor('ff0000')
        .setDescription(`\`\`\`diff
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`
> Unmute a previously muted member.`)
        .addField('Aliases', '`' + commandAliases.join('`, `') + '`')
        .addField('Usage', `\`${prefix}${commandAliases[0]} <user_id>\``);
      return message.channel.send({ embeds: [embed] });
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
      return message.channel.send(`${emoji.util.cross} | This user is not a member of this server.`);
    }

    // Remove timeout (mute)
    try {
      await member.timeout(null);
      await message.channel.send(`${emoji.util.tick} | Successfully unmuted \`${user.tag}\`.`);
      await user.send(`You have been **unmuted** in **${message.guild.name}** by \`${message.author.tag}\`.`).catch(() => {});
    } catch (err) {
      console.error(err);
      message.channel.send(`${emoji.util.cross} | Failed to unmute the user. Make sure I have the correct permissions.`);
    }
  }
};