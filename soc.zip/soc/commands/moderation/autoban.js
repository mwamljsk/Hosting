const { MessageEmbed } = require("discord.js");
const Settings = require("../../settings.js");
const emoji = require("../../emoji.js");

module.exports = {
  name: "autoban",
  category: "moderation",
  UserPerms: ["ADMINISTRATOR"],
  BotPerms: ["BAN_MEMBERS"],
  usage: "autoban <@user|user_id>",
  run: async (client, message, args) => {
    const prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;

    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!user) {
      const errorEmbed = new MessageEmbed()
        .setColor("ff0000")
        .setDescription(`Please mention a valid user or provide a valid user ID.`)
        .addField("Usage", `\`${prefix}autoban <user_id>\``);
      return message.channel.send({ embeds: [errorEmbed] });
    }

    const key = `autoban_${message.guild.id}`;
    const bannedList = await client.db26.get(key) || [];

    if (bannedList.includes(user.id)) {
      return message.channel.send(`${emoji.util.cross} | \`${user.tag}\` is already in the auto-ban list.`);
    }

    bannedList.push(user.id);
    await client.db26.set(key, bannedList);

    const embed = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`${emoji.util.tick} | \`${user.tag}\` has been added to the auto-ban list.\nThey will be banned automatically if they join the server.`);
    message.channel.send({ embeds: [embed] });
  }
};