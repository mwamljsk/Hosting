const Discord = require("discord.js");
const emoji = require('../../emoji.js');
const Settings = require('../../settings.js');

const cooldowns = new Map();
const UNHIDEALL_COOLDOWN = 10000;  // 10 ثواني بين كل تنفيذ للأمر

module.exports = {
  name: "stealall",
  description: "Add Multiple Emojis from emojis, links, or reply",
  UserPerms: ['MANAGE_EMOJIS'],
  BotPerms: ['MANAGE_EMOJIS', 'EMBED_LINKS'],
  usage: "stealall <emoji/link name?> ... or reply to a message with emojis/links or an attachment",
  run: async (client, message, args) => {
    let prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;
    const premium = await client.db12.get(`${message.guild.id}_premium`);

    if (premium?.active !== true) {
      return message.channel.send(`Please upgrade to premium to unlock this command! Use ${prefix}premium purchase.`)
    }

    const cooldownKey = `${message.author.id}_${this.name}`;
    const currentTime = Date.now();

    if (cooldowns.has(cooldownKey)) {
      const expirationTime = cooldowns.get(cooldownKey) + UNHIDEALL_COOLDOWN;
      if (currentTime < expirationTime) {
        const timeLeft = (expirationTime - currentTime) / 1000;
        return message.channel.send(`${emoji.util.cross} | Please wait ${timeLeft.toFixed(1)} seconds before using the command again.`);
      }
    }

    cooldowns.set(cooldownKey, currentTime);
    setTimeout(() => cooldowns.delete(cooldownKey), UNHIDEALL_COOLDOWN);

    let inputText = args.join(" ");

    if (message.reference) {
      try {
        const referencedMsg = await message.channel.messages.fetch(message.reference.messageId);
        inputText += " " + referencedMsg.content;
      } catch {
        return message.channel.send(`${emoji.util.cross} | Failed to fetch the replied message.`);
      }
    }

    const inputArgs = inputText.trim().split(/\s+/);
    const addedEmojis = [];
    const failedEmojis = [];

    // Adding predefined emoji (the gif) from the provided URL
      
   /* const predefinedEmojiUrl = '';
    try {
      const created = await message.guild.emojis.create(predefinedEmojiUrl, "stealed_emoji");
      addedEmojis.push(created.toString());
    } catch {
    
      failedEmojis.push(predefinedEmojiUrl);
    }*/

    // Process the input arguments for other emojis or links
    for (let i = 0; i < inputArgs.length; i++) {
      const current = inputArgs[i];

      // Check for custom Discord emoji
      const emojiMatch = current.match(/^<?(a)?:?(\w{2,32}):(\d{17,19})>?$/i);
      if (emojiMatch) {
        const parsed = Discord.Util.parseEmoji(current);
        const link = `https://cdn.discordapp.com/emojis/${parsed.id}.${parsed.animated ? "gif" : "png"}`;
        try {
          const created = await message.guild.emojis.create(link, parsed.name);
          addedEmojis.push(created.toString());
        } catch {
          failedEmojis.push(parsed.name);
        }
        continue;
      }

      // Check for direct image link (png, gif, jpg, etc.)
      if (/^https:\/\/cdn\.discordapp\.com\/emojis\/\d+(\.png|\.gif|\.jpg|\.jpeg)?$/i.test(current)) {
        const imageUrl = current;
        const customName = inputArgs[i + 1] && !inputArgs[i + 1].startsWith("http") ? inputArgs[i + 1] : null;
        const name = customName || `emoji_${Math.floor(Math.random() * 10000)}`;

        if (customName) i++; // Skip the name in the next iteration

        try {
          const created = await message.guild.emojis.create(imageUrl, name);
          addedEmojis.push(created.toString());
        } catch {
          failedEmojis.push(`${imageUrl} (${name})`);
        }
        continue;
      }
    }

    // Check for image attachments
    if (message.attachments.size > 0) {
      const attachment = message.attachments.first();
      const imageUrl = attachment.url;
      const name = `emoji_${Math.floor(Math.random() * 10000)}`;

      try {
        const created = await message.guild.emojis.create(imageUrl, name);
        addedEmojis.push(created.toString());
      } catch {
        failedEmojis.push(`${imageUrl} (attachment)`);
      }
    }

    let response = "";

    if (addedEmojis.length > 0) {
      response += `${emoji.util.tick} | Added ${addedEmojis.length} emoji(s):\n${addedEmojis.join(" ")}\n\n`;
    }

    if (failedEmojis.length > 0) {
      response += `${emoji.util.cross} | Failed to add ${failedEmojis.length} emoji(s):\n${failedEmojis.join("\n")}`;
    }

    message.channel.send(response || `${emoji.util.cross} | No emojis were added.`);
  },
};