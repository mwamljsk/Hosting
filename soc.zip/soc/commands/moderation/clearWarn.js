const { MessageEmbed } = require('discord.js');
const emoji = require('../../emoji.js');

module.exports = {
  name: 'clearwarns',
  category: 'moderation',
  UserPerms: ['MANAGE_MESSAGES'],
  usage: 'clearwarns <user mention/id> | clearwarns all',
  
  run: async (client, message, args) => {
    if (!args[0]) {
      return message.channel.send(`${emoji.util.cross} | Please provide a user mention/ID or type \`all\` to clear all warnings.`);
    }

    // حذف تحذيرات كل الأعضاء
    if (args[0].toLowerCase() === 'all') {
      await client.db13.all().then(async (data) => {
        const guildWarnings = data.filter(i => i.ID.startsWith(`${message.guild.id}_`) && i.ID.endsWith('_warnings'));
        for (const entry of guildWarnings) {
          await client.db13.delete(entry.ID);
        }
      });

      return message.channel.send(`${emoji.util.tick} | All warnings for this server have been cleared.`);
    }

    // حذف تحذيرات عضو محدد
    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!user) {
      return message.channel.send(`${emoji.util.cross} | Please mention a valid user or provide their ID.`);
    }

    const warnKey = `${message.guild.id}_${user.id}_warnings`;
    const existing = await client.db13.get(warnKey);

    if (!existing || existing.length === 0) {
      return message.channel.send(`${emoji.util.info} | \`${user.tag}\` has no warnings.`);
    }

    await client.db13.delete(warnKey);
    return message.channel.send(`${emoji.util.tick} | Cleared all warnings for \`${user.tag}\`.`);
  }
};