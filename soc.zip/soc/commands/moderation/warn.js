const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');

module.exports = {
  name: 'warn',
  category: 'moderation',
  UserPerms: ['MANAGE_MESSAGES'],
  BotPerms: ['MANAGE_MESSAGES'],
  usage: 'warn <user mention/id> <reason>',
  
  run: async (client, message, args) => {
    const prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;

    const settings = await client.db18.get(message.guild.id) || {};
    const warnSettings = settings?.moderator?.warn || {
      enabled: true,
      allowedChannels: [],
      ignoredChannels: [],
      allowedRoles: []
    };

    const commandAliases = settings?.commands?.warn?.aliases || ['warn'];

    if (!warnSettings.enabled) {
      return message.channel.send(`${emoji.util.cross} | This command is currently **disabled**.`);
    }

    if (
      warnSettings.ignoredChannels.includes(message.channel.id) ||
      (warnSettings.allowedChannels.length > 0 && !warnSettings.allowedChannels.includes(message.channel.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | You cannot use this command in this channel.`);
    }

    if (
      warnSettings.allowedRoles.length > 0 &&
      !message.member.roles.cache.some(role => warnSettings.allowedRoles.includes(role.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | You are not allowed to use this command.`);
    }

    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!user) {
      const embed = new MessageEmbed()
        .setColor('ff0000')
        .setDescription(`\`\`\`diff
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`
> Give a warning to a member`)
        .addField('Aliases', '`' + commandAliases.join('`, `') + '`')
        .addField('Usage', `\`${prefix}${commandAliases[0]} <user_id> [reason]\``);
      return message.channel.send({ embeds: [embed] });
    }

    const member = message.guild.members.cache.get(user.id);
    if (!member) {
      return message.channel.send(`${emoji.util.cross} | This user is not in the server.`);
    }

    args.shift();
    const reason = args.join(' ') || 'Not provided';

    // Save warning in DB
    const warnings = await client.db13.get(`${message.guild.id}_${user.id}_warnings`) || [];
    warnings.push({ mod: message.author.id, reason, date: Date.now() });
    await client.db13.set(`${message.guild.id}_${user.id}_warnings`, warnings);

    await message.channel.send(`${emoji.util.tick} | \`${user.tag}\` has been warned. Reason: **${reason}**`);
    await user.send(`You have been warned in **${message.guild.name}** by \`${message.author.tag}\`. Reason: ${reason}`).catch(() => {});
  }
};