// أمر *setref <رابط الصورة> لتحديد صورة الاشتراك الصحيحة
module.exports = {
  name: "setref",
  UserPerms: ["ADMINISTRATOR"],
  run: async (client, message, args) => {
    const link = args[0];
    if (!link || !link.startsWith("http")) {
      return message.reply("يرجى وضع رابط صورة صحيح.");
    }

    await client.db23.set(`yt_reference_${message.guild.id}`, link.toLowerCase());
    message.reply("تم حفظ الصورة المرجعية للاشتراك.");
  },
};