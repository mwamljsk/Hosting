const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');
const owner = Settings.bot.credits.developerId;

module.exports = {
  name: 'clear',
  aliases: ['مسح','حذف'],
  UserPerms: ['ManageMessages'],
  BotPerms: ['ManageMessages', 'EmbedLinks'],
  run: async (client, message, args) => {
    const list = args[0];
    let prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;
    const arypton = await client.users.fetch(owner);

    const guide = new MessageEmbed()
      .setColor(client.color)
      .setAuthor({ name: client.user.tag, iconURL: client.user.displayAvatarURL() })
      .addFields(
        { name: `${emoji.util.arrow}${prefix}clear bots`, value: "Delete the bots' messages in the channel." },
        { name: `${emoji.util.arrow}${prefix}clear humans`, value: "Delete the humans' messages in the channel." },
        { name: `${emoji.util.arrow}${prefix}clear embeds`, value: "Delete the embeds' messages in the channel." },
        { name: `${emoji.util.arrow}${prefix}clear files`, value: "Delete the files' messages in the channel." },
        { name: `${emoji.util.arrow}${prefix}clear mentions`, value: "Delete the mentions' messages in the channel." },
        { name: `${emoji.util.arrow}${prefix}clear pins`, value: "Delete the pins' messages in the channel." },
        { name: `${emoji.util.arrow}${prefix}clear <number>`, value: "Delete the specified number of messages (any amount)." }
      )
      .setFooter({ text: `Thanks For Selecting ${client.user.username}`, iconURL: client.user.displayAvatarURL({ dynamic: true }) });

    if (!list) return message.channel.send({ embeds: [guide] });

    // إذا كان المستخدم أدخل رقم
    if (!isNaN(list)) {
      let amount = parseInt(list);
      if (amount < 1) return message.reply("العدد يجب أن يكون أكبر من 0.");

      await message.delete();

      let deleted = 0;

      while (deleted < amount) {
        let toDelete = amount - deleted > 100 ? 100 : amount - deleted;
        const messages = await message.channel.messages.fetch({ limit: toDelete });
        const filtered = messages.filter(msg => (Date.now() - msg.createdTimestamp) < 14 * 24 * 60 * 60 * 1000);
        
        if (filtered.size === 0) break;

        await message.channel.bulkDelete(filtered, true).then(m => deleted += m.size);
        await new Promise(resolve => setTimeout(resolve, 1000)); // منع rate limit
      }

      const successEmbed = new MessageEmbed()
        .setColor(client.color)
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(`${emoji.util.tick} | Cleared ${deleted}/${amount} messages!`);

      const msg = await message.channel.send({ embeds: [successEmbed] });
      setTimeout(() => msg.delete(), 5000);
      return;
    }

    const clearMessages = async (filter) => {
      const messages = await message.channel.messages.fetch({ limit: 100 });
      const data = messages.filter(filter).map(m => m);

      await message.delete();
      await message.channel.bulkDelete(data.length ? data : 1, true).then(async (m) => {
        const successEmbed = new MessageEmbed()
          .setColor(client.color)
          .setAuthor(client.user.tag, client.user.displayAvatarURL())
          .setDescription(`${emoji.util.tick} | Cleared ${m.size}/${data.length} messages!`);
        const successMessage = await message.channel.send({ embeds: [successEmbed] });
        setTimeout(() => successMessage.delete(), 5000);
      });
    };

    switch (list) {
      case 'bots':
        return clearMessages(ms => ms.author.bot && !ms.pinned);
      case 'humans':
        return clearMessages(ms => !ms.author.bot && !ms.pinned);
      case 'embeds':
        return clearMessages(ms => ms.embeds.length && !ms.pinned);
      case 'files':
        return clearMessages(ms => ms.attachments.first() && !ms.pinned);
      case 'mentions':
        return clearMessages(ms => (
          (ms.mentions.users.size || ms.mentions.members.size || ms.mentions.channels.size || ms.mentions.roles.size) && !ms.pinned
        ));
      case 'pins':
        return clearMessages(ms => ms.pinned);
      default:
        return message.channel.send({ embeds: [guide] });
    }
  },
};