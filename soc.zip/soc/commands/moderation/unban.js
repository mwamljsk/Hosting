const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');

module.exports = {
  name: 'unban',
  category: 'moderation',
  UserPerms: ['BAN_MEMBERS'],
  BotPerms: ['BAN_MEMBERS'],
  usage: 'unban <user id> [reason]',
  
  run: async (client, message, args) => {
    const prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;
    
    const settings = await client.db18.get(message.guild.id) || {};
    const unbanSettings = settings?.moderator?.unban || {
      enabled: true,
      allowedChannels: [],
      ignoredChannels: [],
      allowedRoles: []
    };
    
    const commandAliases = settings?.commands?.unban?.aliases || ['unban'];

    // Check if command is enabled
    if (!unbanSettings.enabled) {
      return message.channel.send(`${emoji.util.cross} | This command is currently **disabled** by the server administrators.`);
    }

    // Check channel restrictions
    if (
      unbanSettings.ignoredChannels.includes(message.channel.id) ||
      (unbanSettings.allowedChannels.length > 0 && !unbanSettings.allowedChannels.includes(message.channel.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | This command is **not allowed** in this channel.`);
    }

    // Check role restrictions
    if (
      unbanSettings.allowedRoles.length > 0 &&
      !message.member.roles.cache.some(role => unbanSettings.allowedRoles.includes(role.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | You are **not allowed** to use this command based on role restrictions.`);
    }

    // Start unbanning process
    const userId = args[0];
    if (!userId || isNaN(userId)) {
      const embed = new MessageEmbed()
        .setColor('ff0000')
        .setDescription(`\`\`\`diff
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`
> Remove ban from a user by their ID.`)
        .addField('Aliases', '`' + commandAliases.join('`, `') + '`')
        .addField('Usage', `\`${prefix}${commandAliases[0]} <user_id> [reason]\``);
      return message.channel.send({ embeds: [embed] });
    }

    const bans = await message.guild.bans.fetch();
    const bannedUser = bans.get(userId);
    if (!bannedUser) {
      return message.channel.send(`${emoji.util.cross} | This user is not banned.`);
    }

    args.shift();
    const reason = args.join(' ') || 'No reason provided.';

    await message.guild.members.unban(userId, reason);
    await message.channel.send(`${emoji.util.tick} | Successfully unbanned \`${bannedUser.user.tag}\` | Reason: ${reason}`);
  }
};