const { MessageEmbed } = require('discord.js');
const emoji = require('../../emoji.js');

module.exports = {
  name: 'warnings',
  category: 'moderation',
  UserPerms: ['MANAGE_MESSAGES'],
  usage: 'warnings <user mention/id>',
  
  run: async (client, message, args) => {
    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!user) {
      return message.channel.send(`${emoji.util.cross} | Please mention a user or provide a valid user ID.`);
    }

    const warnings = await client.db13.get(`${message.guild.id}_${user.id}_warnings`) || [];

    if (warnings.length === 0) {
      return message.channel.send(`${emoji.util.info} | \`${user.tag}\` has no warnings.`);
    }

    const embed = new MessageEmbed()
      .setTitle(`Warnings for ${user.tag}`)
      .setColor('YELLOW')
      .setDescription(warnings.map((warn, i) => 
        `**#${i + 1}**\n> **Moderator:** <@${warn.mod}>\n> **Reason:** ${warn.reason}\n> **Date:** <t:${Math.floor(warn.date / 1000)}:F>`
      ).join('\n\n'))
      .setFooter({ text: `Total Warnings: ${warnings.length}` });

    message.channel.send({ embeds: [embed] });
  }
};