const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');

module.exports = {
  name: 'ban',
  category: 'moderation',
  UserPerms: ['BAN_MEMBERS'],
  BotPerms: ['BAN_MEMBERS'],
  aboveRole: true,
  usage: 'ban <user mention/id> <reason>',
  
  run: async (client, message, args) => {
    const prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;
    
    const settings = await client.db18.get(message.guild.id) || {};
    const banSettings = settings?.moderator?.ban || {
      enabled: true,
      allowedChannels: [],
      ignoredChannels: [],
      allowedRoles: []
    };
    
    const commandAliases = settings?.commands?.ban?.aliases || ['ban'];

    // Check if command is enabled
    if (!banSettings.enabled) {
      return message.channel.send(`${emoji.util.cross} | This command is currently **disabled** by the server administrators.`);
    }

    // Check channel restrictions
    if (
      banSettings.ignoredChannels.includes(message.channel.id) ||
      (banSettings.allowedChannels.length > 0 && !banSettings.allowedChannels.includes(message.channel.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | This command is **not allowed** in this channel.`);
    }

    // Check role restrictions
    if (
      banSettings.allowedRoles.length > 0 &&
      !message.member.roles.cache.some(role => banSettings.allowedRoles.includes(role.id))
    ) {
      return message.channel.send(`${emoji.util.cross} | You are **not allowed** to use this command based on role restrictions.`);
    }

    // Start banning process
    const user = message.mentions.users.first() || await client.users.fetch(args[0]).catch(() => null);
    if (!args[0] || !user) {
      const embed = new MessageEmbed()
        .setColor('ff0000')
        .setDescription(`\`\`\`diff
- [] = optional argument
- <> = required argument
- Do NOT type these when using commands!
\`\`\`
> Ban someone who continuously breaks the rules.`)
        .addField('Aliases', '`' + commandAliases.join('`, `') + '`')
        .addField('Usage', `\`${prefix}${commandAliases[0]} <user_id> [reason]\``);
      return message.channel.send({ embeds: [embed] });
    }

    const targetMember = message.guild.members.cache.get(user.id);
    if (!targetMember) {
      return message.channel.send(`${emoji.util.cross} | The specified user is not in this server.`);
    }

    if (user.id === message.author.id) {
      return message.channel.send(`${emoji.util.cross} | You can't ban yourself.`);
    }

    if (user.id === client.user.id) {
      return message.channel.send(`${emoji.util.cross} | You can't ban the bot.`);
    }

    if (!targetMember.bannable || targetMember.roles.highest.comparePositionTo(message.guild.me.roles.highest) > 0) {
      return message.channel.send(`${emoji.util.cross} | I can't ban this user. They might have a higher role or I lack permissions.`);
    }

    args.shift();
    const reason = args.join(' ') || 'No reason provided.';

    await targetMember.ban({ reason });
    await message.channel.send(`${emoji.util.tick} | Successfully banned \`${user.tag}\` | Reason: ${reason}`);
    await user.send(`You have been banned from **${message.guild.name}** by \`${message.author.tag}\`.\nReason: ${reason}`).catch(() => {});
  }
};