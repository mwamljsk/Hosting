const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'antispam',
  run: async (client, message, args) => {
    if (!message.member.permissions.has('ADMINISTRATOR'))
      return message.reply("ما عندك صلاحية لإدارة النظام.");

    const status = args[0];

    if (status === 'enable') {
      await client.db26.set(`${message.guild.id}_antispam`, { enabled: true });
      return message.reply("تم تفعيل نظام الحماية من السبام.");
    }

    if (status === 'disable') {
      await client.db26.set(`${message.guild.id}_antispam`, { enabled: false });
      return message.reply("تم تعطيل نظام الحماية من السبام.");
    }

    return message.reply("استخدم: `!antispam enable` أو `!antispam disable`.");
  }
};