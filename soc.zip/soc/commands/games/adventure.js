const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

const { createCanvas, loadImage } = require('canvas');

const emoji = require('../../emoji.js');

module.exports = {

  name: "adventure",

  description: "لعبة مغامرة الماس",

  aliases: ["game", "adventure", "مغامرة"],

  

  run: async (client, message, args) => {

    const db = client.db17;

    const senderId = message.author.id;

    const getBalance = async (id) => await db.get(`balance_${id}`) || 0;

    const getDiamonds = async (id) => await db.get(`diamonds_${id}`) || 0;

    const setBalance = async (id, amount) => await db.set(`balance_${id}`, amount);

    const setDiamonds = async (id, amount) => await db.set(`diamonds_${id}`, amount);

    // تأكيد إذا كان اللاعب يملك رصيد

    const balance = await getBalance(senderId);

    const diamonds = await getDiamonds(senderId);

    if (args[0] === "start") {

      if (balance < 100) return message.reply("❌ تحتاج إلى 100 SOC لبدء المغامرة!");

      // خصم 100 SOC من الرصيد

      await setBalance(senderId, balance - 100);

      // إعطاء الماس بشكل عشوائي

      const randomDiamonds = Math.floor(Math.random() * 10) + 1;

      await setDiamonds(senderId, diamonds + randomDiamonds);

      // إنشاء رسالة تأكيد للمغامرة

      const embed = new MessageEmbed()

        .setColor("#FFDD00")

        .setTitle("مغامرة الماس")

        .setDescription(`لقد بدأت مغامرتك! حصلت على \`${randomDiamonds}\` ماس!`)

        .setFooter("مغامرة الماس", client.user.displayAvatarURL());

      return message.channel.send({ embeds: [embed] });

    }

    if (args[0] === "shop") {

      const shopEmbed = new MessageEmbed()

        .setColor("#008CFF")

        .setTitle("متجر الأدوات")

        .setDescription("يمكنك شراء الأدوات لزيادة فرصك في مغامرة الماس.")

      const shopRow = new MessageActionRow().addComponents(

        new MessageButton()

          .setCustomId("buy_shovel")

          .setLabel("مجنزرة [300 SOC]")

          .setStyle("SUCCESS")

      );

      return message.channel.send({ embeds: [shopEmbed], components: [shopRow] });

    }

    if (args[0] === "balance") {

      return message.reply(`:bank: | **رصيدك هو \`${balance}\` SOC و \`${diamonds}\` ماس**`);

    }

    return message.reply("❌ يرجى استخدام الأمر بشكل صحيح. استخدم `start` لبدء المغامرة أو `shop` لزيارة المتجر.");

  }

};