const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

const { createCanvas, loadImage } = require('canvas');

const emoji = require('../../emoji.js');

module.exports = {

  name: "fight",

  description: "لعبة مصارعة الأبطال",

  aliases: ["مصارعة", "fight", "المصارعة"],

  

  run: async (client, message, args) => {

    const db = client.db17;

    const senderId = message.author.id;

    const getBalance = async (id) => await db.get(`balance_${id}`) || 0;

    const setBalance = async (id, amount) => await db.set(`balance_${id}`, amount);

    // التأكد من رصيد اللاعب

    const balance = await getBalance(senderId);

    

    if (args[0] === "start") {

      // التحقق من أن اللاعب لديه ما يكفي من الرصيد

      if (balance < 200) return message.reply("❌ تحتاج إلى 200 SOC لبدء المصارعة!");

      // خصم SOC من اللاعب لبدء المصارعة

      await setBalance(senderId, balance - 200);

      const opponent = message.mentions.users.first();

      if (!opponent) return message.reply("❌ من فضلك اختر خصمًا لمصارعته باستخدام @username!");

      const opponentBalance = await getBalance(opponent.id);

      if (opponentBalance < 200) return message.reply(`${opponent.username} لا يملك ما يكفي من SOC للمشاركة في المصارعة!`);

      // حساب قوة كل لاعب

      const playerPower = Math.floor(Math.random() * 100) + 1;

      const opponentPower = Math.floor(Math.random() * 100) + 1;

      // تحديد الفائز بناءً على القوة العشوائية

      let winner = "";

      let prize = 0;

      if (playerPower > opponentPower) {

        winner = message.author.username;

        prize = Math.floor(Math.random() * 100) + 300; // اللاعب الفائز يحصل على جوائز

      } else {

        winner = opponent.username;

        prize = Math.floor(Math.random() * 100) + 300;

      }

      // تحديث الرصيد بناءً على الفائز

      if (winner === message.author.username) {

        await setBalance(senderId, balance + prize);

        await setBalance(opponent.id, opponentBalance - 200); // خصم SOC من الخاسر

      } else {

        await setBalance(opponent.id, opponentBalance + prize);

        await setBalance(senderId, balance - 200); // خصم SOC من الفائز

      }

      const embed = new MessageEmbed()

        .setColor("#FF5733")

        .setTitle("مصارعة الأبطال")

        .setDescription(`المباراة انتهت! **${winner}** هو الفائز!`)

        .addField("قوة اللاعب:", playerPower)

        .addField("قوة الخصم:", opponentPower)

        .addField("الجوائز:", `حصل الفائز على \`${prize}\` SOC!`)

        .setFooter("مصارعة الأبطال", client.user.displayAvatarURL());

      return message.channel.send({ embeds: [embed] });

    }

    if (args[0] === "stats") {

      return message.reply(`:bank: | **رصيدك هو \`${balance}\` SOC**`);

    }

    return message.reply("❌ استخدم `start` لبدء المصارعة و `stats` لمعرفة رصيدك.");

  }

};