const Discord = require("discord.js");
const { ownerIDS } = require('../../owner.json');

module.exports = {
  name: "nitro",
  run: async (client, message) => {

    if (!ownerIDS.includes(message.author.id)) return;

    let embed = new Discord.MessageEmbed()
      .setColor(client.color)
      .setTitle("A wild gift appears")
      .setThumbnail("https://cdn.discordapp.com/emojis/1320170196383694889.png")
      .setDescription(`**Nitro** \n Expires in 48 hours`);

    let button = new Discord.MessageButton()
      .setCustomId('brrrrr')
      .setLabel('ㅤㅤㅤㅤㅤㅤAcceptㅤㅤㅤㅤㅤㅤ')
      .setStyle('SUCCESS')

    const row = new Discord.MessageActionRow()
      .addComponents([button])

    return message.channel.send({ embeds: [embed], components: [row] })
  }
}
