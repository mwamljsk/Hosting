const {
  MessageActionRow,
  MessageButton,
  MessageEmbed,
  MessageSelectMenu,
} = require("discord.js");
const Settings = require("../../settings.js");
const { ownerIDS } = require("../../owner.json");
const emoji = require("../../emoji.js");
const owner = Settings.bot.credits.developerId;

module.exports = {
  name: "help",
  aliases: ["h"],
  run: async function (client, message, args) {
    const prefix =
      (await client.db8.get(`${message.guild.id}_prefix`)) ||
      Settings.bot.info.prefix;
    const arypton = await client.users.fetch(owner);
    let commands;
    const data = await client.db11.get(`${message.guild.id}_eo.extraownerlist`);
    const data1 = await client.db11.get(
      `${message.guild.id}_ea.extraadminlist`,
    );
    const premium = await client.db12.get(`${message.guild.id}_premium`);

    const menuOptions = new MessageActionRow().addComponents(
      new MessageSelectMenu()
        .setCustomId("helpOption")
        .setPlaceholder("Choose wisely, shape your destiny.")
        .addOptions([
          {
            label: "Home",
            value: "h1",
            emoji: "1156273221201567814",
            description: "See Home Page",
          },
          {
            label: "Antinuke",
            value: "h2",
            emoji: "1209181835784101898",
            description: "See the antinuke Commands",
          },
          {
            label: "Automod",
            value: "h3",
            emoji: "1209181830608330854",
            description: "See the Automod Commands",
          },
          {
            label: "Moderation",
            value: "h4",
            emoji: "1209182855071141948",
            description: "See the Moderation Commands",
          },
          {
            label: "Welcome",
            value: "h5",
            emoji: "1209185151649849355",
            description: "See the Welcome Commands",
          },
          {
            label: "Server",
            value: "h6",
            emoji: "1209183462402039808",
            description: "See the Server Commands",
          },
          {
            label: "Voice Role",
            value: "h7",
            emoji: "1209185393925169222",
            description: "See the Voice Role Commands",
          },
          {
            label: "Custom Roles",
            value: "h8",
            emoji: "1209184436910952499",
            description: "See the Custom Roles Commands",
          },
          {
            label: "Media",
            value: "h9",
            emoji: "1209184808505319538",
            description: "See the Media Commands",
          },
          {
            label: "Games",
            value: "h10",
            emoji: "1209183749330173972",
            description: "See the Games Commands",
          },
          {
            label: "Utility",
            value: "h11",
            emoji: "1209191962381520906",
            description: "See the Utility Commands",
          },
        ]),
    );

    const disabledMenuOptions = new MessageActionRow().addComponents(
      new MessageSelectMenu()
        .setCustomId("helpOption2")
        .setPlaceholder("Choose wisely, shape your destiny.")
        .addOptions([
          {
            label: "Home",
            value: "h31",
            emoji: "1209335188543373312",
            description: "See Home Page",
          },
        ])
        .setDisabled(true),
    );

    const embed1 = new MessageEmbed()
      .setColor(client.color)
      .setAuthor({
        name: `${message.guild.name}`,
        iconURL: message.author.displayAvatarURL({ dynamic: true }),
      })
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
      .setDescription(
        `Hey It's Me Lock N Loaded a  Multipurpose Bot With All The Features And Commands You Need With Over Powered Features Come Manage Your Server With Me\n\n\<:utility_emoji:1071406896885534730> __**Links**__\n - **[Support](https://discord.gg/RBPaJMx3K4)**\n - **[Invite Me](https://discord.com/oauth2/authorize?client_id=777502015999574036&scope=bot+applications.commands+identify+guilds+applications.commands.permissions.update&response_type=code&permissions=2080374975)**`,
      )
      .addField(
        "\<:utility_emoji:1071406896885534730> __Commands__",
        `- ${emoji.id.antinuke}\`:\`**Antinuke**\n- ${emoji.id.automod}\`:\`**Automod**\n- ${emoji.id.moderation}\`:\`**Moderation**\n- ${emoji.id.welcome}\`:\`**Welcome**\n- ${emoji.id.ignore}\`:\`**Server**\n- ${emoji.id.voiceroles}\`:\`**VoiceRoles**\n- ${emoji.id.customroles}\`:\`**Custom Role**\n- ${emoji.id.media}\`:\`**Media**\n- ${emoji.id.games}\`:\`**Games**\n- ${emoji.id.utility}\`:\`**Utility**\n\`Choose From The Dropdown Below\``,
        false,
      );

    const embed2 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.antinuke} **Antinuke Commands**`)
  .setDescription(`
    **► Basic Antinuke Commands:**
    \`antinuke\` - Activates or deactivates antinuke features.
    \`antinuke guide\` - Shows a guide on how to configure antinuke.
    \`antinuke features\` - Lists all features available with antinuke.

    **► Enable/Disable Antinuke Events:**
    \`antinuke enable/disable\` - Enables or disables antinuke functionality.

    **► Event-specific Antinuke Configuration:**
    \`antinuke <event create/delete/update> enable/disable\` - Enable or disable specific events.

    **► Whitelisting Users:**
    \`antinuke whitelist add/remove <user mention/id>\` - Add or remove a user from the whitelist.
    \`antinuke whitelist reset\` - Resets the whitelist.

    **► Antinuke Configurations and Reset:**
    \`antinuke config\` - Configure antinuke settings.
    \`antinuke reset\` - Resets antinuke configurations to default.

    **► Night Mode Commands:**
    \`nightmode\` - Toggles night mode on or off.
    \`nightmode enable/disable\` - Enables or disables night mode.
    \`nightmode role add/remove <role mention/id>\` - Add or remove a role to use night mode.
    \`nightmode bypass add/remove <user mention/id>\` - Add or remove a user from bypassing night mode.
    \`nightmode role/bypass show\` - Displays roles and users with nightmode bypass.
    \`autoban @user/ user-id\` - autoban user in the Guild on the Server.
    \`unautoban @user/ user-id\` - unautoban user in the Guild on the Server.
    \`autobanlist\` - autoban User's List form the Server Guild's.
    \`nightmode role/bypass reset\` - Resets nightmode roles and bypass settings.
  `)
  .setFooter('Antinuke Bot - Protect your server with Antinuke')
  .setTimestamp();

const embed3 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.automod} **Automod Commands**`)
  .setDescription(`
    **► Basic Anti Features:**
    \`antilink\` - Blocks all links in the server.
    \`antilink enable\` - Enables the antilink feature.
    \`antilink disable\` - Disables the antilink feature.

    **► Anti Mention Features:**
    \`antieveryone\` - Blocks @everyone mentions.
    \`antieveryone enable\` - Enables the anti-everyone feature.
    \`antieveryone disable\` - Disables the anti-everyone feature.

    **► Automod Specific Features:**
    \`automod anti pornography enable/disable\` - Block or unblock pornography content.
    \`automod anti message spam enable/disable\` - Enable or disable anti-spam for messages.
    \`automod anti mention spam enable/disable\` - Enable or disable anti-spam for mentions.
    \`automod anti toxicity enable/disable\` - Enable or disable anti-toxicity moderation.
    
    **► Automod Config and Reset:**
    \`automod config\` - Configure automod settings.
    \`automod reset\` - Resets automod settings to default.
    \`antispam enable/disable\` - Enable or disable antispam Settings.
  `)
  .setFooter('Automod Bot - Keep your server safe and clean')
  .setTimestamp();

const embed4 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.moderation} **Moderation Commands**`)
  .setDescription(`
    **► Clear Commands:**
    \`clear numbers\` - Clears all messages in the channel.
    \`clear bots\` - Clears all bot messages in the channel.
    \`clear humans\` - Clears all human messages in the channel.
    \`clear embeds\` - Clears all embedded messages in the channel.
    \`clear files\` - Clears all file attachments in the channel.
    \`clear mentions\` - Clears messages with mentions in the channel.
    \`clear pins\` - Clears pinned messages in the channel.

    **► Ban and Kick and Mute and Warns Commands:**
    \`ban <user>\` - Bans a user from the server.
    \`unban <user>\` - Unbans a user from the server.
    \`kick <user>\` - Kicks a user from the server.
    \`mute <user>\` - Mute a User from the server.
    \`unmute <unmute>\` - Unmute a User from the server.

    \`warn <user> res\` - Warn the User.
    \`warnings <user>\` - Show Warnings the User.
    \`clearwarns <user>\` - Clear Warnings For User.

    **► Channel Lock/Unlock:**
    \`hide <channel>\` - Hides a channel from users.
    \`unhide <channel>\` - Unhides a channel for users.
    \`lock <channel>\` - Locks a channel, preventing users from sending messages.
    \`unlock <channel>\` - Unlocks a channel, allowing users to send messages.

    **► Voice Mute/Deafen:**
    \`voice muteall\` - Mutes all users in voice channels.
    \`voice unmuteall\` - Unmutes all users in voice channels.
    \`voice deafenall\` - Deafens all users in voice channels.
    \`voice undeafenall\` - Undeafens all users in voice channels.
    \`voice mute <user>\` - Mutes a specific user in voice.
    \`voice unmute <user>\` - Unmutes a specific user in voice.
    \`voice deafen <user>\` - Deafens a specific user in voice.
    \`voice undeafen <user>\` - Undeafens a specific user in voice.



    \`giveaway 1s/1m/1h/1w winers pise\` - giveaway The server the channel.
  `)
  .setFooter('Moderation Bot - Keep your server under control')
  .setTimestamp();

const embed5 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.welcome} **Welcome Commands**`)
  .setDescription(`
    **► Welcome Settings:**
    \`welcome\` - Set up a welcome message for new users.
    \`welcome message panel\` - Edit the welcome message panel.
    \`welcome test\` - Test the welcome message.
    \`welcome reset\` - Reset the welcome message to default.

    **► Auto Role Settings:**
    \`autorole\` - Configure auto roles for users.
    \`autorole humans add <role mention/id>\` - Add a role to human users automatically.
    \`autorole humans remove <role mention/id>\` - Remove a role from human users automatically.
    \`autorole bots add <role mention/id>\` - Add a role to bots automatically.
    \`autorole bots remove <role mention/id>\` - Remove a role from bots automatically.
    \`autorole config\` - Configure the auto role settings.
    \`autorole reset\` - Reset auto role settings to default.
  `)
  .setFooter('Welcome Bot - Greet your new members with style!')
  .setTimestamp();

const embed6 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.ignore} **Server Commands**`)
  .setDescription(`
    **► Extra Commands:**
    \`extra owner add <user mention/id>\` - Adds a user as server owner.
    \`extra admin add <user mention/id>\` - Adds a user as admin.
    \`extra owner remove <user mention/id>\` - Removes a user from server owner role.
    \`extra admin remove <user mention/id>\` - Removes a user from admin role.

    **► Extra Information:**
    \`extra owner show\` - Displays all server owners.
    \`extra admin show\` - Displays all admins.
    \`extra owner reset\` - Resets the owner configuration.
    \`extra admin reset\` - Resets the admin configuration.

    **► Ignore Commands:**
    \`ignore\` - Configure server ignore settings.
    \`ignore channel add <channel mention/id>\` - Add a channel to be ignored.
    \`ignore bypass add <channel mention/id>\` - Add a channel to bypass ignore.
    \`ignore channel remove <channel mention/id>\` - Remove a channel from ignore list.
    \`ignore bypass remove <channel mention/id>\` - Remove a bypassed channel.
    \`ignore channel show\` - Show the list of ignored channels.
    \`ignore bypass show\` - Show the list of bypassed channels.
    \`ignore channel reset\` - Reset ignored channels.
    \`ignore bypass reset\` - Reset bypassed channels.
  `)
  .setFooter('Server Management Bot - Manage and protect your server efficiently')
  .setTimestamp();

const embed7 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.voiceroles} **Voice Roles Commands**`)
  .setDescription(`
    **► Voice Roles Settings:**
    \`invc\` - Enable or disable voice channel invitations.
    \`invc humans <role>\` - Assign a specific role to human users for voice channels.
    \`invc bots <role>\` - Assign a specific role to bots for voice channels.
    \`invc config\` - Configure voice role settings.
    \`invc reset\` - Reset voice role settings to default.
  `)
  .setFooter('Voice Roles Bot - Manage voice roles seamlessly')
  .setTimestamp();

const embed8 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.customroles} **Custom Role Commands**`)
  .setDescription(`
    **► Setup Commands:**
    \`setup\` - Configure your custom role settings.
    \`setup config\` - Configure the setup settings.
    \`setup reqrole <role mention/id>\` - Set the required role for custom roles.
    \`setup admin <role mention/id>\` - Assign admin roles to custom roles.
    \`setup official <role mention/id>\` - Assign official roles to custom roles.
    \`setup guest <role mention/id>\` - Assign guest roles to custom roles.
    \`setup girl <role mention/id>\` - Assign girl roles to custom roles.
    \`setup friend <role mention/id>\` - Assign friend roles to custom roles.
    \`setup vip <role mention/id>\` - Assign VIP roles to custom roles.
    \`setup tag <tag>\` - Add a tag for a custom role.
    \`setup stag <stag>\` - Add a stag for a custom role.

    **► Role Management:**
    \`admin <user mention/id>\` - Assign admin role to a user.
    \`official <user mention/id>\` - Assign official role to a user.
    \`guest <user mention/id>\` - Assign guest role to a user.
    \`girl <user mention/id>\` - Assign girl role to a user.
    \`friend <user mention/id>\` - Assign friend role to a user.
    \`vip <user mention/id>\` - Assign VIP role to a user.

    **► Reset Custom Roles:**
    \`setup reset\` - Reset custom role settings.

    **► Setup XP Channel:**
    \`setxp on/off\` - On and Off XP the server send Channel.
    \`setxp <channel-id/#channel>\` - Setxp For Channel the Server.
  `)
  .setFooter('Custom Roles Bot - Tailor your server roles to perfection')
  .setTimestamp();
  
const embed9 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.media} **Media Commands**`)
  .setDescription(`
    **► Media Channel Settings:**
    \`media\` - General media management commands.
    \`media channel add <channel mention/id>\` - Add a media channel to your server.
    \`media channel remove <channel mention/id>\` - Remove a media channel from your server.
  
    **► Media Config and Reset:**
    \`media config\` - Configure media channels and settings.
    \`media reset\` - Reset media channel settings.
  `)
  .setFooter('Media Bot - Manage media channels and content')
  .setTimestamp();

const embed10 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.games} **Games Commands**`)
  .setDescription(`
    **► Fun Games Commands:**
    \`8ball\` - A fun game command.
    \`nitro\` - A fun game command involving Nitro.
  `)
  .setFooter('Games Bot - Bring some fun to your server!')
  .setTimestamp();

const embed11 = new MessageEmbed()
  .setColor(client.color)
  .setTitle(`${emoji.id.utility} **Utility Commands**`)
  .setDescription(`
    **► General Utilities:**
    \`afk\` - Set yourself as AFK.
    \`premium\` - Check premium status and features.
    \`premium redeem\` - Redeem a premium subscription.
    \`premium status\` - Check premium status.
    \`premium purchase\` - Purchase a premium subscription.
    \`premium features\` - View available premium features.

    **► Server Info:**
    \`embed create\` - Create a custom embed message.
    \`code\` - Show your code.
    \`help\` - Show help information.
    \`info\` - Show bot information.
    \`invite\` - Get the invite link for the bot.
    \`ping\` - Check bot latency.
    \`privacy\` - Show privacy policy.
    \`terms\` - Show terms of service.
    \`stats\` - Show bot statistics.
    \`uptime\` - Check bot uptime.
    \`vote\` - Vote for the bot.
    \`soc\` - Soc balance.
    \`daily\` - Daily SOC Balance.
    \`rank\` - Rank The Server Level. 
  
    **► User/Server Info (continued):**
    \`banner <user mention/id>\` - Get the user's banner.
    \`serverbanner\` - Get the server's banner.
    \`google <query>\` - Perform a search on Google.
    \`serverinfo\` - Display server information.
    \`userinfo <user>\` - Display information about a specific user.
    \`profile <user mention/id>\` - Display the user's profile.
    \`membercount\` - Display the number of members in the server.
    \`boostcount\` - Display the number of boosts in the server.
    \`rolecount\` - Display the number of roles in the server.
    \`channelcount\` - Display the number of channels in the server.
    \`emojicount\` - Display the number of emojis in the server.
    \`snipe\` - Display the last deleted message.
    \`list bots\` - Display a list of bots in the server.
    \`list bans\` - Display a list of bans in the server.
    \`list admins\` - Display a list of admins in the server.
    \`list inrole <role mention/id>\` - Display members in a specific role.
    \`list boosters\` - Display a list of boosters in the server.
    \`list emojis\` - Display a list of emojis in the server.
    \`list roles\` - Display a list of roles in the server.
  `)
  .setFooter('Utility Bot - Tools to make your life easier!')
  .setTimestamp();

    const embeds = [
      embed1,
      embed2,
      embed3,
      embed4,
      embed5,
      embed6,
      embed7,
      embed8,
      embed9,
      embed10,
      embed11,
    ];
    const totalPages = embeds.length;
    let currentPage = 0;

    const pag = new MessageActionRow().addComponents(
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("first")
        .setEmoji("1209332345774284820")
        .setDisabled(true),
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("previous")
        .setEmoji("1209332340719882240")
        .setDisabled(true),
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("close")
        .setEmoji("1209332537554370590")
        .setDisabled(false),
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("next")
        .setEmoji("1209332337872076850")
        .setDisabled(false),
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("last")
        .setEmoji("1209332343203172412")
        .setDisabled(false),
    );

    const button = new MessageActionRow().addComponents(
      new MessageButton()
        .setLabel("Vote")
        .setStyle("LINK")
        .setURL(`https://top.gg/bot/${client.user.id}/vote`),
      new MessageButton()
        .setLabel("Invite")
        .setStyle("LINK")
        .setURL(
          `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`,
        ),
      new MessageButton()
        .setLabel("Website")
        .setStyle("LINK")
        .setURL(`https://locknloaded.netlify.app/`),
    );

    const disabledPagg = new MessageActionRow().addComponents(
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("first")
        .setEmoji("1209332345774284820")
        .setDisabled(true),
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("previous")
        .setEmoji("1209332340719882240")
        .setDisabled(true),
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("close")
        .setEmoji("1209332537554370590")
        .setDisabled(false),
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("next")
        .setEmoji("1209332337872076850")
        .setDisabled(false),
      new MessageButton()
        .setStyle("SECONDARY")
        .setCustomId("last")
        .setEmoji("1209332343203172412")
        .setDisabled(false),
    );

    async function generateEmbed() {
      const embed = embeds[currentPage];
      embed.setFooter(
        `Thanks For Choosing Lock N Loaded`,
        arypton.displayAvatarURL({ dynamic: true }),
      );
      return embed;
    }

    async function sendMessage() {
      const embed = await generateEmbed();
      const messageComponent = await message.channel.send({
        embeds: [embed],
        components: [pag, menuOptions],
      });
      return messageComponent;
    }

    async function updatePaginationButtons() {
      const firstButton = pag.components.find(
        (component) => component.customId === "first",
      );
      const backButton = pag.components.find(
        (component) => component.customId === "previous",
      );
      const nextButton = pag.components.find(
        (component) => component.customId === "next",
      );
      const lastButton = pag.components.find(
        (component) => component.customId === "last",
      );

      firstButton.setDisabled(currentPage === 0);
      backButton.setDisabled(currentPage === 0);
      nextButton.setDisabled(currentPage === totalPages - 1);
      lastButton.setDisabled(currentPage === totalPages - 1);
    }

    async function handleInteraction(interaction) {
      if (interaction.isButton()) {
        if (interaction.customId === "next") {
          if (currentPage < totalPages - 1) {
            currentPage++;
          }
        } else if (interaction.customId === "previous") {
          if (currentPage > 0) {
            currentPage--;
          }
        } else if (interaction.customId === "first") {
          currentPage = 0;
        } else if (interaction.customId === "last") {
          currentPage = totalPages - 1;
        } else if (interaction.customId === "close") {
          messageComponent.edit({
            components: [disabledPagg, disabledMenuOptions],
          });
          return;
        }

        const updatedEmbed = await generateEmbed();
        updatePaginationButtons();

        interaction.update({
          embeds: [updatedEmbed],
          components: [pag, menuOptions],
        });
      } else if (interaction.isSelectMenu()) {
        switch (interaction.values[0]) {
          case "h1":
            currentPage = 0;
            break;
          case "h2":
            currentPage = 1;
            break;
          case "h3":
            currentPage = 2;
            break;
          case "h4":
            currentPage = 3;
            break;
          case "h5":
            currentPage = 4;
            break;
          case "h6":
            currentPage = 5;
            break;
          case "h7":
            currentPage = 6;
            break;
          case "h8":
            currentPage = 7;
            break;
          case "h9":
            currentPage = 8;
            break;
          case "h10":
            currentPage = 9;
            break;
          case "h11":
            currentPage = 10;
            break;
          default:
            currentPage = 0;
        }

        updatedEmbed = await generateEmbed();
        updatePaginationButtons();
      }

      interaction.update({
        embeds: [updatedEmbed],
        components: [pag, menuOptions],
      });
    }

    const messageComponent = await sendMessage();

    const collector = messageComponent.createMessageComponentCollector({
      filter: (interaction) => {
        if (message.author.id === interaction.user.id) return true;
        else {
          return interaction.reply({
            content: `${emoji.util.cross} | This Pagination is not for you.`,
            ephemeral: true,
          });
        }
      },
      time: 200000,
      idle: 300000 / 2,
    });

    collector.on("collect", async (interaction) => {
      await handleInteraction(interaction);
    });

    collector.on("end", async () => {
      const disabledPag = new MessageActionRow().addComponents(
        new MessageButton()
          .setStyle("SECONDARY")
          .setCustomId("first")
          .setEmoji("1209332345774284820")
          .setDisabled(true),
        new MessageButton()
          .setStyle("SECONDARY")
          .setCustomId("previous")
          .setEmoji("1209332340719882240")
          .setDisabled(true),
        new MessageButton()
          .setStyle("SECONDARY")
          .setCustomId("close")
          .setEmoji("1209332537554370590")
          .setDisabled(true),
        new MessageButton()
          .setStyle("SECONDARY")
          .setCustomId("next")
          .setEmoji("1209332337872076850")
          .setDisabled(true),
        new MessageButton()
          .setStyle("SECONDARY")
          .setCustomId("last")
          .setEmoji("1209332343203172412")
          .setDisabled(true),
      );

      messageComponent.edit({ components: [disabledPag, disabledMenuOptions] });
    });
  },
};
