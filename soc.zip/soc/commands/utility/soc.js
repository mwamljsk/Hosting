const { MessageAttachment } = require("discord.js");
const { createCanvas } = require("canvas");
const emoji = require('../../emoji.js');

module.exports = {
  name: "soc",
  description: "Display or transfer SOC currency",
  aliases: ["فلوس", "رصيدي", "رصيد", "soc", "s"],
  usage: "soc | soc @user | soc @user amount",

  run: async (client, message, args) => {
    const senderId = message.author.id;
    const db = client.db17;

    const getBalance = async (id) => await db.get(`balance_${id}`) || 0;
    const setBalance = async (id, amount) => await db.set(`balance_${id}`, amount);

    async function logTransaction(userId, tx) {
      const list = await db.get(`transactions_${userId}`) || [];
      list.unshift(tx);
      await db.set(`transactions_${userId}`, list.slice(0, 10));
    }

    if (message.author.bot) {
      return message.reply("❌ Bots do not have balances.");
    }

    // Show balance
    if (args.length === 0) {
      const soc = await getBalance(senderId);
      return message.reply(`:bank: | **${message.author.username}, your account balance is \`${soc.toLocaleString()}\` ${emoji.flag.soc}.**`);
    }

    // Target user
    let target;
    if (args[0].startsWith("<@") && args[0].endsWith(">")) {
      target = message.mentions.users.first();
    } else {
      target = client.users.cache.get(args[0]);
    }
    if (!target) return message.reply("❌ User not found.");
    if (target.bot) return message.reply("❌ You cannot transfer to bots.");
      if (target.id === senderId) return message.reply("❌ You cannot transfer to yourself.");

    // Show target balance
    if (args.length === 1) {
      const soc = await getBalance(target.id);
      return message.reply(`:bank: | **${target.username}'s account balance is \`${soc.toLocaleString()}\` ${emoji.flag.soc}.**`);
    }

    // Transfer
    if (args.length === 2) {
      const amount = parseInt(args[1]);
      if (isNaN(amount) || amount <= 0) return message.reply("❌ Please enter a valid amount to transfer.");

      const senderBalance = await getBalance(senderId);
      if (senderBalance < amount) return message.reply("❌ You do not have enough balance.");

      const fee = Math.round(amount * 0.0512);
      const finalAmount = amount - fee;

      // Create verification code image
      const code = Math.floor(1000 + Math.random() * 9000).toString();
      const canvas = createCanvas(300, 110);
      const ctx = canvas.getContext("2d");

      // خلفية بيضاء
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // خطوط عشوائية (زخرفة)
      for (let i = 0; i < 20; i++) {
        ctx.beginPath();
        ctx.strokeStyle = `rgba(0,0,0,${Math.random()})`;
        ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
        ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
        ctx.stroke();
      }

      // نقاط عشوائية ملونة
      for (let i = 0; i < 150; i++) {
        ctx.beginPath();
        ctx.fillStyle = `rgba(${Math.floor(Math.random()*256)}, ${Math.floor(Math.random()*256)}, ${Math.floor(Math.random()*256)}, 0.6)`;
        ctx.arc(Math.random() * canvas.width, Math.random() * canvas.height, Math.random() * 3, 0, 2 * Math.PI);
        ctx.fill();
      }

      // كتابة الأرقام
      ctx.font = "bold 50px Arial";
      ctx.fillStyle = "#000000"; // أسود
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";

      const positions = [
        { x: 50, y: 55 },
        { x: 110, y: 55 },
        { x: 170, y: 55 },
        { x: 230, y: 55 }
      ];
      code.split("").forEach((digit, i) => {
        const { x, y } = positions[i];
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate((Math.random() * 0.6) - 0.3); // دوران خفيف
        ctx.fillText(digit, 0, 0);
        ctx.restore();
      });

      const attachment = new MessageAttachment(canvas.toBuffer(), "code.png");

      const confirmMsg = await message.reply({
        content: `🔐 To complete the transfer of **${amount.toLocaleString()} ${emoji.flag.soc}** to **${target.username}**, send the correct code shown in the image within 30 seconds.\nTransfer Fee: **${fee.toLocaleString()} ${emoji.flag.soc}**.`,
        files: [attachment]
      });

      const filter = m => m.author.id === senderId && m.content === code;
      try {
        const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
        await confirmMsg.delete();
        await collected.first().delete();

        await setBalance(senderId, senderBalance - amount);
        const targetBalance = await getBalance(target.id);
        await setBalance(target.id, targetBalance + finalAmount);

        const tx = {
          id: Date.now(),
          from: senderId,
          to: target.id,
          amount: finalAmount,
          fee,
          date: new Date().toISOString()
        };
        await logTransaction(senderId, tx);
        await logTransaction(target.id, tx);

        message.reply(`**:moneybag: | ${message.author.username}, has transferred \`${finalAmount.toLocaleString()}\`${emoji.flag.soc} to <@!${target.id}>**`);

        // Send DM to target
        try {
          await target.send(`:atm: | Transfer Receipt\n\`\`\`\nYou have received $${finalAmount.toLocaleString()} from user ${message.author.username} (ID: ${senderId})\n\n\`\`\``);
        } catch (e) {
          console.log(`Could not send DM to ${target.tag}.`);
        }

      } catch {
        return message.reply("❌ Time expired. Transfer cancelled.");
      }
    }
  }
};