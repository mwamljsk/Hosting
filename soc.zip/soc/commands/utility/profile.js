const { createCanvas, loadImage } = require('canvas');
const { MessageAttachment } = require('discord.js');
const path = require('path');

module.exports = {
  name: "profile",
  aliases: ["profile", "p"],
  description: "عرض بطاقة البروفايل",
  run: async (client, message, args) => {
    let typing = true;

    // بدء إظهار "يكتب..."
    const sendTypingLoop = async () => {
      while (typing) {
        await message.channel.sendTyping();
        await new Promise(r => setTimeout(r, 1000));
      }
    };
    sendTypingLoop();

    try {
      let user;
      if (args[0]) {
        if (args[0].startsWith("<@") && args[0].endsWith(">")) {
          user = message.mentions.users.first();
        } else {
          user = await client.users.fetch(args[0]);
        }
      } else {
        user = message.author;
      }

      const guild = message.guild;

      const xp = await client.db19.get(`xp_${user.id}`) || 0;
      const level = await client.db19.get(`level_${user.id}`) || 1;
      const rep = await client.db17.get(`rep_${user.id}`) || 0;
      const soc = await client.db17.get(`balance_${user.id}`) || 0;
      const rank = await client.db19.get(`rank_${user.id}`) || 9999999;

      function shortenNumber(num) {
        if (num >= 1e12) return (num / 1e12).toFixed(2) + 'T';
        if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
        if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
        if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
        return num.toString();
      }

      const nextLevelXP = (level + 1) * 150;
      const currentXP = xp % nextLevelXP;

      const canvas = createCanvas(400, 400);
      const ctx = canvas.getContext('2d');
      const bg = await loadImage(path.join(__dirname, './assets/profile.png'));
      ctx.drawImage(bg, 0, 0, canvas.width, canvas.height);

      const avatar = await loadImage(user.displayAvatarURL({ format: 'png', size: 256 }));
      ctx.save();
      ctx.beginPath();
      ctx.arc(80, 80, 55, 0, Math.PI * 2, true);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(avatar, 25, 25, 110, 110);
      ctx.restore();

      const guildIcon = await loadImage(guild.iconURL({ format: 'png', size: 128 }));
      ctx.save();
      ctx.beginPath();
      ctx.arc(180, 30, 20, 0, Math.PI * 2, true);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(guildIcon, 161, 11, 40, 40);
      ctx.restore();

      ctx.font = 'bold 20px Arial';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(user.username, 155, 78);

      ctx.font = 'bold 17px Arial';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`LVL`, 40, 170);
      ctx.font = 'bold 16px Arial';
      ctx.fillText(`${level}`, 40, 200);
      ctx.font = 'bold 17px Arial';
      ctx.fillText(`REP`, 40, 230);
      ctx.font = 'bold 16px Arial';
      ctx.fillText(`+${rep}`, 40, 260);
      ctx.font = 'bold 17px Arial';
      ctx.fillText(`SOC`, 40, 290);
      ctx.font = 'bold 16px Arial';
      ctx.fillText(`${shortenNumber(soc)}`, 40, 320);

      ctx.font = 'bold 9px Arial';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`TOTAL XP`, 280, 366);
      ctx.fillText(`${xp}`, 294, 379);

      const barX = 280;
      const barY = 340;
      const barWidth = 100;
      const barHeight = 15;
      const progress = currentXP / nextLevelXP;

      ctx.fillStyle = '#333';
      drawRoundedBar(ctx, barX, barY, barWidth, barHeight, 8);

      ctx.fillStyle = '#3d8bff';
      drawRoundedBar(ctx, barX, barY, barWidth * progress, barHeight, 8);

      ctx.font = 'bold 10px Arial';
      ctx.fillStyle = '#fff';
      ctx.fillText(`${currentXP} / ${nextLevelXP}`, barX + 5, barY + 12);

      const attachment = new MessageAttachment(canvas.toBuffer(), 'profile.png');

      typing = false; // إيقاف عرض "يكتب..."
      message.reply({ files: [attachment] });

    } catch (error) {
      typing = false;
      console.error("Error while generating profile:", error);
      message.reply("حدث خطأ أثناء إنشاء البطاقة!");
    }
  }
};

// دالة رسم مستطيل بزوايا دائرية
function drawRoundedBar(ctx, x, y, width, height, radius) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  ctx.fill();
}