const ms = require("ms");
const emoji = require('../../emoji.js');

module.exports = {

  name: "daily",
  aliases: ["daily", "راتب", "d"],
  description: "الحصول على مكافأة يومية",

  run: async (client, message) => {

    const db = client.db17;
    const userId = message.author.id;

    const cooldown = 24 * 60 * 60 * 1000; // 24 ساعة

    const lastClaim = await db.get(`dailySoc_${userId}`);
    if (lastClaim && Date.now() - lastClaim < cooldown) {
      const remaining = cooldown - (Date.now() - lastClaim);
      const hours = Math.floor(remaining / (1000 * 60 * 60));
      const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((remaining % (1000 * 60)) / 1000);

      return message.reply(`⏳ **لا يمكنك استخدام الأمر مجددًا إلا بعد مرور الوقت التالي: ${hours} ساعة و ${minutes} دقيقة و ${seconds} ثانية**`);

    }

    const reward = Math.floor(Math.random() * (5000 - 2000 + 1)) + 2000;
    const balance = await db.get(`balance_${userId}`) || 0;

    // إضافة المكافأة للرصيد
    await db.set(`balance_${userId}`, balance + reward);
    await db.set(`dailySoc_${userId}`, Date.now());

    return message.reply(`**مبروك!** لقد استلمت مكافأتك اليومية بقيمة **\`${reward}\`${emoji.flag.soc}**`);
  }
};