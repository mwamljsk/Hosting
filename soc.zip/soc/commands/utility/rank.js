const { Rank } = require('canvafy');

module.exports = {

  name: 'rank',
  aliases: ["rank", "رانك"],
  description: 'عرض بطاقة المستوى بتصميم أبيض أنيق',

  run: async (client, message, args) => {

    const db = client.db19;

    const user = message.mentions.users.first() || message.author;

    const guildId = message.guild.id;

    const userId = user.id;

    const xp = await db.get(`xp_${guildId}_${userId}`) || 0;

    const level = await db.get(`level_${guildId}_${userId}`) || 0;

    const requiredXp = level * 500;

    const all = await db.all();

    const leaderboard = all

      .filter(entry => entry.id.startsWith(`xp_${guildId}_`))

      .map(entry => ({

        id: entry.id.split("_")[2],

        xp: entry.value

      }))

      .sort((a, b) => b.xp - a.xp);

    const rank = leaderboard.findIndex(u => u.id === userId) + 1;

    try {

      const card = await new Rank()

        .setAvatar(user.displayAvatarURL({ extension: "png", forceStatic: true }))

        .setBackground("color", "#0e1621")
        .setUsername(user.username)
        .setLevel(level)
        .setRank(rank)
        .setCurrentXp(xp)
        .setRequiredXp(requiredXp)
        .setOverlayOpacity(0.3)
        .setBorder("#0e1621")
        //.setProgressBar("#3d8bff") 
        //.setAvatarBorder("#ffffff") // أبيض

        .build();

      message.channel.send({

        content: `**${user.username} - المستوى: ${level}, الرتبة: #${rank}, XP: ${xp}/${requiredXp}**`,

        files: [{ attachment: card, name: `rank-${userId}.png` }]

      });

    } catch (err) {

      console.error("خطأ في إنشاء البطاقة:", err);

      message.reply("حدث خطأ أثناء إنشاء بطاقة المستوى.");

    }

  }

};