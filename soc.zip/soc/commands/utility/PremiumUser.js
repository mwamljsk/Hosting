// أمر فقط للاختبار - لا تستخدمه لو الناس ما مفروض يشتروا بريميوم هيك فجأة

module.exports = {

  name: "prime",

  description: "تفعيل البرايم (للتجربة فقط)",

  run: async (client, message, args) => {

    await client.db17.set(`premium_${message.author.id}`, true);

    message.reply("تم تفعيل البرايم لحسابك.");

  }

};