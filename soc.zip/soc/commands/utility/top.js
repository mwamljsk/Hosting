const { AttachmentBuilder } = require("discord.js");

const { createCanvas, loadImage } = require("canvas");

const path = require("path");

const fs = require("fs");

module.exports = {

  name: "top_soc",

  description: "عرض أغنى 5 أشخاص بالصورة",

  usage: "top_soc",

  run: async (client, message) => {

    const db = client.db17;

    const emoji = require("../../emoji.js");

    await message.guild.members.fetch();
    const allData = await db.all();
    const balances = allData

  .filter(entry => entry.ID?.startsWith("balance_"))

  .map(entry => ({

    userId: entry.ID.split("_")[1],

    balance: Number(entry.value) || 0

  }))

  .filter(entry => entry.balance > 0);

    if (!balances.length) return message.reply("❌ لا يوجد أي بيانات حالياً.");

    balances.sort((a, b) => b.balance - a.balance);

    const top5 = balances.slice(0, 5);

    const userIndex = balances.findIndex(e => e.userId === message.author.id);

    const canvas = createCanvas(1000, 700);

    const ctx = canvas.getContext("2d");

    // تحميل خلفية

    const background = await loadImage("https://cdn.discordapp.com/attachments/1071028041054158888/1358694017646202981/478.png"); // صورة فخمة، ممكن تغيرها

    ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

    // تظليل الخلفية

    ctx.fillStyle = "rgba(0,0,0,0.6)";

    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // عنوان

    ctx.font = "bold 50px Cairo";

    ctx.fillStyle = "#ffffff";

    ctx.fillText(`أغنى 5 أشخاص بـ ${emoji.flag.soc}`, 50, 80);

    for (let i = 0; i < top5.length; i++) {

      const { userId, balance } = top5[i];

      let user;

      try {

        user = await client.users.fetch(userId);

      } catch {

        user = { username: "غير معروف", displayAvatarURL: () => null };

      }

      const y = 140 + i * 100;

      const isSelf = userId === message.author.id;

      // خلفية لكل صف

      ctx.fillStyle = isSelf ? "#1abc9c88" : "#2c3e5099";

      ctx.fillRect(50, y, 900, 85);

      // صورة البروفايل

      try {

        const avatarURL = user.displayAvatarURL({ extension: "jpg", size: 128 });

        const avatarImg = await loadImage(avatarURL);

        ctx.save();

        ctx.beginPath();

        ctx.arc(100, y + 42, 35, 0, Math.PI * 2, true);

        ctx.closePath();

        ctx.clip();

        ctx.drawImage(avatarImg, 65, y + 7, 70, 70);

        ctx.restore();

      } catch (e) {

        // لو الصورة ما تحملت، تجاهل

      }

      // الاسم

      ctx.font = isSelf ? "bold 28px Cairo" : "26px Cairo";

      ctx.fillStyle = isSelf ? "#ffffff" : "#ecf0f1";

      ctx.fillText(`#${i + 1} - ${user.username}`, 150, y + 50);

      // الرصيد

      ctx.font = "24px Cairo";

      ctx.fillStyle = "#f1c40f";

      ctx.fillText(`${balance.toLocaleString()} ${emoji.flag.soc}`, 750, y + 50);

    }

    // ترتيبك إن لم تكن ضمن الـ 5

    if (userIndex >= 5) {

      const self = balances[userIndex];

      const user = await client.users.fetch(self.userId).catch(() => null);

      ctx.fillStyle = "#d63031";

      ctx.font = "26px Cairo";

      ctx.fillText(`ترتيبك: #${userIndex + 1} | ${user?.username || "أنت"} | ${self.balance.toLocaleString()} ${emoji.flag.soc}`, 50, 660);

    }

    const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: "top_soc.png" });

    return message.reply({ files: [attachment] });

  }

};