const { MessageEmbed, MessageActionRow, MessageSelectMenu, MessageButton } = require('discord.js');
const { PremiumAccess } = require('../../owner.json');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');
const owner = Settings.bot.credits.developerId;
const voucher_codes = require("voucher-code-generator");

module.exports = {
  name: 'premium',
  run: async (client, message, args) => {
    const arypton = await client.users.fetch(owner);
    let prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;
    const user = message.guild.members.cache.get(args[1]) || message.mentions.members.first() || message.author;
    const ID = user.id

    const planOptions = new MessageActionRow().addComponents(
      new MessageSelectMenu()
        .setCustomId('planOption')
        .setPlaceholder(`Select a ${client.user.username} Premium Plan...`)
        .addOptions([
          {
            label: 'Trial (7d) - 100K soc',
            value: 'weekly',
            description: 'Duration: 7 days'
          },
          {
            label: 'Basic (28d) - 400K soc',
            value: 'monthly',
            description: 'Duration: 28 days'
          },
          {
            label: 'Professional (3m) - 1.2M soc',
            value: 'monthlyx3',
            description: 'Duration: 84 days'
          },
          {
            label: 'Enterprise (1y) - 50M soc',
            value: 'yearly',
            description: 'Duration: 336 days'
          },
          {
            label: 'Godlike (69y) - 200M soc',
            value: 'lifetime',
            description: 'Duration: 69 years'
          },
        ])
    )

    const data = await client.db12.get(`premium`);
    if (!data) {
      await client.db12.set(`premium`, { premiumServers: [] });
      return message.channel.send({ content: `Please use this command again.` });
    }

    const guide = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(`${client.user.username}`, client.user.displayAvatarURL())
      .setThumbnail(client.user.displayAvatarURL())
      .addField(`${emoji.util.arrow} \`premium\``, `Shows the guide embed for the module .`)
      .addField(`${emoji.util.arrow} \`premium redeem\``, `Redeem premium code .`)
      .addField(`${emoji.util.arrow} \`premium status\``, `Check the premium status of the server.`)
      .addField(`${emoji.util.arrow} \`premium purchase\``, `Purchase the Premium Codes for your server.`)
      .addField(`${emoji.util.arrow} \`premium features\``, `See the Premium Features for your server.`)
      .setFooter(`Made by 1hp-services with 💞`, arypton.displayAvatarURL({ dynamic: true }));

    const subcommand = args[0];

    switch (subcommand) {
      case undefined:
        return message.channel.send({ embeds: [guide] });
      case 'gencode':
        let plan;
        let planSelected;
        let time;
        let bill;

        if (!PremiumAccess.includes(message.author.id)) {
          return message.channel.send({ content: `Not for you silly ;-;.` });
        }

        let msg = await message.channel.send({ content: `Please select the ${client.user.username} Premium plan, you want to opt:`, components: [planOptions] });

        const collector = await msg.createMessageComponentCollector({
          filter: (interaction) => {
            if (message.author.id === interaction.user.id) return true;
            else {
              return interaction.reply({ content: `${emoji.util.cross} | This Pagination is not for you.`, ephemeral: true })
            }
          },
          time: 200000,
          idle: 300000 / 2
        });

        collector.on('collect', async (interaction) => {
          if (interaction.isSelectMenu()) {
            for (const value of interaction.values) {
              if (value === `weekly`) {
                time = Date.now() + 86400000 * 7;
                planSelected = 'Trial (7d)';
                plan = 'trial'
                bill = '100K soc';
                const codePremium = voucher_codes.generate({
                  postfix: "-krypton",
                  pattern: "####-####-####-####-####-####",
                  charset: "alphanumeric"
                });
                const code = codePremium.toString().toUpperCase();

                const billReceipt = new MessageEmbed()
                  .setColor(client.color)
                  .setTitle(`Premium Code Purchase Receipt`)
                  .addField(`Customer`, `<@${ID}>`)
                  .addField(`Plan`, planSelected)
                  .addField(`Code`, `\`\`\`js\n${code}\`\`\``)
                  .addField(`Expire At`, `<t:${Math.floor(time / 1000)}:F>`)
                  .addField(`Bill`, `${bill}`)
                  .setFooter(`To redeem, use ${prefix}premium redeem <code>`, client.user.displayAvatarURL());

                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await msg.edit({ content: `This redeem code will be usable till <t:${Math.floor(time / 1000)}:F>`, components: [planOptions] });
                await interaction.reply({ embeds: [billReceipt] });
                await client.db12.set(`${code}`, {
                  plan: plan,
                  codeExpiresAt: time,
                  active: true,
                  redeemedAt: null
                });
              } else if (value === `monthly`) {
                time = Date.now() + 86400000 * 28;
                planSelected = 'Basic (28d)';
                plan = 'monthly';
                bill = '400K soc';
                const codePremium = voucher_codes.generate({
                  postfix: "-krypton",
                  pattern: "####-####-####-####-####-####",
                  charset: "alphanumeric"
                });
                const code = codePremium.toString().toUpperCase();

                const billReceipt = new MessageEmbed()
                  .setColor(client.color)
                  .setTitle(`Premium Code Purchase Receipt`)
                  .addField(`Customer`, `<@${ID}>`)
                  .addField(`Plan`, planSelected)
                  .addField(`Code`, `\`\`\`js\n${code}\`\`\``)
                  .addField(`Expire At`, `<t:${Math.floor(time / 1000)}:F>`)
                  .addField(`Bill`, `${bill}`)
                  .setFooter(`To redeem, use ${prefix}premium redeem <code>`, client.user.displayAvatarURL());

                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await msg.edit({ content: `This redeem code will be usable till <t:${Math.floor(time / 1000)}:F>`, components: [planOptions] });
                await interaction.reply({ embeds: [billReceipt] });
                await client.db12.set(`${code}`, {
                  plan: plan,
                  codeExpiresAt: time,
                  active: true,
                  redeemedAt: null
                });
              } else if (value === `monthlyx3`) {
                time = Date.now() + 86400000 * 84;
                planSelected = 'Professional (84d)';
                plan = 'monthlyx3';
                bill = '1.2M soc';
                const codePremium = voucher_codes.generate({
                  postfix: "-krypton",
                  pattern: "####-####-####-####-####-####",
                  charset: "alphanumeric"
                });
                const code = codePremium.toString().toUpperCase();

                const billReceipt = new MessageEmbed()
                  .setColor(client.color)
                  .setTitle(`Premium Code Purchase Receipt`)
                  .addField(`Customer`, `<@${ID}>`)
                  .addField(`Plan`, planSelected)
                  .addField(`Code`, `\`\`\`js\n${code}\`\`\``)
                  .addField(`Expire At`, `<t:${Math.floor(time / 1000)}:F>`)
                  .addField(`Bill`, `${bill}`)
                  .setFooter(`To redeem, use ${prefix}premium redeem <code>`, client.user.displayAvatarURL());

                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await msg.edit({ content: `This redeem code will be usable till <t:${Math.floor(time / 1000)}:F>`, components: [planOptions] });
                await interaction.reply({ embeds: [billReceipt] });
                await client.db12.set(`${code}`, {
                  plan: plan,
                  codeExpiresAt: time,
                  active: true,
                  redeemedAt: null
                });
              } else if (value === `yearly`) {
                time = Date.now() + 86400000 * 336;
                planSelected = 'Enterprise (336d)';
                plan = 'yearly';
                bill = '50M soc';
                const codePremium = voucher_codes.generate({
                  postfix: "-krypton",
                  pattern: "####-####-####-####-####-####",
                  charset: "alphanumeric"
                });
                const code = codePremium.toString().toUpperCase();

                const billReceipt = new MessageEmbed()
                  .setColor(client.color)
                  .setTitle(`Premium Code Purchase Receipt`)
                  .addField(`Customer`, `<@${ID}>`)
                  .addField(`Plan`, planSelected)
                  .addField(`Code`, `\`\`\`js\n${code}\`\`\``)
                  .addField(`Expire At`, `<t:${Math.floor(time / 1000)}:F>`)
                  .addField(`Bill`, `${bill}`)
                  .setFooter(`To redeem, use ${prefix}premium redeem <code>`, client.user.displayAvatarURL());

                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await msg.edit({ content: `This redeem code will be usable till <t:${Math.floor(time / 1000)}:F>`, components: [planOptions] });
                await interaction.reply({ embeds: [billReceipt] });
                await client.db12.set(`${code}`, {
                  plan: plan,
                  codeExpiresAt: time,
                  active: true,
                  redeemedAt: null
                });
              } else if (value === `lifetime`) {
                time = Date.now() + 86400000 * 336 * 69;
                planSelected = 'Godlike (69y)';
                plan = 'lifetime'
                bill = '200M soc';
                const codePremium = voucher_codes.generate({
                  postfix: "-krypton",
                  pattern: "####-####-####-####-####-####",
                  charset: "alphanumeric"
                });
                const code = codePremium.toString().toUpperCase();

                const billReceipt = new MessageEmbed()
                  .setColor(client.color)
                  .setTitle(`Premium Code Purchase Receipt`)
                  .addField(`Customer`, `<@${ID}>`)
                  .addField(`Plan`, planSelected)
                  .addField(`Code`, `\`\`\`js\n${code}\`\`\``)
                  .addField(`Expire At`, `<t:${Math.floor(time / 1000)}:F>`)
                  .addField(`Bill`, `${bill}`)
                  .setFooter(`To redeem, use ${prefix}premium redeem <code>`, client.user.displayAvatarURL());

                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await msg.edit({ content: `This redeem code will be usable till <t:${Math.floor(time / 1000)}:F>`, components: [planOptions] });
                await interaction.reply({ embeds: [billReceipt] });
                await client.db12.set(`${code}`, {
                  plan: plan,
                  codeExpiresAt: time,
                  active: true,
                  redeemedAt: null
                });
              }
            }
          }
        });
        break;
      case 'redeem':
        const redeemCode = args.slice(1).join(" ");
        const data = await client.db12.get(`${redeemCode}`);
        const dataPremium = await client.db12.get(`${message.guild.id}_premium`);
        const premiumServer = await client.db12.get(`premium`);
        let alreadyPremium;
        let codePlan;
        let codeExpiry;
        let codeActive;
        let premiumActive;
        let samay;

        if (!data) {
          return message.channel.send({ content: `${emoji.util.cross} | The code you provided is invalid. Please try again by using a valid one!` });
        }

        codePlan = data.plan;
        codeExpiry = data.codeExpiresAt;
        codeActive = data.active;
        premiumActive = dataPremium.active;
        alreadyPremium = dataPremium.premiumExpiresAt;

        if (codeActive === false) {
          return message.channel.send({ content: `${emoji.util.cross} | This code is already being used. | Purchase a new one.` });
        }

        if (Date.now() >= codeExpiry) {
          return message.channel.send({ content: `${emoji.util.cross} | This code is expired.` });
        }

        if (codePlan === 'trial') {
          if (premiumActive === true) {
            samay = alreadyPremium + 86400000 * 7;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          } else {
            samay = Date.now() + 86400000 * 7;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          }
        } else if (codePlan === 'monthly') {
          if (premiumActive === true) {
            samay = alreadyPremium + 86400000 * 28;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          } else {
            samay = Date.now() + 86400000 * 28;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          }
        } else if (codePlan === 'monthlyx3') {
          if (premiumActive === true) {
            samay = alreadyPremium + 86400000 * 84;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          } else {
            samay = Date.now() + 86400000 * 84;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          }
        } else if (codePlan === 'yearly') {
          if (premiumActive === true) {
            samay = alreadyPremium + 86400000 * 336;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          } else {
            samay = Date.now() + 86400000 * 336;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          }
        } else if (codePlan === 'lifetime') {
          if (premiumActive === true) {
            samay = alreadyPremium + 86400000 * 336 * 69;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully extended premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          } else {
            samay = Date.now() + 86400000 * 336 * 69;
            await client.db12.set(`${redeemCode}`, {
              plan: codePlan,
              codeExpiresAt: codeExpiry,
              active: false,
              redeemedAt: Date.now()
            });
            await client.db12.set(`${message.guild.id}_premium`, {
              active: true,
              premiumExpiresAt: samay,
            });
            if (!premiumServer.premiumServers.includes(message.guild.id)) {
              await client.db12.push(`premium.premiumServers`, message.guild.id);
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            } else {
              message.channel.send({ content: `${emoji.util.tick} | Successfully activated premium for this server.\nPremium will expire on <t:${Math.floor(samay / 1000)}:F>` });
            }
          }
        }
        break;
            /*
      case 'purchase':
        let msg1 = await message.channel.send({ content: `Please select the ${client.user.username} Premium plan, you want to opt:`, components: [planOptions] });

        const collector1 = await msg1.createMessageComponentCollector({
          filter: (interaction) => {
            if (message.author.id === interaction.user.id) return true;
            else {
              return interaction.reply({ content: `${emoji.util.cross} | This Pagination is not for you.`, ephemeral: true })
            }
          },
          time: 200000,
          idle: 300000 / 2
        });

        collector1.on('collect', async (interaction) => {
          if (interaction.isSelectMenu()) {
            for (const value of interaction.values) {
              if (value === `weekly`) {
                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await interaction.reply({ content: `You are about to purchase **${client.user.username} Trial Premium Code**\n\n[*Click Me to Continue the Payment Process*](https://discord.gg/gwZunABahx)`, ephemeral: true });
                await msg1.edit({ components: [planOptions] });
              } else if (value === `monthly`) {
                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await interaction.reply({ content: `You are about to purchase **${client.user.username} Monthly Premium Code**\n\n[*Click Me to Continue the Payment Process*](https://discord.gg/gwZunABahx)`, ephemeral: true });
                await msg1.edit({ components: [planOptions] });
              } else if (value === `monthlyx3`) {
                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await interaction.reply({ content: `You are about to purchase **${client.user.username} Monthlyx3 Premium Code**\n\n[*Click Me to Continue the Payment Process*](https://discord.gg/gwZunABahx)`, ephemeral: true });
                await msg1.edit({ components: [planOptions] });
              } else if (value === `yearly`) {
                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await interaction.reply({ content: `You are about to purchase **${client.user.username} Yearly Premium Code**\n\n[*Click Me to Continue the Payment Process*](https://discord.gg/gwZunABahx)`, ephemeral: true });
                await msg1.edit({ components: [planOptions] });
              } else if (value === `lifetime`) {
                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await interaction.reply({ content: `You are about to purchase **${client.user.username} Lifetime Premium Code**\n\n[*Click Me to Continue the Payment Process*](https://discord.gg/gwZunABahx)`, ephemeral: true });
                await msg1.edit({ components: [planOptions] });
              }
            }
          }
        });
        break;
        
      case 'purchase':
    let msg1 = await message.channel.send({ content: `Please select the ${client.user.username} Premium plan, you want to opt:`, components: [planOptions] });

    const collector1 = await msg1.createMessageComponentCollector({
        filter: (interaction) => {
            if (message.author.id === interaction.user.id) return true;
            else {
                return interaction.reply({ content: `${emoji.util.cross} | This Pagination is not for you.`, ephemeral: true });
            }
        },
        time: 200000,
        idle: 300000 / 2
    });

    collector1.on('collect', async (interaction) => {
        if (interaction.isSelectMenu()) {
            const userId = interaction.user.id;
            let planSelected;
            let price;
            
            // تحديد الخطة المختارة والسعر
            switch (interaction.values[0]) {
                case 'weekly':
                    planSelected = 'Trial Premium';
                    price = 70000; // السعر بالوحدات الخاصة بـ soc
                    break;
                case 'monthly':
                    planSelected = 'Monthly Premium';
                    price = 150000;
                    break;
                case 'monthlyx3':
                    planSelected = '3-Month Premium';
                    price = 1000000;
                    break;
                case 'yearly':
                    planSelected = 'Yearly Premium';
                    price = 3000000;
                    break;
                case 'lifetime':
                    planSelected = 'Lifetime Premium';
                    price = 10000000;
                    break;
                default:
                    return interaction.reply({ content: `Invalid plan selected.`, ephemeral: true });
            }

            // التحقق من رصيد المستخدم
            const userBalance = await client.db17.get(`balance_${userId}`);
            if (userBalance < price) {
                return interaction.reply({ content: `You do not have enough balance to purchase the ${planSelected}. Your balance is: ${userBalance} SOC.`, ephemeral: true });
            }

            // خصم المبلغ من الرصيد
            await client.db17.set(`balance_${userId}`, userBalance - price);

            // إنشاء كود البريميوم
            const voucher_code = voucher_codes.generate({
                postfix: "-krypton",
                pattern: "####-####-####-####-####-####",
                charset: "alphanumeric"
            });
            const code = voucher_code.toString().toUpperCase();

            // إرسال رسالة التأكيد
            const billReceipt = new MessageEmbed()
                .setColor(client.color)
                .setTitle(`Premium Code Purchase Receipt`)
                .addField(`Customer`, `<@${userId}>`)
                .addField(`Plan`, planSelected)
                .addField(`Code`, `\`\`\`js\n${code}\`\`\``)
                .addField(`Bill`, `${price} SOC`)
                .setFooter(`To redeem, use ${prefix}premium redeem <code>`, client.user.displayAvatarURL());

            // تحديث الرسالة
            const lastButton = planOptions.components.find((component) => component.customId === "planOption");
            lastButton.setDisabled(true);
            await msg1.edit({ components: [planOptions] });

            await interaction.reply({ embeds: [billReceipt] });

            // تخزين الكود البريميوم في قاعدة البيانات
            await client.db12.set(`${code}`, {
                plan: planSelected,
                active: true,
                redeemedAt: null
            });

            message.channel.send({ content: `You have successfully purchased the ${planSelected} plan. Use the code ${code} to redeem your premium.` });
        }
    });
    break;
      case 'purchase':
    let plan;
    let planSelected;
    let time;
    let bill;

    // إرسال رسالة لاختيار الخطة
    let msg = await message.channel.send({ content: `Please select the ${client.user.username} Premium plan you want to opt for:`, components: [planOptions] });

    const collector = await msg.createMessageComponentCollector({
        filter: (interaction) => {
            if (message.author.id === interaction.user.id) return true;
            else {
                return interaction.reply({ content: `${emoji.util.cross} | This pagination is not for you.`, ephemeral: true })
            }
        },
        time: 200000,
        idle: 300000 / 2
    });

    collector.on('collect', async (interaction) => {
        if (interaction.isSelectMenu()) {
            for (const value of interaction.values) {
                // تحديد الخطة التي تم اختيارها
                if (value === `weekly`) {
                    time = Date.now() + 86400000 * 7;
                    planSelected = 'Trial (7d)';
                    plan = 'trial';
                    bill = 70000; // SOC
                } else if (value === `monthly`) {
                    time = Date.now() + 86400000 * 28;
                    planSelected = 'Basic (28d)';
                    plan = 'monthly';
                    bill = 150000; // SOC
                } else if (value === `monthlyx3`) {
                    time = Date.now() + 86400000 * 84;
                    planSelected = 'Professional (84d)';
                    plan = 'monthlyx3';
                    bill = 3000000; // SOC
                } else if (value === `yearly`) {
                    time = Date.now() + 86400000 * 336;
                    planSelected = 'Enterprise (336d)';
                    plan = 'yearly';
                    bill = 5000000; // SOC
                } else if (value === `lifetime`) {
                    time = Date.now() + 86400000 * 336 * 69;
                    planSelected = 'Godlike (69y)';
                    plan = 'lifetime';
                    bill = 10000000; // SOC
                }

                // التحقق من رصيد الـ SOC
                const userBalance = await db17.get(`balance_${message.author.id}`);
                
                if (userBalance < bill) {
                    return interaction.reply({ content: `You don't have enough SOC to purchase the **${planSelected}** plan.`, ephemeral: true });
                }

                // خصم المبلغ من رصيد المستخدم
                await db17.set(`balance_${message.author.id}`, userBalance - bill);

                // إنشاء كود التفعيل
                const codePremium = voucher_codes.generate({
                    postfix: "-krypton",
                    pattern: "####-####-####-####-####-####",
                    charset: "alphanumeric"
                });
                const code = codePremium.toString().toUpperCase();

                // رسالة تأكيد الشراء
                const billReceipt = new MessageEmbed()
                    .setColor(client.color)
                    .setTitle(`Premium Code Purchase Receipt`)
                    .addField(`Customer`, `<@${message.author.id}>`)
                    .addField(`Plan`, planSelected)
                    .addField(`Code`, `\`\`\`js\n${code}\`\`\``)
                    .addField(`Expire At`, `<t:${Math.floor(time / 1000)}:F>`)
                    .addField(`Bill`, `${bill} SOC`)
                    .setFooter(`To redeem, use ${prefix}premium redeem <code>`, client.user.displayAvatarURL());

                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await msg.edit({ content: `This redeem code will be usable till <t:${Math.floor(time / 1000)}:F>`, components: [planOptions] });

                // إرسال رسالة المخفية للمستخدم
                await interaction.reply({ content: 'Your purchase was successful! Please check your DMs for the code.', ephemeral: true });

                // إرسال الكود للمستخدم في الخاص
                await message.author.send({ embeds: [billReceipt] });

                // تخزين كود البريميوم في قاعدة البيانات
                await client.db12.set(`${code}`, {
                    plan: plan,
                    codeExpiresAt: time,
                    active: true,
                    redeemedAt: null
                });
            }
        }
    });
    break;
      case 'purchase':
    
    let planSelected;
    let time;
    let bill;

    // إرسال رسالة لاختيار الخطة
    let msg = await message.channel.send({ content: `Please select the ${client.user.username} Premium plan you want to opt for:`, components: [planOptions] });

    const collector = await msg.createMessageComponentCollector({
        filter: (interaction) => {
            if (message.author.id === interaction.user.id) return true;
            else {
                return interaction.reply({ content: `${emoji.util.cross} | This pagination is not for you.`, ephemeral: true })
            }
        },
        time: 200000,
        idle: 300000 / 2
    });

    collector.on('collect', async (interaction) => {
        if (interaction.isSelectMenu()) {
            for (const value of interaction.values) {
                // تحديد الخطة التي تم اختيارها
                if (value === `weekly`) {
                    time = Date.now() + 86400000 * 7;
                    planSelected = 'Trial (7d)';
                    plan = 'trial';
                    bill = 70000; // SOC
                } else if (value === `monthly`) {
                    time = Date.now() + 86400000 * 28;
                    planSelected = 'Basic (28d)';
                    plan = 'monthly';
                    bill = 150000; // SOC
                } else if (value === `monthlyx3`) {
                    time = Date.now() + 86400000 * 84;
                    planSelected = 'Professional (84d)';
                    plan = 'monthlyx3';
                    bill = 3000000; // SOC
                } else if (value === `yearly`) {
                    time = Date.now() + 86400000 * 336;
                    planSelected = 'Enterprise (336d)';
                    plan = 'yearly';
                    bill = 5000000; // SOC
                } else if (value === `lifetime`) {
                    time = Date.now() + 86400000 * 336 * 69;
                    planSelected = 'Godlike (69y)';
                    plan = 'lifetime';
                    bill = 10000000; // SOC
                }

                // التحقق من رصيد الـ SOC
                const userBalance = await db17.get(`balance_${message.author.id}`);
                
                if (userBalance < bill) {
                    return interaction.reply({ content: `You don't have enough SOC to purchase the **${planSelected}** plan.`, ephemeral: true });
                }

                // خصم المبلغ من رصيد المستخدم
                await db17.set(`balance_${message.author.id}`, userBalance - bill);

                // إنشاء كود التفعيل
                const codePremium = voucher_codes.generate({
                    postfix: "-krypton",
                    pattern: "####-####-####-####-####-####",
                    charset: "alphanumeric"
                });
                const code = codePremium.toString().toUpperCase();

                // رسالة تأكيد الشراء
                const billReceipt = new MessageEmbed()
                    .setColor(client.color)
                    .setTitle(`Premium Code Purchase Receipt`)
                    .addField(`Customer`, `<@${message.author.id}>`)
                    .addField(`Plan`, planSelected)
                    .addField(`Code`, `\`\`\`js\n${code}\`\`\``)
                    .addField(`Expire At`, `<t:${Math.floor(time / 1000)}:F>`)
                    .addField(`Bill`, `${bill} SOC`)
                    .setFooter(`To redeem, use ${prefix}premium redeem <code>`, client.user.displayAvatarURL());

                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await msg.edit({ content: `This redeem code will be usable till <t:${Math.floor(time / 1000)}:F>`, components: [planOptions] });

                // إرسال رسالة المخفية للمستخدم
                await interaction.reply({ content: 'Your purchase was successful! Please check your DMs for the code.', ephemeral: true });

                // إرسال الكود للمستخدم في الخاص
                await message.author.send({ embeds: [billReceipt] });

                // تخزين كود البريميوم في قاعدة البيانات
                await client.db12.set(`${code}`, {
                    plan: plan,
                    codeExpiresAt: time,
                    active: true,
                    redeemedAt: null
                });
            }
        }
    });
    break;*/
      case 'purchase':
    let selectedPlan;
    let planName;
    let expirationTime;
    let totalCost;

    // إرسال رسالة لاختيار الخطة
    let purchaseMessage = await message.channel.send({ content: `Please select the ${client.user.username} Premium plan you want to opt for:`, components: [planOptions] });

    const collectorP = await purchaseMessage.createMessageComponentCollector({
        filter: (interaction) => {
            if (message.author.id === interaction.user.id) return true;
            else {
                return interaction.reply({ content: `${emoji.util.cross} | This pagination is not for you.`, ephemeral: true })
            }
        },
        time: 200000,
        idle: 300000 / 2
    });

    collectorP.on('collect', async (interaction) => {
        if (interaction.isSelectMenu()) {
            for (const value of interaction.values) {
                // تحديد الخطة التي تم اختيارها
                if (value === `weekly`) {
                    expirationTime = Date.now() + 86400000 * 7;
                    planName = 'Trial (7d)';
                    selectedPlan = 'trial';
                    totalCost = 100000; // SOC
                } else if (value === `monthly`) {
                    expirationTime = Date.now() + 86400000 * 28;
                    planName = 'Basic (28d)';
                    selectedPlan = 'monthly';
                    totalCost = 400000; // SOC
                } else if (value === `monthlyx3`) {
                    expirationTime = Date.now() + 86400000 * 84;
                    planName = 'Professional (84d)';
                    selectedPlan = 'monthlyx3';
                    totalCost = 3000000; // SOC
                } else if (value === `yearly`) {
                    expirationTime = Date.now() + 86400000 * 336;
                    planName = 'Enterprise (336d)';
                    selectedPlan = 'yearly';
                    totalCost = 50000000; // SOC
                } else if (value === `lifetime`) {
                    expirationTime = Date.now() + 86400000 * 336 * 69;
                    planName = 'Godlike (69y)';
                    selectedPlan = 'lifetime';
                    totalCost = 200000000; // SOC
                }

                // التحقق من رصيد الـ SOC
                const userBalance = await client.db17.get(`balance_${message.author.id}`);
                
                if (userBalance < totalCost) {
                    return interaction.reply({ content: `You don't have enough SOC to purchase the **${planName}** plan.`, ephemeral: true });
                }

                // خصم المبلغ من رصيد المستخدم
                await client.db17.set(`balance_${message.author.id}`, userBalance - totalCost);

                // إنشاء كود التفعيل
                const codePremium = voucher_codes.generate({
                    postfix: "-krypton",
                    pattern: "####-####-####-####-####-####",
                    charset: "alphanumeric"
                });
                const code = codePremium.toString().toUpperCase();

                // رسالة تأكيد الشراء
                const billReceipt = new MessageEmbed()
                    .setColor(client.color)
                    .setTitle(`Premium Code Purchase Receipt`)
                    .addField(`Customer`, `<@${message.author.id}>`)
                    .addField(`Plan`, planName)
                    .addField(`Code`, `${code}`)
                    .addField(`Expire At`, `<t:${Math.floor(expirationTime / 1000)}:F>`)
                    .addField(`Bill`, `${totalCost} SOC`)
                    .setFooter(`To redeem, use ${prefix}premium redeem <code>`, client.user.displayAvatarURL());

                const lastButton = planOptions.components.find((component) => component.customId === "planOption");
                lastButton.setDisabled(true);
                await purchaseMessage.edit({ content: `This redeem code will be usable till <t:${Math.floor(expirationTime / 1000)}:F>`, components: [planOptions] });

                // إرسال رسالة المخفية للمستخدم
                await interaction.reply({ content: 'Your purchase was successful! Please check your DMs for the code.', ephemeral: true });

                // إرسال الكود للمستخدم في الخاص
                await message.author.send({ embeds: [billReceipt] });

                // تخزين كود البريميوم في قاعدة البيانات
                await client.db12.set(`${code}`, {
                    plan: selectedPlan,
                    codeExpiresAt: expirationTime,
                    active: true,
                    redeemedAt: null
                });
            }
        }
    });
    break;
            
      case 'status':
  const premiumData = await client.db12.get(`${message.guild.id}_premium`);

  if (!premiumData || premiumData.active === false) {
    const noPremium = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(message.guild.name, message.guild.iconURL({ dynamic: true }))
      .addField('Server', '> Activated: No!')
      .addField('Premium Features', `
> hideall: ${emoji.util.cross}
> unhideall: ${emoji.util.cross}
> lockall: ${emoji.util.cross}
> unlockall: ${emoji.util.cross}
> Logs Premium: ${emoji.util.cross}
> stealall Emoji: ${emoji.util.cross}
> unbanall: ${emoji.util.cross}
> Antinuke Prune: ${emoji.util.cross}
> Antinuke Autorecovery:  ${emoji.util.cross}
> Antinuke Whitelist Limit 100: ${emoji.util.cross}
> Autorole Humans Limit 10: ${emoji.util.cross}
> Autorole Bots Limit 10: ${emoji.util.cross}
> Extra Owner Limit 100: ${emoji.util.cross}
> Extra Admin Limit 100: ${emoji.util.cross}
> Ignore Channel Limit 100: ${emoji.util.cross}
> Ignore Bypass Limit 100: ${emoji.util.cross}
> Nightmode Role Limit 100: ${emoji.util.cross}
> Nightmode Bypass Limit 100: ${emoji.util.cross}
> Media Channel Limit 100: ${emoji.util.cross}`, false)
      .setFooter(message.guild.name, message.guild.iconURL({ dynamic: true }));

    message.channel.send({ embeds: [noPremium] });
  } else {
    const ending = premiumData.premiumExpiresAt;
    const yesPremium = new MessageEmbed()
      .setColor(client.color)
      .setAuthor(message.guild.name, message.guild.iconURL({ dynamic: true }))
      .addField('Server', `> Activated: Yes!\n> Ending: <t:${Math.floor(ending / 1000)}:F>`, false)
      .addField('Premium Features', `
> hideall: ${emoji.util.tick}
> unhideall: ${emoji.util.tick}
> lockall: ${emoji.util.tick}
> unlockall: ${emoji.util.tick}
> Logs Premium: ${emoji.util.tick}
> stealall Emoji: ${emoji.util.tick}
> unbanall: ${emoji.util.tick}
> Antinuke Prune: ${emoji.util.tick}
> Antinuke Autorecovery: ${emoji.util.tick}
> Antinuke Whitelist Limit 100: ${emoji.util.tick}
> Autorole Humans Limit 10: ${emoji.util.tick}
> Autorole Bots Limit 10: ${emoji.util.tick}
> Extra Owner Limit 100: ${emoji.util.tick}
> Extra Admin Limit 100: ${emoji.util.tick}
> Ignore Channel Limit 100: ${emoji.util.tick}
> Ignore Bypass Limit 100: ${emoji.util.tick}
> Nightmode Role Limit 100: ${emoji.util.tick}
> Nightmode Bypass Limit 100: ${emoji.util.tick}
> Media Channel Limit 100: ${emoji.util.tick}`, false)
      .setFooter(message.guild.name, message.guild.iconURL({ dynamic: true }));

    message.channel.send({ embeds: [yesPremium] });
  }
  break;
  case 'features':
  case 'feature':

  const premiumFeatures = new MessageEmbed()
    .setColor(client.color)
    .setTitle(`Premium Features for ${client.user.username}`)
    .setDescription(`With ${client.user.username} Premium, you get access to the following features:`)
    .addField('Antinuke Prune', `> ${emoji.util.tick} accessible`, true)
    .addField('Premium LOGS', `> ${emoji.util.tick} Active`, true)
    .addField('Antinuke Autorecovery', `> ${emoji.util.tick} accessible`, true)
    .addField('Antinuke Whitelist Limit', `> ${emoji.util.tick} 100`, true)
    .addField('Autorole Humans Limit', `> ${emoji.util.tick} 10`, true)
    .addField('Autorole Bots Limit', `> ${emoji.util.tick} 10`, true)
    .addField('Extra Owner Limit', `> ${emoji.util.tick} 100`, true)
    .addField('Extra Admin Limit', `> ${emoji.util.tick} 100`, true)
    .addField('Ignore Channel Limit', `> ${emoji.util.tick} 100`, true)
    .addField('Ignore Bypass Limit', `> ${emoji.util.tick} 100`, true)
    .addField('Nightmode Role Limit', `> ${emoji.util.tick} 100`, true)
    .addField('Nightmode Bypass Limit', `> ${emoji.util.tick} 100`, true)
    .addField('Media Channel Limit', `> ${emoji.util.tick} 100`, true)
    .setFooter(`Enjoy the enhanced features with ${client.user.username} Premium!`, client.user.displayAvatarURL());

  await message.channel.send({ embeds: [premiumFeatures] });
  break;

      default:
        message.channel.send('Invalid command usage.');
        break;
    }
  }
};
