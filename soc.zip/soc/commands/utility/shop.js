const { MessageEmbed, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const fs = require('fs');

module.exports = {
  name: 'shop',
  description: 'عرض المتجر وشراء المنتجات باستخدام عملة balance',
  run: async (client, message, args) => {
    const db = client.db20;
    
    // تحقق إذا كان المستخدم أدمن
    const isAdmin = message.member.permissions.has('ADMINISTRATOR');
    const userId = message.author.id;

    // استرجاع المنتجات من قاعدة البيانات
    let items = await db.get(`shop_items_${message.guild.id}`) || [];
    // استرجاع الخصومات
    let discounts = await db.get('active_discounts') || [];

    // عرض متجر الأدمن
    if (isAdmin) {
      const adminEmbed = new MessageEmbed()
        .setTitle('لوحة التحكم - متجر Balance')
        .setColor('GREEN')
        .setDescription('إدارة المتجر')
        .addField('المنتجات الحالية:', items.length > 0 ? items.map(item => `**${item.id}**: ${item.name}`).join('\n') : 'لا توجد منتجات في المتجر.')
        .addField('الخصومات الحالية:', discounts.length > 0 ? discounts.map(discount => `**${discount.code}**: ${discount.discount}%`).join('\n') : 'لا توجد خصومات حاليًا.')
        .addField('التصنيفات:', 'يمكنك إضافة تصنيفات للمنتجات (مثال: أسلحة، أدوات، ترقيات).')
        .addField('الأوامر المتاحة:', `- إضافة منتج\n- إضافة خصم\n- إزالة منتج\n- مشاهدة تقارير المبيعات`);

      const adminRow = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('view_user_shop')
            .setLabel('عرض قائمة المستخدمين')
            .setStyle(ButtonStyle.Secondary),
          new ButtonBuilder()
            .setCustomId('add_item')
            .setLabel('إضافة منتج')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('add_discount')
            .setLabel('إضافة خصم')
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId('remove_item')
            .setLabel('إزالة منتج')
            .setStyle(ButtonStyle.Danger)
        );

      return message.channel.send({ embeds: [adminEmbed], components: [adminRow] });
    }

    // إذا كان المستخدم عادي
    const userEmbed = new MessageEmbed()
      .setTitle('متجر Balance')
      .setColor('BLUE')
      .setDescription(items.length > 0 ? items.map(item =>
        `**[${item.id}] ${item.name}**\nالسعر: ${item.price} Balance\nالجوائز: ${item.reward}`).join('\n\n') : 'لا توجد منتجات للعرض.');

    const userRow = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('buy_item')
          .setLabel('شراء منتج')
          .setStyle(ButtonStyle.Success)
      );

    // عرض المنتجات للمستخدم
    message.channel.send({ embeds: [userEmbed], components: [userRow] });
  }
};

// التعامل مع الأزرار
module.exports.handleButtonInteraction = async (interaction) => {
  const db = interaction.client.db20;

  // عرض متجر المستخدم
  if (interaction.customId === 'view_user_shop') {
    const items = await db.get(`shop_items_${interaction.guild.id}`) || [];
    const userEmbed = new MessageEmbed()
      .setTitle('متجر Balance')
      .setColor('BLUE')
      .setDescription(items.length > 0 ? items.map(item =>
        `**[${item.id}] ${item.name}**\nالسعر: ${item.price} Balance\nالجوائز: ${item.reward}`).join('\n\n') : 'لا توجد منتجات للعرض.');

    interaction.update({ embeds: [userEmbed] });
  }

  // إضافة خصم جديد
  if (interaction.customId === 'add_discount') {
    const embed = new MessageEmbed()
      .setTitle('إضافة خصم جديد')
      .setColor('YELLOW')
      .setDescription('يرجى إدخال بيانات الخصم في التنسيق التالي:\n**الرمز:**\n**النسبة المئوية للخصم:**');

    interaction.reply({ embeds: [embed], ephemeral: true });

    // التعامل مع إدخال الخصم
    const filter = m => m.author.id === interaction.user.id;
    const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 15000 });

    collector.on('collect', async (msg) => {
      const [code, discount] = msg.content.split('\n');
      if (!code || !discount || isNaN(discount)) {
        return msg.reply('تنسيق البيانات غير صحيح.');
      }

      const newDiscount = { code, discount: parseInt(discount) };
      const activeDiscounts = await db.get('active_discounts') || [];
      activeDiscounts.push(newDiscount);
      await db.set('active_discounts', activeDiscounts);

      msg.reply('تم إضافة الخصم بنجاح!');
    });
  }

  // إضافة منتج
  if (interaction.customId === 'add_item') {
    const embed = new MessageEmbed()
      .setTitle('إضافة منتج جديد')
      .setColor('PURPLE')
      .setDescription('يرجى إدخال تفاصيل المنتج مثل الاسم والسعر والجوائز.');
    
    interaction.reply({ embeds: [embed], ephemeral: true });

    const filter = m => m.author.id === interaction.user.id;
    const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 15000 });

    collector.on('collect', async (msg) => {
      const [name, price, reward] = msg.content.split('\n');
      if (!name || !price || !reward || isNaN(price)) {
        return msg.reply('تنسيق البيانات غير صحيح.');
      }

      const newItem = { id: Date.now(), name, price: parseInt(price), reward };
      const items = await db.get(`shop_items_${interaction.guild.id}`) || [];
      items.push(newItem);
      await db.set(`shop_items_${interaction.guild.id}`, items);

      msg.reply('تم إضافة المنتج بنجاح!');
    });
  }

  // إزالة منتج
  if (interaction.customId === 'remove_item') {
    const embed = new MessageEmbed()
      .setTitle('إزالة منتج')
      .setColor('RED')
      .setDescription('يرجى إدخال رقم المنتج الذي تريد إزالته.');

    interaction.reply({ embeds: [embed], ephemeral: true });

    const filter = m => m.author.id === interaction.user.id;
    const collector = interaction.channel.createMessageCollector({ filter, max: 1, time: 15000 });

    collector.on('collect', async (msg) => {
      const productId = msg.content.trim();
      const items = await db.get(`shop_items_${interaction.guild.id}`) || [];
      const itemIndex = items.findIndex(item => item.id == productId);

      if (itemIndex === -1) {
        return msg.reply('المنتج غير موجود.');
      }

      items.splice(itemIndex, 1);
      await db.set(`shop_items_${interaction.guild.id}`, items);

      msg.reply('تم إزالة المنتج بنجاح!');
    });
  }
};