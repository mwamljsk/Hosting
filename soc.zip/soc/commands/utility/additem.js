const { Permissions } = require('discord.js');

module.exports = {
  name: 'additem',
  description: 'إضافة منتج إلى المتجر',
  run: async (client, message, args) => {
    // تحقق إذا كان الشخص الذي نفذ الأمر أدمن
    if (!message.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
      return message.reply('ليس لديك صلاحيات لإضافة منتج!');
    }

    // بقية الكود لإضافة المنتج
    const newItem = {
      id: args[0], // رقم المنتج (أو يمكن تخصيصه بطريقة أخرى)
      name: args[1], // اسم المنتج
      price: parseInt(args[2]), // السعر
      reward: args[3], // الجائزة
      listFile: args[4], // اسم ملف الأكواد
      targetID: args[5], // أيدي الشخص الذي سيحصل على الفلوس
    };

    const items = await client.db20.get(`shop_items_${message.guild.id}`) || [];
    items.push(newItem);

    // تحديث قاعدة البيانات
    await client.db20.set(`shop_items_${message.guild.id}`, items);

    message.reply('تم إضافة المنتج بنجاح!');
  }
};