module.exports = {
  name: "rep",
  description: "إعطاء سمعة لشخص آخر",
  run: async (client, message, args) => {
    try {
 
        
    const premium = await client.db7.get(`premium_${message.author.id}`);

    if (premium.active !== true) {
      return message.channel.send(`**Please upgrade to Premium Account to unlock this command!.**`)
    }
        
       // تحقق من أن هناك شخصًا تم منشنه
        const mentionedUser = message.mentions.users.first();
      if (!mentionedUser) {
        return message.reply("من فضلك قم بذكر الشخص الذي تريد منحه السمعة.");
      }

      // الحصول على الوقت الحالي
      const now = Date.now();

      // جلب الوقت الذي منحت فيه السمعة في آخر مرة
      const lastRepTime = await client.db17.get(`lastRep_${message.author.id}_${mentionedUser.id}`);

      // إذا لم يكن هناك وقت سابق أو كان الوقت قد مر عليه أكثر من 24 ساعة
      if (!lastRepTime || now - lastRepTime >= 24 * 60 * 60 * 1000) {
        // منح السمعة
        await client.db17.set(`rep_${mentionedUser.id}`, (await client.db17.get(`rep_${mentionedUser.id}`)) + 1);
        
        // تحديث الوقت الذي تم فيه إعطاء السمعة
        await client.db17.set(`lastRep_${message.author.id}_${mentionedUser.id}`, now);

        return message.reply(`${mentionedUser.username} حصل على سمعة جديدة!`);
      } else {
        // إذا كانت السمعة قد أعطيت مؤخرًا
        const timeRemaining = 24 * 60 * 60 * 1000 - (now - lastRepTime);
        const hours = Math.floor(timeRemaining / (1000 * 60 * 60));
        const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
        return message.reply(`يمكنك منح سمعة لـ ${mentionedUser.username} بعد ${hours} ساعة و ${minutes} دقيقة.`);
      }
    } catch (error) {
      console.error("Error in rep command:", error);
      message.reply("حدث خطأ أثناء محاولة منح السمعة.");
    }
  },
};