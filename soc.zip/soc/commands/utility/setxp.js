module.exports = {
  name: "setxp",
  description: "تحديد أو تعطيل قناة إرسال بطاقات رفع المستوى",

  run: async (client, message, args) => {
    const db = client.db19;

    if (!message.guild) return message.reply("❌ هذا الأمر يعمل فقط في السيرفرات.");

    if (!message.member.permissions.has("ManageGuild")) {
      return message.reply("❌ يجب أن تملك صلاحية 'Manage Server' لاستخدام هذا الأمر.");
    }

    const input = args[0];

    if (!input) {
      return message.reply("❌ يرجى تحديد أحد الخيارات: `on`، `off`، أو تحديد قناة مثل: `#channel`.");
    }

    // حالة off
    if (input.toLowerCase() === "off") {
      await db.delete(`rank_channel_${message.guild.id}`);
      return message.reply("✅ تم تعطيل إرسال بطاقات رفع المستوى.");
    }

    // حالة on بدون تحديد قناة (يتم التعيين على نفس القناة)
    if (input.toLowerCase() === "on") {
      await db.set(`rank_channel_${message.guild.id}`, message.channel.id);
      return message.reply(`✅ تم تفعيل إرسال بطاقات رفع المستوى في هذه القناة: ${message.channel}`);
    }

    // حالة تحديد قناة
    const channel = message.mentions.channels.first();
    if (channel) {
      await db.set(`rank_channel_${message.guild.id}`, channel.id);
      return message.reply(`✅ تم تعيين قناة رفع المستوى إلى: ${channel}`);
    }

    return message.reply("❌ خيار غير صالح. استخدم `off`، `on`، أو قم بتحديد قناة مثل: `#channel`.");
  }
};