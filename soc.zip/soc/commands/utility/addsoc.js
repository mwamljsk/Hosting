const { MessageAttachment } = require("discord.js");
const emoji = require('../../emoji.js');
const { createCanvas } = require("canvas");

module.exports = {

  name: "add_soc",

  description: "عرض أو تحويل عملة soc",

  aliases: ["oc"],

  usage: "soc | soc add @user amount | soc remove @user amount",

  run: async (client, message, args) => {

    const ownerId = "544869116771696672"; // استبدل هذا برقم معرف الأونر الخاص بك

    const senderId = message.author.id;

    const db = client.db17;

    const getBalance = async (id) => await db.get(`balance_${id}`) || 0;

    const setBalance = async (id, amount) => await db.set(`balance_${id}`, amount);

    if (args.length === 0) {

      const balance = await getBalance(senderId);

      return message.reply(`:bank:| **رصيد حسابك هو \`${soc}$\`.**`);

    }

    // تحقق إذا كان المستخدم هو الأونر

    if (senderId !== ownerId) {

      return message.reply("❌ فقط الأونر يمكنه إضافة أو سحب الرصيد.");

    }

    // أمر إضافة رصيد

    if (args[0] === "add") {

      const target = message.mentions.users.first();

      if (!target) return message.reply("❌ يرجى الإشارة إلى مستخدم.");

      const amount = parseInt(args[2]);

      if (isNaN(amount) || amount <= 0) return message.reply("❌ أدخل مبلغًا صحيحًا لإضافته.");

      const targetBalance = await getBalance(target.id);

      await setBalance(target.id, targetBalance + amount);

      return message.reply(`✅ تم إضافة **${amount.toLocaleString()}${emoji.flag.soc}** إلى رصيد **<@!${target.id}>** بنجاح.`);

    }

    // أمر سحب رصيد

    if (args[0] === "remove") {

      const target = message.mentions.users.first();

      if (!target) return message.reply("❌ يرجى الإشارة إلى مستخدم.");

      const amount = parseInt(args[2]);

      if (isNaN(amount) || amount <= 0) return message.reply("❌ أدخل مبلغًا صحيحًا للسحب.");

      const targetBalance = await getBalance(target.id);

      if (targetBalance < amount) return message.reply("❌ لا يوجد رصيد كافي لسحب هذا المبلغ.");

      await setBalance(target.id, targetBalance - amount);

      return message.reply(`✅ تم سحب **${amount.toLocaleString()}${emoji.flag.soc}** من رصيد **<@!${target.id}>** بنجاح.`);

    }

    const target = message.mentions.users.first();

    if (!target) return message.reply("❌ يرجى الإشارة إلى مستخدم.");

    if (args.length === 1) {

      const soc = await getBalance(target.id);

      return message.reply(`**:bank:| ـ ${target.username}، رصيد حسابك هو \`${soc.toLocaleString()}\`${emoji.flag.soc}.**`);

    }

    if (args.length === 2) {

      const amount = parseInt(args[1]);

      if (isNaN(amount) || amount <= 0) return message.reply("❌ أدخل مبلغًا صحيحًا للتحويل.");

      const senderBalance = await getBalance(senderId);

      if (senderBalance < amount) return message.reply("❌ لا تملك رصيدًا كافيًا.");

      // حساب الرسوم والتحويل النهائي

      const fee = parseFloat((amount * 0.02).toFixed(2));

      const finalAmount = amount - fee;

      const code = Math.floor(1000 + Math.random() * 9000).toString();

      // إنشاء صورة الكود المخربش

      const canvas = createCanvas(400, 200);

      const ctx = canvas.getContext("2d");

      ctx.fillStyle = "#111";

      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.font = "bold 60px Arial";

      ctx.textBaseline = "middle";

      ctx.textAlign = "center";

      const positions = [

        { x: 60, y: 100 },

        { x: 130, y: 100 },

        { x: 200, y: 100 },

        { x: 270, y: 100 }

      ];

      code.split("").forEach((digit, i) => {

        const { x, y } = positions[i];

        ctx.save();

        const angle = (Math.random() * 0.4) - 0.2;

        ctx.translate(x, y);

        ctx.rotate(angle);

        ctx.fillStyle = "#0f0";

        ctx.fillText(digit, 0, 0);

        ctx.restore();

        // خربشات عشوائية

        for (let j = 0; j < 4; j++) {

          ctx.strokeStyle = "#0f08";

          ctx.beginPath();

          const offsetX = Math.random() * 30 - 15;

          const offsetY = Math.random() * 30 - 15;

          ctx.moveTo(x + offsetX, y + offsetY);

          ctx.lineTo(x + offsetX + Math.random() * 10 - 5, y + offsetY + Math.random() * 10 - 5);

          ctx.stroke();

        }

      });

      const attachment = new MessageAttachment(canvas.toBuffer(), "code.png");

      const confirmMsg = await message.reply({

  content: `🔐 لإتمام التحويل إلى **${target.username}** بمقدار **\`${amount.toLocaleString()}\`${emoji.flag.soc}**، أرسل الكود الصحيح الموجود في الصورة (مرتبًا بشكل صحيح). لديك 30 ثانية. رسوم التحويل: **${fee}${emoji.flag.soc}**`,

  files: [attachment]

});

      const filter = m => m.author.id === senderId && m.content === code;

      try {

        const collected = await message.channel.awaitMessages({

          filter,

          max: 1,

          time: 30000,

          errors: ['time']

        });
          const userCodeMessage = collected.first();

await confirmMsg.delete();             // حذف رسالة التحويل مع الصورة

await userCodeMessage.delete();        // حذف رسالة الكود التي أرسلها المستخدم

        await setBalance(senderId, senderBalance - amount);

        const targetBalance = await getBalance(target.id);

        await setBalance(target.id, targetBalance + finalAmount);

        return message.reply(`**:moneybag: | ${target.username}، قام بتحويل \`${finalAmount.toLocaleString()}$\` إلى <@!${target.id}>**`);

      } catch (err) {

        return message.reply("❌ لم يتم إدخال الرمز الصحيح في الوقت المحدد. تم إلغاء التحويل.");

      }

    }

  }

};