const { MessageEmbed, MessageActionRow, MessageSelectMenu, MessageButton } = require('discord.js');

module.exports = {
  name: 'se_es',
  description: 'يعرض لك السيرفرات التي فيها البوت',
  run: async (client, message) => {
    const ownerId = '544869116771696672'; // ضع معرفك هنا
    if (message.author.id !== ownerId) return;

    const guilds = [...client.guilds.cache.values()];

    const selectMenu = new MessageActionRow().addComponents(
      new MessageSelectMenu()
        .setCustomId('select_server')
        .setPlaceholder('اختر سيرفر لعرض المعلومات')
        .addOptions(
          guilds.map(g => ({
            label: g.name.substring(0, 100),
            value: g.id,
            description: `عدد الأعضاء: ${g.memberCount}`
          }))
        )
    );

    const msg_ = await message.channel.send({
      content: `اختر أحد السيرفرات من القائمة أدناه:`,
      components: [selectMenu]
    });

    const selectCollector = msg_.createMessageComponentCollector({
      filter: i => i.user.id === ownerId,
      time: 60_000,
      max: 1
    });

    selectCollector.on('collect', async interaction => {
      const guild = client.guilds.cache.get(interaction.values[0]);
      if (!guild) return interaction.reply({ content: '❌ لم أتمكن من العثور على هذا السيرفر.', ephemeral: true });

      const owner = await guild.fetchOwner().catch(() => null);

      const embed = new MessageEmbed()
        .setTitle(guild.name)
        .setThumbnail(guild.iconURL({ dynamic: true }))
        .addFields(
          { name: 'عدد الأعضاء', value: `${guild.memberCount}`, inline: true },
          { name: 'المالك', value: `${owner ? owner.user.tag : 'غير معروف'}`, inline: true },
          { name: 'عدد الرومات', value: `${guild.channels.cache.size}`, inline: true },
        )
        .setColor('BLUE');

      const row = new MessageActionRow().addComponents(
        new MessageButton()
          .setCustomId(`kick_${guild.id}`)
          .setLabel(`❌ طرد البوت`)
          .setStyle('DANGER'),
        new MessageButton()
          .setCustomId(`invite_${guild.id}`)
          .setLabel(`🔗 رابط دعوة`)
          .setStyle('SUCCESS')
      );

      await interaction.update({ embeds: [embed], components: [row] });

      const inviteCollector = msg_.channel.createMessageComponentCollector({
        filter: i => i.user.id === ownerId && (i.customId === `kick_${guild.id}` || i.customId === `invite_${guild.id}`),
        time: 20_000,
        max: 1
      });

      inviteCollector.on('collect', async btn => {
        if (btn.customId === `kick_${guild.id}`) {
          await guild.leave();
          btn.reply({ content: `✅ تم طرد البوت من **${guild.name}**.`, ephemeral: true });
        } else if (btn.customId === `invite_${guild.id}`) {
          try {
            const channels = guild.channels.cache.filter(c =>
              c.type === 'GUILD_TEXT' &&
              c.permissionsFor(guild.me).has('CREATE_INSTANT_INVITE')
            );

            const channel = channels.first();
            if (!channel) return btn.reply({ content: '❌ لا أملك صلاحية إنشاء رابط دعوة.', ephemeral: true });

            const invite = await channel.createInvite({ maxAge: 0, maxUses: 0 });
            btn.reply({ content: `🔗 رابط الدعوة:\n${invite.url}`, ephemeral: true });
          } catch (err) {
            btn.reply({ content: '❌ حدث خطأ أثناء إنشاء رابط الدعوة.', ephemeral: true });
          }
        }
      });
    });
  }
};