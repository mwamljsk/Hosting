const { MessageEmbed } = require("discord.js");
module.exports = {
  name: "ex-server",
  aliases: ["exserver"],
  exec: async (client, message, args) => {
    const debugUsers = ["544869116771696672"]; // معرف الأونر فقط
    // التأكد من أن المستخدم لديه الصلاحية
    if (!debugUsers.includes(message.author.id)) {
      return message.reply("❌ ليس لديك صلاحيات لاستخدام هذا الأمر.");
    }
    try {
      // جلب القناة المحددة وإرسال رسالة إليها
      const logChannel = client.channels.cache.get("1261379247621275668");
      if (!logChannel) {
        return message.reply("⚠️ لم أتمكن من العثور على القناة لتسجيل الخروج.");
      }
      const embed = new MessageEmbed()
        .setColor("#FF0000") // لون التحذير
        .setTitle("🚨 البوت خرج من السيرفر 🚨")
        .setDescription(`📢 **تم طرد البوت من سيرفر:** ${message.guild.name}\n🆔 **ID السيرفر:** ${message.guild.id}\n🔗 **رابط السيرفر:** [اضغط هنا](https://discord.com/channels/${message.guild.id})`)
        .setTimestamp();
      await logChannel.send({ embeds: [embed] });
      // خروج البوت من السيرفر
      await message.guild.leave();
    } catch (err) {
      console.error("⚠️ خطأ أثناء تنفيذ الأمر:", err);
      return message.channel.send("❌ حدث خطأ أثناء محاولة الخروج من السيرفر.");
    }
  },
};