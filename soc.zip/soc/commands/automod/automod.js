const { MessageEmbed } = require('discord.js');
const Settings = require('../../settings.js');
const emoji = require('../../emoji.js');
const owner = Settings.bot.credits.developerId;

module.exports = {
  name: 'automod',
  aliases: ['am'],
  run: async (client, message, args) => {
    const prefix = await client.db8.get(`${message.guild.id}_prefix`) || Settings.bot.info.prefix;
    const arypton = await client.users.fetch(owner);

    const createEmbed = (description) => {
      return new MessageEmbed()
        .setColor(client.color)
        .setThumbnail(client.user.displayAvatarURL())
        .setAuthor(client.user.tag, client.user.displayAvatarURL())
        .setDescription(description)
        .setFooter(`Made by ${arypton.username} with ❤️`, arypton.displayAvatarURL({ dynamic: true }));
    };

    if (!message.member.permissions.has('MANAGE_GUILD'))
      return message.reply("You don't have permission to use this command.");

    if (!message.guild.me.permissions.has('MANAGE_GUILD'))
      return message.reply("I need `Manage Server` permission to manage AutoMod rules.");

    const existingRules = await message.guild.autoModerationRules.fetch();

    const rulesToManage = [
      'lnl Anti Toxicity',
      'lnl Anti Pornography',
      'lnl Anti Spam Basic',
      'lnl Anti Mention Spam'
    ];

    const createRule = async (name, options) => {
      if (existingRules.some(rule => rule.name === name)) return;

      await message.guild.autoModerationRules.create({
        name,
        creatorId: client.user.id,
        enabled: true,
        eventType: 1,
        ...options,
        actions: [{
          type: 1,
          metadata: {
            channel: message.channel,
            durationSeconds: 10,
            customMessage: 'This message has been blocked.'
          }
        }]
      });
    };

    if (args[0] === 'enable') {
      try {
        await createRule('lnl Anti Toxicity', {
          triggerType: 1,
          triggerMetadata: { keywordFilter: ['mo'] }
        });

        await createRule('lnl Anti Pornography', {
          triggerType: 4,
          triggerMetadata: { presets: [1, 2, 3] }
        });

        await createRule('lnl Anti Spam Basic', {
          triggerType: 3
        });

        await createRule('lnl Anti Mention Spam', {
          triggerType: 5,
          triggerMetadata: { mentionTotalLimit: 5, mentionSpamRule: true }
        });

        const embed = createEmbed(`AutoMod rules have been **enabled** successfully.\n${emoji.util.enabled}`);
        await message.channel.send({ embeds: [embed] });

      } catch (err) {
        console.error(err);
        const errorEmbed = createEmbed(`Something went wrong while enabling AutoMod.`);
        await message.channel.send({ embeds: [errorEmbed] });
      }

    } else if (args[0] === 'disable') {
      try {
        for (const ruleName of rulesToManage) {
          const rule = existingRules.find(r => r.name === ruleName);
          if (rule) await rule.delete();
        }

        const embed = createEmbed(`AutoMod rules have been **disabled and removed**.\n${emoji.util.disabler}`);
        await message.channel.send({ embeds: [embed] });

      } catch (err) {
        console.error(err);
        const errorEmbed = createEmbed(`Failed to disable AutoMod rules.`);
        await message.channel.send({ embeds: [errorEmbed] });
      }
    } else {
      const helpEmbed = createEmbed(`Usage:\n\`${prefix}automod enable\` to activate\n\`${prefix}automod disable\` to deactivate`);
      await message.channel.send({ embeds: [helpEmbed] });
    }
  }
};