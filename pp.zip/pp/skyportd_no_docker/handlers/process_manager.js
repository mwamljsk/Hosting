/**
 * Process Manager - Docker Alternative for Skyport
 * Manages applications as native Node.js processes instead of Docker containers
 */

const { spawn, exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const os = require('os');
const pidtree = require('pidtree');
const psList = require('ps-list');

class ProcessManager {
    constructor() {
        this.processes = new Map(); // Map of process ID to process info
        this.processDir = path.join(__dirname, '../processes');
        this.initializeProcessDir();
    }

    async initializeProcessDir() {
        try {
            await fs.mkdir(this.processDir, { recursive: true });
        } catch (error) {
            // Directory already exists
        }
    }

    /**
     * Simulates docker.ping() - checks if process manager is ready
     */
    async ping() {
        return true;
    }

    /**
     * Simulates docker.info() - returns system information
     */
    async info() {
        const loadAvg = os.loadavg();
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        
        return {
            ID: 'process-manager',
            Containers: this.processes.size,
            ContainersRunning: Array.from(this.processes.values()).filter(p => p.status === 'running').length,
            ContainersPaused: 0,
            ContainersStopped: Array.from(this.processes.values()).filter(p => p.status === 'stopped').length,
            Images: 0,
            Driver: 'process',
            SystemStatus: 'active',
            Plugins: {
                Volume: ['local'],
                Network: ['bridge', 'host', 'null'],
                Authorization: null,
                Log: ['local']
            },
            MemoryLimit: true,
            SwapLimit: false,
            KernelMemory: false,
            CpuCfsPeriod: true,
            CpuCfsQuota: true,
            CPUShares: true,
            CPUSet: true,
            IPv4Forwarding: true,
            BridgeNfIptables: false,
            BridgeNfIp6tables: false,
            Debug: false,
            NFd: 0,
            NGoroutines: 0,
            SystemTime: new Date().toISOString(),
            LoggingDriver: 'local',
            CgroupDriver: 'systemd',
            NEventsListener: 0,
            KernelVersion: os.release(),
            OperatingSystem: `${os.type()} ${os.release()}`,
            OSType: os.type(),
            Architecture: os.arch(),
            IndexServerAddress: 'https://index.docker.io/v1/',
            NCPU: os.cpus().length,
            MemTotal: totalMem,
            DockerRootDir: this.processDir,
            HttpProxy: '',
            HttpsProxy: '',
            NoProxy: '',
            Name: os.hostname(),
            Labels: [],
            ExperimentalBuild: false,
            ServerVersion: '1.0.0-process-manager',
            ClusterStore: '',
            ClusterAdvertise: '',
            DefaultRuntime: 'process',
            Swarm: {
                NodeID: '',
                NodeAddr: '',
                LocalNodeState: 'inactive',
                ControlAvailable: false,
                Error: '',
                RemoteManagers: null
            },
            LiveRestoreEnabled: false,
            Isolation: '',
            InitBinary: '',
            ContainerdCommit: {
                ID: '',
                Expected: ''
            },
            RuncCommit: {
                ID: '',
                Expected: ''
            },
            InitCommit: {
                ID: '',
                Expected: ''
            },
            SecurityOptions: []
        };
    }

    /**
     * Simulates docker.listContainers() - lists all managed processes
     */
    async listContainers(options = {}) {
        const all = options.all || false;
        const processes = Array.from(this.processes.values());
        
        if (!all) {
            return processes.filter(p => p.status === 'running');
        }
        
        return processes.map(p => ({
            Id: p.id,
            Names: [p.name],
            Image: p.image || 'local/process',
            ImageID: p.imageId || 'local-process',
            Command: p.command,
            Created: p.created,
            Ports: p.ports || [],
            Labels: p.labels || {},
            State: p.status,
            Status: p.status === 'running' ? 'Up' : 'Exited',
            HostConfig: {
                NetworkMode: 'bridge'
            },
            NetworkSettings: {
                Networks: {
                    bridge: {
                        IPAMConfig: null,
                        Links: null,
                        Aliases: null,
                        NetworkID: 'bridge',
                        EndpointID: '',
                        Gateway: '172.17.0.1',
                        IPAddress: `172.17.0.${Math.floor(Math.random() * 254) + 2}`,
                        IPPrefixLen: 16,
                        IPv6Gateway: '',
                        GlobalIPv6Address: '',
                        GlobalIPv6PrefixLen: 0,
                        MacAddress: `02:42:ac:11:00:${Math.floor(Math.random() * 254).toString(16).padStart(2, '0')}`
                    }
                }
            },
            Mounts: []
        }));
    }

    /**
     * Simulates container.stats() - gets process statistics
     */
    async getProcessStats(processId) {
        const processInfo = this.processes.get(processId);
        if (!processInfo || !processInfo.pid) {
            throw new Error('Process not found');
        }

        try {
            const processes = await psList();
            const targetProcess = processes.find(p => p.pid === processInfo.pid);
            
            if (!targetProcess) {
                throw new Error('Process not running');
            }

            // Get child processes
            let childPids = [];
            try {
                childPids = await pidtree(processInfo.pid);
            } catch (error) {
                // Process might not have children
            }

            return {
                read: new Date().toISOString(),
                preread: new Date(Date.now() - 1000).toISOString(),
                pids_stats: {
                    current: childPids.length + 1
                },
                blkio_stats: {
                    io_service_bytes_recursive: [],
                    io_serviced_recursive: [],
                    io_queue_recursive: [],
                    io_service_time_recursive: [],
                    io_wait_time_recursive: [],
                    io_merged_recursive: [],
                    io_time_recursive: [],
                    sectors_recursive: []
                },
                num_procs: 0,
                storage_stats: {},
                cpu_stats: {
                    cpu_usage: {
                        total_usage: Math.floor(Math.random() * 1000000000), // Simulated
                        percpu_usage: os.cpus().map(() => Math.floor(Math.random() * 100000000)),
                        usage_in_kernelmode: Math.floor(Math.random() * 10000000),
                        usage_in_usermode: Math.floor(Math.random() * 10000000)
                    },
                    system_cpu_usage: Math.floor(Math.random() * 10000000000),
                    online_cpus: os.cpus().length,
                    throttling_data: {
                        periods: 0,
                        throttled_periods: 0,
                        throttled_time: 0
                    }
                },
                precpu_stats: {
                    cpu_usage: {
                        total_usage: Math.floor(Math.random() * 1000000000),
                        percpu_usage: os.cpus().map(() => Math.floor(Math.random() * 100000000)),
                        usage_in_kernelmode: Math.floor(Math.random() * 10000000),
                        usage_in_usermode: Math.floor(Math.random() * 10000000)
                    },
                    system_cpu_usage: Math.floor(Math.random() * 10000000000),
                    online_cpus: os.cpus().length,
                    throttling_data: {
                        periods: 0,
                        throttled_periods: 0,
                        throttled_time: 0
                    }
                },
                memory_stats: {
                    usage: targetProcess.memory || Math.floor(Math.random() * 100000000),
                    max_usage: (targetProcess.memory || Math.floor(Math.random() * 100000000)) * 1.2,
                    stats: {
                        active_anon: Math.floor(Math.random() * 50000000),
                        active_file: Math.floor(Math.random() * 50000000),
                        cache: Math.floor(Math.random() * 20000000),
                        dirty: Math.floor(Math.random() * 1000000),
                        hierarchical_memory_limit: 9223372036854775807,
                        hierarchical_memsw_limit: 9223372036854775807,
                        inactive_anon: Math.floor(Math.random() * 20000000),
                        inactive_file: Math.floor(Math.random() * 30000000),
                        mapped_file: Math.floor(Math.random() * 10000000),
                        pgfault: Math.floor(Math.random() * 1000000),
                        pgmajfault: Math.floor(Math.random() * 1000),
                        pgpgin: Math.floor(Math.random() * 100000),
                        pgpgout: Math.floor(Math.random() * 100000),
                        rss: Math.floor(Math.random() * 50000000),
                        rss_huge: 0,
                        total_active_anon: Math.floor(Math.random() * 50000000),
                        total_active_file: Math.floor(Math.random() * 50000000),
                        total_cache: Math.floor(Math.random() * 20000000),
                        total_dirty: Math.floor(Math.random() * 1000000),
                        total_inactive_anon: Math.floor(Math.random() * 20000000),
                        total_inactive_file: Math.floor(Math.random() * 30000000),
                        total_mapped_file: Math.floor(Math.random() * 10000000),
                        total_pgfault: Math.floor(Math.random() * 1000000),
                        total_pgmajfault: Math.floor(Math.random() * 1000),
                        total_pgpgin: Math.floor(Math.random() * 100000),
                        total_pgpgout: Math.floor(Math.random() * 100000),
                        total_rss: Math.floor(Math.random() * 50000000),
                        total_rss_huge: 0,
                        total_unevictable: 0,
                        total_writeback: 0,
                        unevictable: 0,
                        writeback: 0
                    },
                    limit: os.totalmem()
                },
                name: `/process_${processId}`,
                id: processId,
                networks: {
                    eth0: {
                        rx_bytes: Math.floor(Math.random() * 1000000),
                        rx_packets: Math.floor(Math.random() * 10000),
                        rx_errors: 0,
                        rx_dropped: 0,
                        tx_bytes: Math.floor(Math.random() * 1000000),
                        tx_packets: Math.floor(Math.random() * 10000),
                        tx_errors: 0,
                        tx_dropped: 0
                    }
                }
            };
        } catch (error) {
            throw new Error(`Failed to get process stats: ${error.message}`);
        }
    }

    /**
     * Creates a new process (simulates docker.createContainer)
     */
    async createContainer(options) {
        const processId = Math.random().toString(36).substr(2, 12);
        const processInfo = {
            id: processId,
            name: options.name || `process_${processId}`,
            image: options.Image || 'local/process',
            imageId: 'local-process',
            command: options.Cmd ? options.Cmd.join(' ') : '',
            created: Math.floor(Date.now() / 1000),
            status: 'created',
            process: null,
            pid: null,
            ports: options.ExposedPorts ? Object.keys(options.ExposedPorts) : [],
            labels: options.Labels || {},
            workingDir: options.WorkingDir || this.processDir,
            env: options.Env || [],
            volumes: options.Volumes || {},
            hostConfig: options.HostConfig || {}
        };

        this.processes.set(processId, processInfo);

        return {
            id: processId,
            start: async () => this.startProcess(processId),
            stop: async () => this.stopProcess(processId),
            restart: async () => this.restartProcess(processId),
            inspect: async () => this.inspectProcess(processId),
            stats: () => this.getProcessStats(processId),
            logs: (options = {}) => this.getProcessLogs(processId, options)
        };
    }

    /**
     * Gets an existing process (simulates docker.getContainer)
     */
    getContainer(processId) {
        if (!this.processes.has(processId)) {
            throw new Error('Process not found');
        }

        return {
            id: processId,
            start: async () => this.startProcess(processId),
            stop: async () => this.stopProcess(processId),
            restart: async () => this.restartProcess(processId),
            inspect: async () => this.inspectProcess(processId),
            stats: () => this.getProcessStats(processId),
            logs: (options = {}) => this.getProcessLogs(processId, options)
        };
    }

    /**
     * Starts a process
     */
    async startProcess(processId) {
        const processInfo = this.processes.get(processId);
        if (!processInfo) {
            throw new Error('Process not found');
        }

        if (processInfo.status === 'running') {
            return; // Already running
        }

        // For this demo, we'll start a simple Node.js process
        // In a real implementation, you'd parse the Docker image and run the appropriate application
        const command = processInfo.command || 'node -e "console.log(\'Process started\'); setInterval(() => console.log(\'Process running...\'), 5000);"';
        
        const child = spawn('sh', ['-c', command], {
            cwd: processInfo.workingDir,
            env: { ...process.env, ...this.parseEnvArray(processInfo.env) },
            stdio: ['pipe', 'pipe', 'pipe']
        });

        processInfo.process = child;
        processInfo.pid = child.pid;
        processInfo.status = 'running';
        processInfo.startedAt = new Date().toISOString();

        // Handle process events
        child.on('exit', (code, signal) => {
            processInfo.status = 'stopped';
            processInfo.exitCode = code;
            processInfo.exitedAt = new Date().toISOString();
            processInfo.process = null;
            processInfo.pid = null;
        });

        child.on('error', (error) => {
            processInfo.status = 'error';
            processInfo.error = error.message;
        });

        this.processes.set(processId, processInfo);
        return processInfo;
    }

    /**
     * Stops a process
     */
    async stopProcess(processId) {
        const processInfo = this.processes.get(processId);
        if (!processInfo) {
            throw new Error('Process not found');
        }

        if (processInfo.status !== 'running' || !processInfo.process) {
            return; // Already stopped
        }

        return new Promise((resolve) => {
            processInfo.process.on('exit', () => {
                processInfo.status = 'stopped';
                processInfo.exitedAt = new Date().toISOString();
                resolve();
            });

            // Try graceful termination first
            processInfo.process.kill('SIGTERM');

            // Force kill after 10 seconds
            setTimeout(() => {
                if (processInfo.process) {
                    processInfo.process.kill('SIGKILL');
                }
            }, 10000);
        });
    }

    /**
     * Restarts a process
     */
    async restartProcess(processId) {
        await this.stopProcess(processId);
        await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
        await this.startProcess(processId);
    }

    /**
     * Inspects a process (simulates container.inspect)
     */
    async inspectProcess(processId) {
        const processInfo = this.processes.get(processId);
        if (!processInfo) {
            throw new Error('Process not found');
        }

        return {
            Id: processId,
            Created: new Date(processInfo.created * 1000).toISOString(),
            Path: '/bin/sh',
            Args: ['-c', processInfo.command],
            State: {
                Status: processInfo.status,
                Running: processInfo.status === 'running',
                Paused: false,
                Restarting: false,
                OOMKilled: false,
                Dead: processInfo.status === 'stopped',
                Pid: processInfo.pid || 0,
                ExitCode: processInfo.exitCode || 0,
                Error: processInfo.error || '',
                StartedAt: processInfo.startedAt || new Date().toISOString(),
                FinishedAt: processInfo.exitedAt || '0001-01-01T00:00:00Z'
            },
            Image: processInfo.image,
            ResolvConfPath: '',
            HostnamePath: '',
            HostsPath: '',
            LogPath: '',
            Name: `/${processInfo.name}`,
            RestartCount: 0,
            Driver: 'process',
            Platform: 'linux',
            MountLabel: '',
            ProcessLabel: '',
            AppArmorProfile: '',
            ExecIDs: null,
            HostConfig: processInfo.hostConfig,
            GraphDriver: {
                Data: {
                    LowerDir: '',
                    MergedDir: '',
                    UpperDir: '',
                    WorkDir: ''
                },
                Name: 'process'
            },
            Mounts: [],
            Config: {
                Hostname: os.hostname(),
                Domainname: '',
                User: '',
                AttachStdin: false,
                AttachStdout: true,
                AttachStderr: true,
                Tty: false,
                OpenStdin: false,
                StdinOnce: false,
                Env: processInfo.env,
                Cmd: processInfo.command.split(' '),
                Image: processInfo.image,
                Volumes: processInfo.volumes,
                WorkingDir: processInfo.workingDir,
                Entrypoint: null,
                OnBuild: null,
                Labels: processInfo.labels
            },
            NetworkSettings: {
                Bridge: '',
                SandboxID: '',
                HairpinMode: false,
                LinkLocalIPv6Address: '',
                LinkLocalIPv6PrefixLen: 0,
                Ports: {},
                SandboxKey: '',
                SecondaryIPAddresses: null,
                SecondaryIPv6Addresses: null,
                EndpointID: '',
                Gateway: '172.17.0.1',
                GlobalIPv6Address: '',
                GlobalIPv6PrefixLen: 0,
                IPAddress: `172.17.0.${Math.floor(Math.random() * 254) + 2}`,
                IPPrefixLen: 16,
                IPv6Gateway: '',
                MacAddress: `02:42:ac:11:00:${Math.floor(Math.random() * 254).toString(16).padStart(2, '0')}`,
                Networks: {
                    bridge: {
                        IPAMConfig: null,
                        Links: null,
                        Aliases: null,
                        NetworkID: 'bridge',
                        EndpointID: '',
                        Gateway: '172.17.0.1',
                        IPAddress: `172.17.0.${Math.floor(Math.random() * 254) + 2}`,
                        IPPrefixLen: 16,
                        IPv6Gateway: '',
                        GlobalIPv6Address: '',
                        GlobalIPv6PrefixLen: 0,
                        MacAddress: `02:42:ac:11:00:${Math.floor(Math.random() * 254).toString(16).padStart(2, '0')}`
                    }
                }
            }
        };
    }

    /**
     * Gets process logs (simulates container.logs)
     */
    getProcessLogs(processId, options = {}) {
        const processInfo = this.processes.get(processId);
        if (!processInfo) {
            throw new Error('Process not found');
        }

        // Return a mock stream for logs
        const { Readable } = require('stream');
        const logStream = new Readable({
            read() {
                // Simulate log output
                this.push(`[${new Date().toISOString()}] Process ${processId} log entry\n`);
                
                if (Math.random() > 0.8) {
                    this.push(null); // End stream
                }
            }
        });

        return logStream;
    }

    /**
     * Simulates docker.pull() - downloads and prepares an application
     */
    async pull(imageName) {
        // In a real implementation, this would download the application/script
        // For demo purposes, we'll just simulate the progress
        const { Readable } = require('stream');
        
        const pullStream = new Readable({
            read() {
                const progress = Math.floor(Math.random() * 100);
                this.push(JSON.stringify({
                    status: 'Downloading',
                    id: imageName,
                    progress: `${progress}%`,
                    progressDetail: {
                        current: progress,
                        total: 100
                    }
                }) + '\n');

                if (progress >= 95) {
                    this.push(JSON.stringify({
                        status: 'Download complete',
                        id: imageName
                    }) + '\n');
                    this.push(null);
                }
            }
        });

        return pullStream;
    }

    /**
     * Utility function to parse environment array
     */
    parseEnvArray(envArray) {
        const envObj = {};
        envArray.forEach(env => {
            const [key, ...values] = env.split('=');
            envObj[key] = values.join('=');
        });
        return envObj;
    }

    /**
     * Mock modem for compatibility
     */
    get modem() {
        return {
            followProgress: (stream, callback) => {
                stream.on('data', (chunk) => {
                    // Process chunk if needed
                });
                stream.on('end', () => {
                    callback(null, 'complete');
                });
                stream.on('error', (error) => {
                    callback(error);
                });
            }
        };
    }
}

module.exports = ProcessManager;
