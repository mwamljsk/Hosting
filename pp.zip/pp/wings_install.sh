#!/bin/bash



git clone https://github.com/achul123/skyportd.git
cd skyportd 
npm install

echo_message "* cd skyportd"

echo_message "* paste your configure code"

echo_message "* pm2 start ."

