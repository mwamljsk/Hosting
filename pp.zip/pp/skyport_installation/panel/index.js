const express = require('express');
const app = express();
const port = 3001;

app.get('/', (req, res) => {
  res.send(`
    <h1>Skyport Panel - Docker-Free Version</h1>
    <p>Welcome to Skyport Panel running without Docker!</p>
    <p>This version is optimized for mobile devices and UserLand environments.</p>
    <p>Version: 1.0.0-no-docker</p>
    <p>Status: <span style="color: green;">Running</span></p>
    <hr>
    <h3>Features available:</h3>
    <ul>
      <li>Process Management (replaces container management)</li>
      <li>Application Deployment</li>
      <li>Real-time Monitoring</li>
      <li>Web-based Interface</li>
    </ul>
  `);
});

app.listen(port, () => {
  console.log(`Skyport Panel listening at http://localhost:${port}`);
  console.log('Panel is ready for Docker-free operation!');
});
