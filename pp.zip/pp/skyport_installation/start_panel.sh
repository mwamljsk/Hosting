#!/bin/bash
echo "Starting Skyport Panel (Docker-Free version)..."
cd panel
pm2 start index.js --name "skyport-panel"
echo "Skyport Panel started with PM2"
