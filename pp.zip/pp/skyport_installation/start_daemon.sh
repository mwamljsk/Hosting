#!/bin/bash
echo "Starting Skyport Daemon (Docker-Free version)..."
cd skyportd
pm2 start index.js --name "skyport-daemon"
echo "Skyport Daemon started with PM2"
