#!/bin/bash
echo "Starting Skyport (Docker-Free version)..."
echo "Starting Daemon..."
cd skyportd
pm2 start index.js --name "skyport-daemon"
cd ..

echo "Starting Panel..."
cd panel
pm2 start index.js --name "skyport-panel"
cd ..

echo "All services started!"
echo "Panel available at: http://localhost:3001"
echo "Daemon available at: http://localhost:3002"
echo ""
echo "To check status: pm2 status"
echo "To stop all: pm2 stop all"
echo "To restart all: pm2 restart all"
