/**
 * Database Handler - Simplified version for Docker-free operation
 */

const createDatabaseAndUser = () => {
    console.log('Database initialized (simplified)');
    return Promise.resolve();
};

module.exports = {
    createDatabaseAndUser
};
