/**
 * FTP Handler - Simplified version for Docker-free operation
 */

const start = () => {
    console.log('FTP service initialized (simplified)');
    return Promise.resolve();
};

const createNewVolume = (volumeId) => {
    console.log(`Volume ${volumeId} created (simplified)`);
    return Promise.resolve();
};

module.exports = {
    start,
    createNewVolume
};
