/**
 * Stats Handler - Simplified version for Docker-free operation
 */

const os = require('os');

class StatsLogger {
    constructor() {
        this.stats = {
            total: () => ({
                cpu: os.loadavg()[0] * 100,
                memory: (1 - os.freemem() / os.totalmem()) * 100,
                disk: 50, // Simulated
                network: {
                    rx: Math.floor(Math.random() * 1000000),
                    tx: Math.floor(Math.random() * 1000000)
                }
            })
        };
    }

    initLogger() {
        console.log('Stats logger initialized (simplified)');
    }

    get getSystemStats() {
        return this.stats;
    }
}

module.exports = new StatsLogger();
